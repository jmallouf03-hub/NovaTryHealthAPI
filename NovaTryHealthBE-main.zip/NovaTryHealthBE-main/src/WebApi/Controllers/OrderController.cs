﻿using Microsoft.AspNetCore.Mvc;
using NovaHealth.Application.BookOrders.Command.AddOrUpdateBookOrder;
using NovaHealth.Application.BookOrders.Queries.GetBookOrderById;

namespace NovaHealth.WebApi.Controllers;
/// <summary>
///  
/// </summary>
public class OrderController : ApiControllerBase
{
    /// <summary>
    ///  Book Order By Id. 
    /// </summary>
    [HttpGet("Book-Order")]
    public async Task<GetBookOrderByIdResponse> GetBookOrderAsync([FromQuery]GetBookOrderByIdRequest request)
    {
        return await Mediator.Send(request);
    }

    /// <summary>
    ///   Add Update Book Order.
    /// </summary>
    [HttpPost("Add-Update-Book-Order")]
    public async Task<long> AddUpdateBookOrderAsync([FromBody] AddOrUpdateBookOrderRequest request)
    {
        return await Mediator.Send(request);
    }
}
