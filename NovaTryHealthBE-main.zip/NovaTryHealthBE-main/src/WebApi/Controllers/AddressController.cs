﻿using Microsoft.AspNetCore.Mvc;
using NovaHealth.Application.Address.Command.AddUpdateUserAddress;
using NovaHealth.Application.Address.Command.AddUpdateUserShippingAddress;
using NovaHealth.Application.Address.Queries.GetAddressByUserId;
using NovaHealth.Application.Address.Queries.GetShippingAddressByUserId;

namespace NovaHealth.WebApi.Controllers;

/// <summary>
/// Controller for managing address
/// </summary>
public class AddressController : ApiControllerBase
{
    /// <summary>
    /// Add or update user address.
    /// </summary>

    [HttpPost("add-update-address")]
    public async Task<bool> AddUpdateAddressAsync(AddUpdateUserAddressRequest request)
    {
        return await Mediator.Send(request);
    }

    /// <summary>
    /// Get Address by userId.
    /// </summary>
    [HttpGet("address")]
    public async Task<GetAddressResponse> GetAddressByUserIdAsync([FromQuery] GetAddressByUserIdRequest request)
        {
        return await Mediator.Send(request);
    }

    /// <summary>
    /// Add update shipping address.
    /// </summary>

    [HttpPost("add-Update-shipping-address")]
    public async Task<bool> AddUpdateShippingAddressAsync(AddUpdateUserShippingAddressRequest request)
    {
        return await Mediator.Send(request);
    }

    /// <summary>
    /// Get shipping address by userId
    /// </summary>
    [HttpGet("shipping-address")]
    public async Task<GetShippingAddressResponse> GetShippingAddressByUserIdAsync([FromQuery]GetShippingAddressRequest request)
    {
        return await Mediator.Send(request);
    }
}