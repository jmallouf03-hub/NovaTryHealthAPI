﻿using NovaHealth.Application.Common.Models;
using NovaHealth.Application.LoginLogs.Queries.GetLoginLogs;
using Microsoft.AspNetCore.Mvc;

namespace NovaHealth.WebApi.Controllers;

/// <summary>
/// Controller for managing login logs.
/// </summary>
[Route("api/login-logs")]
[ApiController]
public class LoginLogsController : ApiControllerBase
{
    /// <summary>
    /// Retrieves a list of login logs.
    /// </summary>
    [HttpGet]
    public async Task<PaginationResponse<GetLoginLogsResponse>> GetLoginLogsAsync([FromQuery] GetLoginLogsRequest request)
    {
        return await Mediator.Send(request);
    }
}