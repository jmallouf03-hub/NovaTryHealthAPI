﻿using Microsoft.AspNetCore.Mvc;
using NovaHealth.Application.Common.Models;
using NovaHealth.Application.Doctor.Commands.AddUpdateDoctorProfile;
using NovaHealth.Application.Doctor.Commands.DeleteDoctorProfile;
using NovaHealth.Application.Doctor.Commands.DeleteDoctorProfilePicture;
using NovaHealth.Application.Doctor.Queries.GetCategoryList;
using NovaHealth.Application.Doctor.Queries.GetDoctorBookOrderListByUserId;
using NovaHealth.Application.Doctor.Queries.GetDoctorByUserId;
using NovaHealth.Application.Doctor.Queries.GetDoctorList;
using NovaHealth.Application.Doctor.Queries.GetDoctorProdutList;
using NovaHealth.Application.Doctor.Queries.GetTotalBookOrderCount;

namespace NovaHealth.WebApi.Controllers;
/// <summary>
/// Controller for managing Doctor.
/// </summary>

public class DoctorController : ApiControllerBase
{
    /// <summary>
    /// Retrieves a category list.
    /// </summary>
    [HttpGet("category-list")]
    public async Task<PaginationResponse<GetCategoryListResponse>> GetCategoryListAsync([FromQuery] GetCategoryListRequest request)
    {
        return await Mediator.Send(request);
    }

    /// <summary>
    /// Retrieves a doctor list.
    /// </summary>
    [HttpGet("doctor-list")]
    public async Task<PaginationResponse<GetDoctorListResponse>> GetDoctorListAsync([FromQuery] GetDoctorListRequest request)
    {
        return await Mediator.Send(request);
    }

    /// <summary>
    /// Deletes a doctor profile.
    /// </summary>
    [HttpDelete("doctor-profile")]
    public async Task<bool> DeleteDoctorProfileAsync([FromQuery] DeleteDoctorProfileRequest request)
    {
        return await Mediator.Send(request);

    }


    /// <summary>
    /// Add update doctor profile.
    /// </summary>

    [HttpPost("add-Update-doctor-profile")]
    public async Task<bool> AddUpdateDoctorProfileAsync([FromForm] AddUpdateDoctorProfileRequest request)
    {
        return await Mediator.Send(request);
    }

    /// <summary>
    /// Get doctor profile by userId
    /// </summary>
    [HttpGet("doctor-profile")]
    public async Task<GetDoctorByUserIdResponse> GetDoctorByUserIdAsync([FromQuery] GetDoctorByUserIdRequest request)
    {
        return await Mediator.Send(request);
    }


    /// <summary>
    /// Retrieves a doctor order list.
    /// </summary>
    [HttpGet("product-list")]
    public async Task<PaginationResponse<GetDoctorProdcutListResponse>> GetDoctorProdutListAsync([FromQuery] GetDoctorProductListRequest request)
    {
        return await Mediator.Send(request);
    }

    /// <summary>
    /// Doctor Order By UserId. 
    /// </summary>
    [HttpGet("doctor-book-order")]
    public async Task<PaginationResponse<GetDoctorBookOrderListByUserIdResponse>> GetDoctorBookOrderListByUserIdListAsync([FromQuery] GetDoctorBookOrderListByUserIdRequest request)
    {
        return await Mediator.Send(request);
    }

    /// <summary>
    ///  Retrieves a total count of book order. 
    /// </summary>
    [HttpGet("book-order-count")]
    public async Task<GetTotalBookOrderCountResponse> GetTotalBookOrderCountAsync()
    {
        return await Mediator.Send(new GetTotalBookOrderCountRequest());
    }



    /// <summary>
    /// Deletes a profile picture.
    /// </summary>
    [HttpDelete("profile-picture")]
    public async Task<bool> DeleteDoctorProfilePictureAsync([FromQuery] DeleteDoctorProfilePictureRequest request)
    {
        return await Mediator.Send(request);
    }
}
