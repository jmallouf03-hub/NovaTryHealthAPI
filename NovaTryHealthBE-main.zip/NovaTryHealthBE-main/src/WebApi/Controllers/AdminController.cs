﻿using Microsoft.AspNetCore.Mvc;
using NovaHealth.Application.Admin.Command.ChangePatientStatus;
using NovaHealth.Application.AdminDashboard.Queries.ChangeDoctorStatus;
using NovaHealth.Application.AdminDashboard.Queries.GetMessageListByAdminId;
using NovaHealth.Application.AdminDashboard.Queries.GetTotalDoctorCount;
using NovaHealth.Application.AdminDashboard.Queries.GetMessageListByUserId;
using NovaHealth.Application.AdminDashboard.Queries.GetPatientTimelineForAdmin;
using NovaHealth.Application.AdminDashboard.Queries.GetAdminDetailByUserId;
using NovaHealth.Application.AdminDashboard.Queries.GetSupportMessageByAdminId;
using NovaHealth.Application.AdminDashboard.Queries.PatientListCount;
using NovaHealth.Application.AdminDashboard.Queries.TotalPayment;

namespace NovaHealth.WebApi.Controllers;

/// <summary>
/// Controller for managing Admin.
/// </summary>
public class AdminController : ApiControllerBase
{

    /// <summary>
    /// Change patient status.
    /// </summary>
    [HttpPut("patient-status/{userId}")]
    public async Task<bool> ChangePatientStatusAsync(long userId, bool isDisabledByAdmin)
    {
        return await Mediator.Send(new ChangePatientStatusRequest
        {
            UserId = userId,
            IsDisabledByAdmin = isDisabledByAdmin
        });
    }

    /// <summary>
    /// Change doctor status.
    /// </summary>
    [HttpPut("doctor-status/{userId}")]
    public async Task<bool> ChangeDoctorStatusAsync(long userId, bool isDisabledByAdmin)
    {
        return await Mediator.Send(new ChangesDoctorStatusRequest
        {
            UserId = userId,
            IsDisabledByAdmin = isDisabledByAdmin
        });
    }

    /// <summary>
    ///  Retrieves a total count of doctor. 
    /// </summary>
    [HttpGet("doctor-count")]
    public async Task<GetTotalDoctorCountResponse> GetTotalDoctorCountAsync()
    {
        return await Mediator.Send(new GetTotalDoctorCountRequest());
    }


    /// <summary>
    /// Retrieves a message by its adminId.
    /// </summary>
    [HttpGet("message-List")]
    public async Task<GetMessageListByAdminIdResponse> GetMessageListByAdminIdAsync([FromQuery] GetMessageListByAdminIdRequest request)
    {
        return await Mediator.Send(request);
    }


    /// <summary>
    /// Retrieves a message by its role type.
    /// </summary>
    //[HttpGet("message-role-type")]
    //public async Task<PaginationResponse<GetMessageListByRoleTypeRespose>> GetMessageListByRoleTypeAsync([FromQuery] GetMessageListByRoleTypeRequest request)
    //{
    //    return await Mediator.Send(request);
    //}

    /// <summary>
    /// Retrieves a message by its superparentId.
    /// </summary>
    [HttpGet("messages")]
    public async Task<List<GetMessageListByUserIdResponse>> GetMessageListByUserIdAsync(long SuperParentMessageId, long UserId)
    {
        return await Mediator.Send(new GetMessageListByUserIdRequest
        {
            SuperParentMessageId = SuperParentMessageId,

            UserId = UserId
        });
    }


    /// <summary>
    /// Retrieves a Patient Time line.
    /// </summary>
    [HttpGet("patient-time-line")]
    public async Task<List<GetPatientTimelineForAdminResponse>> GetPatientTimelineForAdminAsync([FromQuery] GetPatientTimelineForAdminRequest request)
    {
        return await Mediator.Send(request);
    }

    /// <summary>
    /// Get admin profile by userId
    /// </summary>
    [HttpGet("admin-profile")]
    public async Task<GetAdminDetailByUserIdResponse> GetAdminDetailByUserIdAsync([FromQuery] GetAdminDetailByUserIdRequest request)
    {
        return await Mediator.Send(request);
    }


    /// <summary>
    /// Retrieves a message by its supportId.
    /// </summary>
    [HttpGet("support-message-List")]
    public async Task<GetSupportMessageByAdminIdResponse> GetSupportMessageByAdminIdAsync([FromQuery] GetSupportMessageByAdminIdRequest request)
    {
        return await Mediator.Send(request);
    }


    /// <summary>
    /// Get patient total count.
    /// </summary>
    [HttpGet("patient-count")]
    public async Task<PatientListCountResponse> PatientListCountAsync()
    {
        return await Mediator.Send(new PatientListCountRequest());

    }

    /// <summary>
    /// Get total payment.
    /// </summary>
    [HttpGet("total-payment")]
    public async Task<TotalPaymentResponse> TotalPaymentAsync()
    {
        return await Mediator.Send(new TotalPaymentRequest());
    }

}