﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using NovaHealth.Application.Common.Models;
using NovaHealth.Application.Identity.Queries.GetEmailType;
using NovaHealth.Application.Users.Command.AdminChangeStatus;
using NovaHealth.Application.Users.Command.ChangeUserPassword;
using NovaHealth.Application.Users.Command.CreateUserPassword;
using NovaHealth.Application.Users.Command.ForgotUserPassword;
using NovaHealth.Application.Users.Command.SignUpUsers;

namespace NovaHealth.WebApi.Controllers;

/// <summary>
/// Controller for managing users.
/// </summary>
public class UsersController : ApiControllerBase
{
    /// <summary>
    /// Create a password for a user.
    /// </summary>
    [AllowAnonymous]
    [HttpPut("create-password")]
    public async Task<bool> CreatePasswordAsync(CreateUserPasswordRequest request)
    {
        return await Mediator.Send(request);
    }

    /// <summary>
    /// Adds or updates a user for registration.
    /// </summary>
    [HttpPost("user-sign-up")]
    [AllowAnonymous]
    public async Task<bool> UserSignUpAsync(SignUpUserRequest request)
    {
        return await Mediator.Send(request);
    }

    /// <summary>
    /// change user password.
    /// </summary>
    [HttpPut("change-password")]
    public async Task<bool> ChangePasswordAsync(ChangeUserPasswordRequest request)
    {
        return await Mediator.Send(request);
    }

    /// <summary>
    /// Create a password for a user.
    /// </summary>
    [HttpPut("change-status")]
    public async Task<bool> ChangeStatusAsync(AdminChangeStatusRequest request)
    {
        return await Mediator.Send(request); 
    }

    /// <summary>
    /// Check if email exists (POST method to avoid URL encoding issues).
    /// </summary>
    [HttpPost("check-email")]
    [AllowAnonymous]
    public async Task<bool> PostEmailAsync([FromBody] EmailRequest request)
    {
        return await Mediator.Send(new GetEmailTypeRequest(request.Email));
    }

    /// <summary>
    /// forgot  user password.
    /// </summary>
    [HttpPost("forgot-user-password")]
    [AllowAnonymous]
    public async Task<bool> ForgotUserPasswordAsync([FromBody] ForgotUserPasswordRequest request)
    {
        return await Mediator.Send(request);
    }

}