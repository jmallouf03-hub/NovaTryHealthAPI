﻿using NovaHealth.Application.GoogleCalendar.Commands.AuthorizeGoogle;
using NovaHealth.Application.GoogleCalendar.Commands.StartGoogleAuthentication;
using Microsoft.AspNetCore.Mvc;

namespace NovaHealth.WebApi.Controllers;

/// <summary>
/// Handles operations related to Google Calendar appointments.
/// </summary>
[Route("api/google-calendar")]
public class GoogleCalendarController : ApiControllerBase
{
    /// <summary>
    /// Starts the Google authentication process.
    /// </summary>
    [HttpPost("start-authentication")]
    public async Task<IActionResult> StartAuthentication(StartGoogleAuthenticationRequest request)
    {
        var url = await Mediator.Send(request);
        return Ok(new { url });
    }

    /// <summary>
    /// Authorizes a user with Google using the provided request parameters.
    /// </summary>
    [HttpGet("authorize-google")]
    public async Task<IActionResult> AuthorizeGoogle([FromQuery] AuthorizeGoogleRequest request)
    {
        var result = await Mediator.Send(request);

        if (result == true)
        {
            return Redirect("https://calendar.google.com");
        }

        return Ok(result);
    }
}