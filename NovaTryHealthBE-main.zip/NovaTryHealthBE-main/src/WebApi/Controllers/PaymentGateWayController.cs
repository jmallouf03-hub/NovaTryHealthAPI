﻿using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using NovaHealth.Application.PaymentGateway.Commands.CreateCheckoutSession;

namespace NovaHealth.WebApi.Controllers;

/// <summary>
/// Provides functionality to manage and process payment gateway operations.
/// </summary>

public class PaymentGateWayController : ApiControllerBase
{
    /// <summary>
    /// Creates a checkout session for processing payments.
    /// </summary>
    [HttpPost("create-checkout-session")]
    [AllowAnonymous]
    public async Task<CreateCheckoutSessionResponse> CreateCheckoutSessionAsync(CreateCheckoutSessionRequest request)
    {
        return await Mediator.Send(request);
    }
}
