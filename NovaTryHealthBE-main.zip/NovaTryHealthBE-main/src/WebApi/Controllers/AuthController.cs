﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using NovaHealth.Application.Identity.Command.GoogleSignIn;
using NovaHealth.Application.Identity.Command.ResetPassword;
using NovaHealth.Application.Identity.Commands.OTPVerification;
using NovaHealth.Application.Identity.Commands.ResendOtp;
using NovaHealth.Application.Identity.Queries.GetIdentity;
using NovaHealth.Application.Identity.Tokens.MagicTokan.SendMagicLoginLink;
using NovaHealth.Application.Identity.Tokens.MagicTokan.SendMagicLinkOTP;
using NovaHealth.Application.Identity.Tokens.MagicTokan.GenerateMagicLinkToken;
using NovaHealth.Application.Identity.Tokens.Queries.GetToken;
using NovaHealth.Application.Identity.Tokens.Queries.RefreshToken;
using NovaHealth.Application.Identity.Tokens.Services;



namespace NovaHealth.WebApi.Controllers;

/// <summary>
/// Controller for managing Authentication.
/// </summary>
public class AuthController : ApiControllerBase
{
    /// <summary>
    /// User login.
    /// </summary>
    [HttpPost("[action]")]
    [AllowAnonymous]
    public async Task<GetIdentityResponse> SignIn(GetIdentityRequest tokenRequest)
    {
        return await Mediator.Send(tokenRequest);
    }

    /// <summary>
    /// Get the token after Sign-in.
    /// </summary>
    [HttpPost("token")]
    [AllowAnonymous]
    public async Task<GetTokenResponse> GetTokenAsync(GetTokenRequest tokenRequest)
    {
        return await Mediator.Send(tokenRequest);
    }

    /// <summary>
    /// Reset password.
    /// </summary>
    [HttpPut("reset-password")]
    [AllowAnonymous]
    public async Task<bool> ResetPasswordAsync(ResetPasswordRequest request)
    {
        return await Mediator.Send(request);
    }

    /// <summary>
    /// Refresh token if the access token is invalid.
    /// </summary>
    [HttpPost("refresh")]
    [AllowAnonymous]
    public async Task<RefreshTokenResponse> RefreshAsync(RefreshTokenRequest request)
    {
        return await Mediator.Send(request);
    }

    /// <summary>
    /// Send otp to user verification
    /// </summary>
    [HttpPost("otp-verification")]
    [AllowAnonymous]
    public async Task<OTPVerificationResponse> SignWithTokenAsync([FromBody] OTPVerificationRequest request)
    {
        return await Mediator.Send(request);
    }

    /// <summary>
    /// Resend otp to user verification
    /// </summary>
    [HttpPost("resend-otp-verification")]
    [AllowAnonymous]
    public async Task<ResendOtpResponse> ResendOtpAsync([FromBody] ResendOtpRequest request)
    {
        return await Mediator.Send(request);
    }

    /// <summary>
    /// Google sign in.
    /// </summary>
    [HttpPost("google-signIn")]
    [AllowAnonymous]
    public async Task<GoogleSignInResponse> GoogleLogin([FromBody] GoogleSignInRequest request)
    {
        return await Mediator.Send(request);
    }

    /// <summary>
    /// Sends a magic login link to the user's email.
    /// </summary>
    [AllowAnonymous]
    [HttpPost("send-magic-link")]
    public async Task<bool> SendMagicLoginLink([FromBody] SendMagicLoginLinkRequest request)
    {
        return await Mediator.Send(request);

    }

    /// <summary>
    /// Sends a magic link OTP to the user's email.
    /// </summary>
    [AllowAnonymous]
    [HttpPost("send-magic-link-otp")]
    public async Task<SendMagicLinkOtpResponse> SendMagicLinkOtpAsync([FromBody] SendMagicLinkOtpRequest request)
    {
        return await Mediator.Send(request);
    }

    /// <summary>
    /// Generates a token for magic login link.
    /// </summary>
    [AllowAnonymous]
    [HttpPost("generate-magic-login-token")]
    public async Task<TokenResponse> GenerateMagicLoginTokenAsync([FromQuery] GenerateMagicLinkTokenRequest request)
    {
        return await Mediator.Send(request);

    }

    /// <summary>
    /// Generates a new GUID.
    /// </summary>
    [AllowAnonymous]
    [HttpGet("create-clientId")]
    public IActionResult CreateClientIdAsync()
    {
        var newGuid = Guid.NewGuid().ToString();
        return  Ok(new { ClientId = newGuid });
    }


}