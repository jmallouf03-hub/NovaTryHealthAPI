﻿using Microsoft.AspNetCore.Mvc;
using NovaHealth.Application.Common.Models;
using NovaHealth.Application.LayoutSettings.Command.UpdateLayoutSettings;
using NovaHealth.Application.LayoutSettings.Queries.GetLayoutSettings;
using NovaHealth.Application.LayoutSettings.Queries.GetQuestionTemplateList;
using NovaHealth.Application.Questionnaires.Queries.GetQuestionnaireWebDomainList;

namespace NovaHealth.WebApi.Controllers;

/// <summary>
/// Controller for managing layout settings
/// </summary>
public class LayoutSettingController :ApiControllerBase
{

    /// <summary>
    /// Update layout settings for a specific layout ID.
    /// </summary>

    [HttpPut("Layout-Settings")]
    public async Task<bool> UpdatelayoutSettingAsync([FromForm] LayoutSettingRequest request)
    {
        return await Mediator.Send(request);
    }

    /// <summary>
    /// Get layout settings by layout ID.   
    /// </summary>
    [HttpGet("Layout-Settings")]
    public async Task<GetLayoutSettingResponse> GetLayoutSettingAsync([FromQuery] GetLayoutSettingByLayoutIdRequest request)
    {
        return await Mediator.Send(request);
    }

    /// <summary>
    /// Retrieves a question template list.
    /// </summary>
    [HttpGet("template-name")]
    public async Task<PaginationResponse<GetQuestionTemplateListResponse>> GetQuestionTemplateListAsync([FromQuery] GetQuestionTemplateListRequest request)
    {
        return await Mediator.Send(request);
    }
}
