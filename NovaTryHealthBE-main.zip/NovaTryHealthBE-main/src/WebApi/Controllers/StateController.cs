﻿using Microsoft.AspNetCore.Mvc;
using NovaHealth.Application.Common.Models;
using NovaHealth.Application.States.Queries.GetStateList;

namespace NovaHealth.WebApi.Controllers;
/// <summary>
/// Controller for managing state.
/// </summary>
public class StateController : ApiControllerBase
{
    /// <summary>
    /// Retrieves a state list.
    /// </summary>
    [HttpGet("states-list")]
    public async Task<PaginationResponse<GetStateListResponse>> GetStateListAsync([FromQuery] GetStateListRequest request)
    {
        return await Mediator.Send(request);
    }
}
