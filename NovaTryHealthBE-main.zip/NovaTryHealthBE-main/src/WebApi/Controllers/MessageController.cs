﻿using Microsoft.AspNetCore.Mvc;
using NovaHealth.Application.Common.Models;
using NovaHealth.Application.Messaging.Command.MarkReadMessage;
using NovaHealth.Application.Messaging.Commands.SendMessage;
using NovaHealth.Application.Messaging.Queries.GetMessageListByUserId;
using NovaHealth.Application.Messaging.Queries.GetMessageUnreadCount;
using NovaHealth.Application.Messaging.Queries.GetUnreadMessageCount;

namespace NovaHealth.WebApi.Controllers;

/// <summary>
/// Controller for managing messages.
/// </summary>
public class MessageController : ApiControllerBase
{
    /// <summary>
    /// send message.
    /// </summary>
    [HttpPost("send-messages")]
    public async Task<SendMessageResponse> SendMessageAsync([FromForm] SendMessageRequest request)
    {
        return await Mediator.Send(request);
    }

    /// <summary>
    /// send message read.
    /// </summary>
    [HttpPost("send-message-Read")]
    public async Task<bool> MarkReadMessageAsync(MarkReadMessageRequest request)
    {
        return await Mediator.Send(request);
    }

    ///<summary>
    /// Retrieves a count of Unread Message.
    /// </summary>
    [HttpGet("Unread-count")]
    public async Task<GetMessageUnreadCountResponse> GetMessageUnreadCountAsync(long userId)
    {
        return await Mediator.Send(new GetMessageUnreadCountRequest
        {
            UserId = userId,
        });
    }

    /// <summary>
    /// Retrieves a message by its usersId.
    /// </summary>
    [HttpGet("message-List")]
    public async Task<List<GetMessageListByUserIdResponse>> GetMessageListByUserIdAsync([FromQuery] GetMessageListByUserIdRequest request)
    {
        return await Mediator.Send(request);
    }
}
