﻿using Microsoft.AspNetCore.Mvc;
using NovaHealth.Application.Common.Models;
using NovaHealth.Application.Patient.Command.AddPatientGoal;
using NovaHealth.Application.Patient.Command.AddPatientProfile;
using NovaHealth.Application.Patient.Command.SignUpPatient;
using NovaHealth.Application.Patient.Queries.GetPatientByUserId;
using NovaHealth.Application.Patient.Queries.GetPatientGoalList;
using NovaHealth.Application.Patient.Queries.GetPatientList;
using NovaHealth.Application.Patient.Queries.GetPatientMetricList;
using NovaHealth.Application.Patient.Queries.GetPatientOrderCount;
using NovaHealth.Application.Patient.Queries.GetPatientOrderList;
using NovaHealth.Application.Patient.Queries.GetPatientQuestionnaire;
using NovaHealth.Application.Patient.Queries.GetPatientTreatmentTypeList;

namespace NovaHealth.WebApi.Controllers;

/// <summary>
/// Controller for managing patient
/// </summary>
public class PatientController : ApiControllerBase
{
    /// <summary>
    /// Retrieves a list of patient.
    /// </summary>
    [HttpGet("patient-list")]
    public async Task<PaginationResponse<GetPatientListResponse>> GetPatientInformationListAsync([FromQuery] GetPatientListRequest request)
    {
        return await Mediator.Send(request);
    }


    /// <summary>
    /// Add  patient profile.
    /// </summary>

    [HttpPost("add-patient-profile")]
    public async Task<bool> AddPatientProfileAsync([FromForm]AddPatientProfileRequest request)
    {
        return await Mediator.Send(request);
    }

    /// <summary>
    /// Add  patient goal.
    /// </summary>

    [HttpPost("add-patient-goal")]
    public async Task<bool> AddPatientGoalAsync(AddPatientGoalRequest request)
    {
        return await Mediator.Send(request);
    }

    /// <summary>
    /// Retrieves a treatment type.
    /// </summary>
    [HttpGet("treatment-type")]
    public async Task<PaginationResponse<GetPatientTreatmentTypeListResponse>> GetPatientTreatmentTypeListAsync([FromQuery] GetPatientTreatmentTypeListRequest request)
    {
        return await Mediator.Send(request);
    }

    /// <summary>
    /// Retrieves a metric name.
    /// </summary>
    [HttpGet("metric")]
    public async Task<PaginationResponse<GetPatientMetricListResponse>> GetPatientMetricListAsync([FromQuery] GetPatientMetricListRequest request)
    {
        return await Mediator.Send(request);
    }

    /// <summary>
    /// Retrieves a goal list.
    /// </summary>
    [HttpGet("patient-goal-list")]
    public async Task<PaginationResponse<GetPatientGoalListResponse>> GetPatientGoalListAsync([FromQuery] GetPatientGoalListRequest request)
    {
        return await Mediator.Send(request);
    }

    // <summary>
    ///  Retrieves the total count of a patient's book orders. 
    /// </summary>
    [HttpGet("patient-order-count")]
  
    public async Task<GetPatientOrderCountResponse> GetPatientOrderCountAsync([FromQuery] GetPatientOrderCountRequest request)
    {
        return await Mediator.Send(request);
    }


    /// <summary>
    /// Patient Sign Up.
    /// </summary>

    [HttpPost("patient-signUp")]
    public async Task<SignUpPatientResponse> PatientSignUpAsync(SignUpPatientRequest request)
    {
        return await Mediator.Send(request);
    }

    /// <summary>
    /// Get patient profile by userId
    /// </summary>
    [HttpGet("patient-profile")]
    public async Task<GetPatientByUserIdResponse> GetPatientByUserIdAsync([FromQuery] GetPatientByUserIdRequest request)
    {
        return await Mediator.Send(request);
    }


    /// <summary>
    /// Get patient questionnaire answers
    /// </summary>
    [HttpGet("patient-questionnaire")]
    public async Task<GetPatientDetailQuestionnaireResponse> GetPatientQuestionnaireAsync([FromQuery] GetPatientQuestionnaireRequest request)
    {
        return await Mediator.Send(request);
    }

    /// <summary>
    /// Get Patient detail By UserId. 
    /// </summary>
    [HttpGet("order-book")]
    public async Task<PaginationResponse<GetPatientOrderListResponse>> GetPatientOrderListAsync([FromQuery] GetPatientOrderListRequest request)
    {
        return await Mediator.Send(request);
    }
}