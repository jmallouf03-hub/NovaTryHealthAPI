﻿using Microsoft.AspNetCore.Mvc;
using NovaHealth.Application.Common.Models;
using NovaHealth.Application.Products.AddUpdateProducts;
using NovaHealth.Application.Products.Command.AddUpdateProducts;
using NovaHealth.Application.Products.Command.DeleteProduct;
using NovaHealth.Application.Products.Command.DeleteProductIngredients;
using NovaHealth.Application.Products.Command.DeleteProductVariants;
using NovaHealth.Application.Products.Queries.GetBrowseProductList;
using NovaHealth.Application.Products.Queries.GetProductById;
using NovaHealth.Application.Products.Queries.GetProductByIds;
using NovaHealth.Application.Products.Queries.GetProductList;
using NovaHealth.Application.Products.Queries.GetTotalProductCount;

namespace NovaHealth.WebApi.Controllers;

/// <summary>
/// Controller for managing product
/// </summary>
public class ProductController : ApiControllerBase
{
    /// <summary>
    /// Add or update user product.
    /// </summary>

    [HttpPost("add-update-product")]
    public async Task<AddUpdateProductResponse> AddUpdateProductsAsync([FromForm] AddUpdateProductRequest request)
    {
        return await Mediator.Send(request);
    }

    /// <summary>
    /// Get product by productId.
    /// </summary>
    [HttpGet("product")]
    public async Task<GetProductByIdsResponse> GetProductByIdAsync(long ProductId)
    {
        return await Mediator.Send(new GetProductByIdRequest
        {
            ProductId = ProductId,
        });
    }

    /// <summary>
    /// Deletes a product variant.
    /// </summary>
    [HttpDelete("product-variant")]
    public async Task<bool> DeleteProductVariantsAsync([FromQuery] DeleteProductVariantRequest request)
    {
        return await Mediator.Send(request);

    }

    /// <summary>
    /// Deletes a product ingredients.
    /// </summary>
    [HttpDelete("product-ingredients")]
    public async Task<bool> DeleteProductIngredientsAsync([FromQuery] DeleteProductIngredientRequest request)
    {
        return await Mediator.Send(request);

    }

    /// <summary>
    /// Retrieves a list of product.
    /// </summary>
    [HttpGet("product-list")]
    public async Task<PaginationResponse<GetProductListResponse>> GetPatientInformationListAsync([FromQuery] GetProductListRequest request)
     {
        return await Mediator.Send(request);
    }

    /// <summary>
    ///  Retrieves a total count of product. 
    /// </summary>
    [HttpGet("product-count")]
    public async Task<GetTotalProductCountResponse> GetTotalProductCountAsync()
    {
        return await Mediator.Send(new GetTotalProductCountRequest());
    }

    /// <summary>
    /// Retrieves a list of browse product.
    /// </summary>
    [HttpGet("browse-product-list")]
    public async Task<PaginationResponse<GetBrowseProductListResponse>> GetBrowseProductListAsync([FromQuery] GetBrowseProductListRequest request)
    {
        return await Mediator.Send(request);
    }

    /// <summary>
    /// Get products by product Ids.
    /// </summary>
    [HttpGet("products")]
    public async Task<List<GetProductsByIdsResponse>> GetProductsByIdsAsync([FromQuery] GetProductByIdsRequest request)
    {
        return await Mediator.Send(request); 

    }

    /// <summary>
    /// Deletes a product.
    /// </summary>
    [HttpDelete("product")]
    public async Task<bool> DeleteProductAsync([FromQuery] DeleteProductRequest request)
    {
        return await Mediator.Send(request);

    }
}
