﻿using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace NovaHealth.WebApi.Controllers;

/// <summary>
/// ApiControllerBase
/// </summary>
[ApiController]
[Route("api/[controller]")]
//[Authorize(Policy = "SameIpPolicy")]
public abstract class ApiControllerBase : ControllerBase
{
    private ISender? _mediator;

    /// <summary>
    /// Mediator
    /// </summary>
    protected ISender Mediator => _mediator ??= HttpContext.RequestServices.GetRequiredService<ISender>();
}