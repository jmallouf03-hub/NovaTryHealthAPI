﻿using Microsoft.AspNetCore.Mvc;
using NovaHealth.Application.Common.Models;
using NovaHealth.Application.Question.Command.DeleteQuestion;
using NovaHealth.Application.Questionnaires.Command.AddUpdateDuplicateQuestionnire;
using NovaHealth.Application.Questionnaires.Command.AddUpdateQuestionnaire;
using NovaHealth.Application.Questionnaires.Command.DeleteQuestionnaire;
using NovaHealth.Application.Questionnaires.Queries.GetQuestionnaireById;
using NovaHealth.Application.Questionnaires.Queries.GetQuestionnaireGlobalLayoutList;
using NovaHealth.Application.Questionnaires.Queries.GetQuestionnaireLanguageList;
using NovaHealth.Application.Questionnaires.Queries.GetQuestionnaireList;
using NovaHealth.Application.Questionnaires.Queries.GetQuestionnaireTreatmentTypeList;
using NovaHealth.Application.Questionnaires.Queries.GetQuestionnaireTypeList;
using NovaHealth.Application.Questionnaires.Queries.GetQuestionnaireWebDomainList;
using NovaHealth.Application.Questions.Command.AddUpdateAnswerQuestion;
using NovaHealth.Application.Questions.Command.AddUpdateDuplicateQuestion;
using NovaHealth.Application.Questions.Command.AddUpdateQuestion;
using NovaHealth.Application.Questions.Command.UpdateQuestionNumber;
using NovaHealth.Application.Questions.Queries.GetNextQuestion;
using NovaHealth.Application.Questions.Queries.GetNextQuestionByProduct;
using NovaHealth.Application.Questions.Queries.GetPreviousQuestion;
using NovaHealth.Application.Questions.Queries.GetQuestionById;
using NovaHealth.Application.Questions.Queries.GetQuestionList;
using NovaHealth.Application.Questions.Queries.GetQuestionSpecialVisitList;
using NovaHealth.Application.Questions.Queries.GetQuestionTypeList;

namespace NovaHealth.WebApi.Controllers;
/// <summary>
/// Controller for managing Questionnaire.
/// </summary>
public class QuestionnaireController : ApiControllerBase
{
    /// <summary>
    /// Retrieves a language list.
    /// </summary>
    [HttpGet("questionnaire-Languages")]
    public async Task<PaginationResponse<GetQuestionnaireLanguageListResponse>>GetQuestionnaireDefaultLanguageListAsync([FromQuery] GetQuestionnaireLanguageListRequest request)
    {
        return await Mediator.Send(request);
    }

    /// <summary>
    /// Retrieves a type list.
    /// </summary>
    [HttpGet("questionnaire-Type")]
    public async Task<PaginationResponse<GetQuestionnaireTypeListResponse>>GetQuestionnaireTypeListAsync([FromQuery] GetQuestionnaireTypeListRequest request)
    {
        return await Mediator.Send(request);
    }

    /// <summary>
    /// Retrieves a treatment type.
    /// </summary>
    [HttpGet("treatment-type")]
    public async Task<PaginationResponse<GetQuestionnaireTreatmentTypeListResponse>> GetQuestionnaireTreatmentTypeListAsync([FromQuery] GetQuestionnaireTreatmentTypeListRequest request)
    {
        return await Mediator.Send(request);
    }

    /// <summary>
    /// Retrieves a global layout list.
    /// </summary>
    [HttpGet("global-layout")]
    public async Task<PaginationResponse<GetQuestionnaireGlobalLayoutListResponse>> GetQuestionnaireGlobalLayoutListAsync([FromQuery] GetQuestionnaireGlobalLayoutListRequest request)
    {
        return await Mediator.Send(request);
    }


    /// <summary>
    /// Add update questionnaire.
    /// </summary>

    [HttpPost("add-Update-questionnaire")]
    public async Task<bool> AddUpdateQuestionnaireAsync([FromBody] AddUpdateQuestionnaireRequest request)
    {
        return await Mediator.Send(request);
    }


    /// <summary>
    /// Get questionnaire by questionnaireId.
    /// </summary>
    [HttpGet("questionnaire")]
    public async Task<GetQuestionnaireByIdResponse> GetQuestionnaireByIdAsync([FromQuery] GetQuestionnaireByIdRequest request)
    {
        return await Mediator.Send(request);
       
    }
    /// <summary>
    ///  Retrieves a list of questionnaires. 
    /// </summary>

    [HttpGet("questionnaire-list")]
    public async Task<PaginationResponse<GetQuestionnaireListResponse>> GetQuestionnaireListAsync([FromQuery] GetQuestionnaireListRequest request)
    {
        return await Mediator.Send(request);
    }
    /// <summary>
    /// Add update question and AnswerOption.
    /// </summary>

    [HttpPost("question-AnswerOption")]
    public async Task<bool> AddUpdateQuestionAsync([FromBody] AddUpdateQuestionRequest request)
    {
        return await Mediator.Send(request);
    }

    /// <summary>
    /// Get question by question Id.
    /// </summary>
    [HttpGet("question")]
    public async Task<Application.Questions.Queries.GetQuestionById.GetQuestionByIdResponse> GetQuestionByIdAsync([FromQuery] GetQuestionByIdRequest request)
    {
        return await Mediator.Send(request);

    }

    /// <summary>
    ///  Retrieves a list of question. 
    /// </summary>
    [HttpGet("question-list")]
    public async Task<QuestionListWithTitleResponse> GetQuestionListAsync([FromQuery] GetQuestionListRequest request)
    {
        return await Mediator.Send(request);
    }


    /// <summary>
    /// Retrieves a web Domain list.
    /// </summary>
    [HttpGet("Web-Domain")]
    public async Task<PaginationResponse<GetQuestionnaireWebDomainListResponse>> GetQuestionnaireWebDomainListAsync([FromQuery] GetQuestionnaireWebDomainListRequest request)
    {
        return await Mediator.Send(request);
    }

    /// <summary>
    /// Retrieves a question type.
    /// </summary>
    [HttpGet("question-type")]
    public async Task<PaginationResponse<GetQuestionTypeListResponse>>GetQuestionTypeListAsync([FromQuery] GetQuestionTypeListRequest request)
    {
        return await Mediator.Send(request);
    }

    /// <summary>
    /// Retrieves a question special visit.
    /// </summary>
    [HttpGet("question-special-visit")]
    public async Task<PaginationResponse<GetQuestionSpecialVisitResponse>> GetQuestionSpecialVisitListAsync([FromQuery] GetQuestionSpecialVisitListRequest request)
    {
        return await Mediator.Send(request);
    }

    /// <summary>
    ///   Questionnaire  delete by  ID.
    /// </summary>
    [HttpDelete("questionnaire")]
    public async Task<bool> QuestionnaireDeleteByIdAsync([FromQuery] QuestionnaireDeleteByIdRequest request)
    {
        return await Mediator.Send(request);
    }

    /// <summary>
    ///   Question  delete by  ID.
    /// </summary>
    [HttpDelete("question")]
    public async Task<bool> QuestionDeleteByIdAsync([FromQuery] QuestionDeleteByIdRequest request)
    {
        return await Mediator.Send(request);
    }



    /// <summary>
    /// Add Duplicate Questionnaire.
    /// </summary>

    [HttpPost("Duplicate-Questionnaire")]
    public async Task<bool> AddDuplicateQuestionnaireAsync([FromQuery] AddDuplicateQuestionnaireRequest request)
    {
        return await Mediator.Send(request);
    }

    /// <summary>
    /// Add  question and AnswerOption.
    /// </summary>

    [HttpPost("question-answer")]
    public async Task<bool> AddUpdateAnswerQuestionAsync([FromBody] AddUpdateAnswerQuestionRequest request)
    {
        return await Mediator.Send(request);
    }


    /// <summary>
    /// Add Duplicate Question.
    /// </summary>

    [HttpPost("Duplicate-Question")]
    public async Task<bool> AddUpdateDuplicateQuestionAsync([FromQuery] AddUpdateDuplicateQuestionRequest request)
    {
        return await Mediator.Send(request);
    }

    /// <summary>
    /// Get next question by question Id.
    /// </summary>
    [HttpPost("Next-Question")]
    public async Task<GetNextQuestionResponse> GetNextQuestionByIdAsync([FromForm] GetNextQuestionByIdRequest request)
    {
        return await Mediator.Send(request);
    }

    /// <summary>
    /// Get  question by  Product ID.
    /// </summary>

    [HttpGet("Next-Question-productId")]
    public async Task<GetNextQuestionByProductIdResponse> GetNextQuestionByProductIdAsync([FromQuery] GetNextQuestionByProductIdRequest request)
    {
        return await Mediator.Send(request);
    }

    /// <summary>
    /// Update question seq number.
    /// </summary>

    [HttpPost("question-Seq-No")]
    public async Task<bool> UpdateQuestionNumberAsync([FromBody] ListUpdateQuestionNumberRequest request)
    {
        return await Mediator.Send(request);
    }

    /// <summary>
    /// Get previous question by question Id.
    /// </summary>
    [HttpGet("previous-Question")]
    public async Task<GetPreviousQuestionResponse> GetPreviousQuestionAsync([FromQuery] GetPreviousQuestionRequest request)
    {
        return await Mediator.Send(request);
    }

}
