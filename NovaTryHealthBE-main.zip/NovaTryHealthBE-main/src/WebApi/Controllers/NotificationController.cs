﻿using Microsoft.AspNetCore.Mvc;
using NovaHealth.Application.Notifications.Commands.AllArchiveNotification;
using NovaHealth.Application.Notifications.Commands.AllReadNotification;
using NovaHealth.Application.Notifications.Commands.ArchiveNotification;
using NovaHealth.Application.Notifications.Commands.ReadNotification;
using NovaHealth.Application.Notifications.Queries.GetArchiveListByUserId;
using NovaHealth.Application.Notifications.Queries.GetNotificationByUserId;
using NovaHealth.Application.Notifications.Queries.GetNotificationCountByUserId;

namespace NovaHealth.WebApi.Controllers;

/// <summary>
/// Controller for managing notifications.
/// </summary>
public class NotificationController : ApiControllerBase
{
    /// <summary>
    /// Retrieves a notification by its userId.
    /// </summary>
    [HttpGet("notification-user-id")]
    public async Task<List<GetNotificationByUserIdResponse>> GetNotificationByUserIdAsync([FromQuery] GetNotificationByUserIdRequest request)
    {
        return await Mediator.Send(request);
    }

    /// <summary>
    /// Total notification count.
    /// </summary>

    [HttpGet("notification-count")]
    public async Task<GetNotificationCountByUserIdResponse> GetNotificationCountByUserIdAsync([FromQuery] GetNotificationCountByUserIdRequest request)
    {
        return await Mediator.Send(request);
    }


    /// <summary>
    /// Notification ReadAndUnread
    /// </summary>
    [HttpPost("Notification-Read")]
    public async Task<bool> ReadNotificationAsync(ReadNotificationRequest request)
    {
        return await Mediator.Send(request);
    }

    /// <summary>
    /// Archieve a notification.
    /// </summary>
    [HttpDelete("notification")]
    public async Task<bool> ArchiveNotificationAsync([FromQuery] ArchieveNotificationRequest request)
    {
        return await Mediator.Send(request);
    }

    /// <summary>
    /// Retrieves a archive notification by its userId.
    /// </summary>
    [HttpGet("archive-notification-user-id")]
    public async Task<List<GetArchiveListByUserIdResponse>> GetArchiveListByUserIdAsync([FromQuery] GetArchiveListByUserIdRequest request)
    {
        return await Mediator.Send(request);
    }

    /// <summary>
    /// All Archieve a notification.
    /// </summary>
    [HttpDelete("all-achieve-notification")]
    public async Task<bool> AllArchiveNotificationAsync([FromQuery] AllArchiveNotificationRequest request)
    {
        return await Mediator.Send(request);
    }

    /// <summary>
    /// All Notification ReadAndUnread
    /// </summary>
    [HttpPost("All-Notification-Read")]
    public async Task<bool> AllReadNotificationAsync(AllReadNotificationRequestRequest request)
    {
        return await Mediator.Send(request);
    }
}