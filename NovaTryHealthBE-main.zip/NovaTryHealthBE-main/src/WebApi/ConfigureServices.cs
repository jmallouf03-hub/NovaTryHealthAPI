﻿using System.Text.Json.Serialization;
using Microsoft.AspNetCore.Mvc;
using NSwag;
using NovaHealth.Application.Common.Interfaces;
//using NovaHealth.Infrastructure.Common.ModelBinders;
using NovaHealth.Infrastructure.Common.Converters;
using NovaHealth.Infrastructure.Persistence;

namespace NovaHealth.WebApi;

/// <summary>
/// Configure Services
/// </summary>
public static class ConfigureServices
{
    /// <summary>
    /// AddWebApiServices
    /// </summary>
    public static IServiceCollection AddWebApiServices(this IServiceCollection services)
    {
        services.AddDatabaseDeveloperPageExceptionFilter();
        services.AddScoped<ICurrentUser, CurrentUser>();
        services.AddHttpContextAccessor();

        services.AddHealthChecks().AddDbContextCheck<NovaHealthDbContext>();

        services.AddRouting(options => options.LowercaseUrls = true);
        services.AddControllers();        //services
        //    .AddControllers(options => { options.ModelBinderProviders.Insert(0, new TcDateTimeModelBinderProvider()); })
        //    .AddJsonOptions(x =>
        //    {
        //        x.JsonSerializerOptions.Converters.Add(new JsonStringEnumConverter());
        //        x.JsonSerializerOptions.Converters.Add(new TcDateTimeNullableConverter());
        //        x.JsonSerializerOptions.Converters.Add(new TcDateTimeConverter());
        //        x.JsonSerializerOptions.DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull;
        //    });

        services.Configure<ApiBehaviorOptions>(options =>
            options.SuppressModelStateInvalidFilter = true);

        services.AddOpenApiDocument(configure =>
        {
            configure.Title = "NovaHealth";
            configure.AddSecurity("bearer", Enumerable.Empty<string>(), new OpenApiSecurityScheme
            {
                Name = "Authorization",
                Type = OpenApiSecuritySchemeType.ApiKey,
                Scheme = "Bearer",
                BearerFormat = "Bearer",
                In = OpenApiSecurityApiKeyLocation.Header,
                Description = "JWT Authorization header using the Bearer scheme. \r\n\r\n Enter 'Bearer' [space] and then your token in the text input below.\r\n\r\nExample: \"Bearer 12345abcdef\"",
            });
        });

        return services;
    }
}