using NovaHealth.Application;
using NovaHealth.Infrastructure;
using NovaHealth.WebApi;
using NovaHealth.Infrastructure.Persistence;
using NovaHealth.Application.SignalR.Interface;
using NovaHealth.Application.SignalR.Queries;
using Twilio.Clients;
using Stripe;
using NovaHealth.Application.Common.Interfaces;
using NovaHealth.WebApi.Services;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddSignalR();
builder.Services.AddSingleton<IUserConnectionManager, UserConnectionManager>();

builder.Services.AddHttpClient();

// Configure CORS
builder.Services.AddCors(options =>
{
    options.AddPolicy("CorsPolicy", builder =>
    { 
        builder
             .AllowAnyMethod()
             .AllowAnyHeader()
             .AllowCredentials()
             .SetIsOriginAllowed(_ => true);
    });
});

builder.Configuration.AddJsonFile("appsettings.json", optional: false, reloadOnChange: true)
    .AddJsonFile($"appsettings.{builder.Environment.EnvironmentName}.json", optional: true, reloadOnChange: true)
    .AddEnvironmentVariables();

// Register logging with Serilog
builder.Services.AddScoped<ITimelineService, TimelineService>();
builder.Services.AddHttpContextAccessor();

builder.Services.AddApplicationServices(builder.Configuration);
builder.Services.AddInfrastructureServices(builder.Configuration);
builder.Services.AddWebApiServices();

// Configure Twilio
builder.Services.AddSingleton<ITwilioRestClient, TwilioRestClient>(serviceProvider =>
{
    var accountSid = builder.Configuration["Twilio:AccountSid"];
    var authToken = builder.Configuration["Twilio:AuthToken"];
    return new TwilioRestClient(accountSid, authToken);
});


builder.RegisterSerilog();
// Build the application
var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.UseDeveloperExceptionPage();
    app.UseMigrationsEndPoint();

    // Initialise and seed database
    using var scope = app.Services.CreateScope();
    var initializer = scope.ServiceProvider.GetRequiredService<NovaHealthDbContextInitializer>();
    await initializer.InitialiseAsync();
}
else
{
    //app.UseExceptionHandler();

    // Initialise and seed database
    using var scope = app.Services.CreateScope();
    var initializer = scope.ServiceProvider.GetRequiredService<NovaHealthDbContextInitializer>();
    await initializer.InitialiseAsync();
}


// Middleware configuration
if (app.Environment.IsDevelopment())
{
    app.UseDeveloperExceptionPage();
    app.UseMigrationsEndPoint();
}

// Use CORS policy

app.UseHttpsRedirection(); // Ensure HTTPS for requests
app.UseCors("CorsPolicy");
app.UseRouting();
app.UseAuthentication();
app.UseAuthorization();


// Add routing and middleware
app.UseHealthChecks("/health");
app.UseStaticFiles();

// Use infrastructure services
app.UseInfrastructure(builder.Configuration);

// Swagger UI configuration
app.UseSwaggerUi(settings =>
{
    settings.Path = "/api";
    settings.DocumentPath = $"/api/specification.json?v={DateTime.Now.Ticks}";

});

// Configure Stripe
StripeConfiguration.ApiKey = builder.Configuration["Stripe:SecretKey"];

app.MapHub<NotificationHub>("/api/notificationHub");

// Map controllers
app.MapControllers();

// Run the application
await app.RunAsync(); 