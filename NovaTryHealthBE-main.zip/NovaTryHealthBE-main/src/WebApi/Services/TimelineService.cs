﻿using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using NovaHealth.Application.Common.Interfaces;
using NovaHealth.Domain.Entities;
using NovaHealth.Shared.Enums;
using System;

namespace NovaHealth.WebApi.Services;

public class TimelineService : ITimelineService
{
    private readonly INovaHealthDbContext _context;

    public TimelineService(INovaHealthDbContext context)
    {
        _context = context;
    }

    public async Task LogTimelineEventAsync(long patientId, TimelineEventType eventType, string title, string description, object metadata = null, string createdBy = "System")
    {
        var timelineEvent = new TimelineEvent
        {
            UserId = patientId,
            EventType = eventType.ToString(),
            Title = title,
            Description = description,
            EventDate = DateTime.UtcNow,
            CreatedBy = createdBy,
            Metadata = metadata != null ? JsonConvert.SerializeObject(metadata) : null
        };

        _context.TimelineEvents.Add(timelineEvent);
        await _context.SaveChangesAsync();
    }

    public async Task<IEnumerable<TimelineEvent>> GetTimelineByPatientAsync(int patientId)
    {
        return await _context.TimelineEvents
            .Where(e => e.UserId == patientId)
            .OrderBy(e => e.EventDate)
            .ToListAsync();
    }
}
