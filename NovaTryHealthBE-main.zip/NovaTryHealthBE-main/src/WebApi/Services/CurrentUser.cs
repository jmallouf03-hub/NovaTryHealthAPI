﻿using System.Security.Claims;
using NovaHealth.Application.Common.Interfaces;

namespace NovaHealth.WebApi;

/// <summary>
/// Current user service
/// </summary>
public class CurrentUser : ICurrentUser
{
    private readonly IHttpContextAccessor _httpContextAccessor;
    private readonly ClaimsPrincipal? _user;

    /// <summary>
    /// Constructor
    /// </summary>
    public CurrentUser(IHttpContextAccessor httpContextAccessor)
    {
        _httpContextAccessor = httpContextAccessor;
        _user = _httpContextAccessor.HttpContext?.User;
    }

    /// <summary>
    /// Name of logged in user
    /// </summary>
    public string? Name => _user?.Identity?.Name;

    /// <summary>
    /// Id of logged in user
    /// </summary>
    public long Id => IsAuthenticated ? long.Parse(_user?.FindFirstValue(ClaimTypes.NameIdentifier) ?? "0") : 0;

    /// <summary>
    /// Email of logged in user
    /// </summary>
    public string? Email => IsAuthenticated ? _user!.FindFirstValue(ClaimTypes.Email) : string.Empty;

    /// <summary>
    /// User is logged in
    /// </summary>
    public bool IsAuthenticated => _user?.Identity?.IsAuthenticated is true;

    /// <summary>
    /// Claims of user
    /// </summary>
    public IEnumerable<Claim>? Claims => _user?.Claims;

    /// <summary>
    /// IpAddress of user on generate token
    /// </summary>
    public string? IpAddress => IsAuthenticated ? _user!.FindFirstValue("IpAddress") : string.Empty;
}