using MailKit.Net.Smtp;
using MailKit.Security;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using MimeKit;
using NovaHealth.Application.Common.Mailing;

namespace NovaHealth.Infrastructure.Mailing;

public class SmtpMailService : IMailService
{
    private readonly MailSettings _settings;
    private readonly ILogger<SmtpMailService> _logger;

    public SmtpMailService(IOptions<MailSettings> settings, ILogger<SmtpMailService> logger)
    {
        _settings = settings.Value;
        _logger = logger;
    }

    public async Task SendAsync(MailRequest request, CancellationToken cancellationToken = default)
    {
        try
        {
            var email = new MimeMessage();

            // From
            email.From.Add(new MailboxAddress(_settings.DisplayName, request.From ?? _settings.From));

            // To
            foreach (string address in request.To)
                email.To.Add(MailboxAddress.Parse(address));

            // Reply To
            if (!string.IsNullOrEmpty(request.ReplyTo))
                email.ReplyTo.Add(new MailboxAddress(request.ReplyToName, request.ReplyTo));

            // Bcc
            if (request.Bcc.Count > 0)
            {
                foreach (var address in request.Bcc.Where(bccValue => !string.IsNullOrWhiteSpace(bccValue)))
                    email.Bcc.Add(MailboxAddress.Parse(address.Trim()));
            }

            // Cc
            if (request.Cc.Count > 0)
            {
                foreach (var address in request.Cc.Where(ccValue => !string.IsNullOrWhiteSpace(ccValue)))
                    email.Cc.Add(MailboxAddress.Parse(address.Trim()));
            }

            // Headers
            foreach (var header in request.Headers)
                email.Headers.Add(header.Key, header.Value);

            // Content
            var builder = new BodyBuilder();
            email.Sender = new MailboxAddress(request.DisplayName ?? _settings.DisplayName, request.From ?? _settings.From);
            email.Subject = request.Subject;
            builder.HtmlBody = request.Body;

            // Create the file attachments for this e-mail message
            //foreach (var attachmentInfo in request.AttachmentData)
            //    builder.Attachments.Add(attachmentInfo.Key, attachmentInfo.Value);




            // Add the logo as an inline LinkedResource
            if (request.AttachmentData != null && request.AttachmentData.ContainsKey("NovaHealthLogo"))
            {
                var logo = builder.LinkedResources.Add("NovaHealthLogo.png", request.AttachmentData["NovaHealthLogo"]);
                logo.ContentId = "NovaHealthLogo";  // This must match the cid in the HTML body
            }

            //// Attach any other files (if applicable)
            //foreach (var attachment in request.AttachmentData.Where(x => x.Key != "NovaHealthLogo"))
            //{
            //    builder.Attachments.Add(attachment.Key, attachment.Value);
            //}
            // Add inline images from InlineAttachments
            if (request.InlineAttachments != null)
            {
                foreach (var inline in request.InlineAttachments)
                {
                    var linkedRes = builder.LinkedResources.Add($"{inline.Key}.png", inline.Value);
                    linkedRes.ContentId = inline.Key; // Ensure CID matches template reference
                    linkedRes.ContentDisposition = new ContentDisposition(ContentDisposition.Inline);
                    linkedRes.ContentType.MediaType = "image";
                    linkedRes.ContentType.Name = $"{inline.Key}.png";
                }
            }



            email.Body = builder.ToMessageBody();

            using var smtp = new SmtpClient();
            await smtp.ConnectAsync(_settings.Host, _settings.Port, SecureSocketOptions.StartTls, cancellationToken);
            await smtp.AuthenticateAsync(_settings.UserName, _settings.Password, cancellationToken);
            await smtp.SendAsync(email, cancellationToken);
            await smtp.DisconnectAsync(true, cancellationToken);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, ex.Message);
        }
    }
}