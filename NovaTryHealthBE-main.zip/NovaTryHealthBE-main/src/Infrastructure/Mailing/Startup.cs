﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace NovaHealth.Infrastructure.Mailing;

internal static class Startup
{
    internal static IServiceCollection AddMailing(this IServiceCollection services, IConfiguration configuration) =>
        services.Configure<MailSettings>(configuration.GetSection(nameof(MailSettings)));
}