﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace NovaHealth.Infrastructure.Migrations
{
    /// <inheritdoc />
    public partial class LayoutSettings : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "LayoutAnswerSettings",
                columns: table => new
                {
                    Id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    LayoutId = table.Column<long>(type: "bigint", nullable: false),
                    AnswerBackgroundColor = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    AnswerTextColor = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    AnswerHighlightColor = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    AnswerOutlineColor = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    CreatedDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    IsActive = table.Column<bool>(type: "bit", nullable: false),
                    IsDeleted = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_LayoutAnswerSettings", x => x.Id);
                    table.ForeignKey(
                        name: "FK_LayoutAnswerSettings_QuestionnaireGlobalLayouts_LayoutId",
                        column: x => x.LayoutId,
                        principalTable: "QuestionnaireGlobalLayouts",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "LayoutFooterSettings",
                columns: table => new
                {
                    Id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    LayoutId = table.Column<long>(type: "bigint", nullable: false),
                    ShowFooter = table.Column<bool>(type: "bit", nullable: false),
                    PrimaryTextColor = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    SecondaryTextColor = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    DividerColor = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    BackgroundColor = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    FooterLogo = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    CompanyName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    PhoneNumber = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    EmailAddress = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    HelpCenterURL = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    CopyrightText = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ShowFooterSocialIcons = table.Column<bool>(type: "bit", nullable: false),
                    FacebookURL = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    InstagramURL = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    TwitterURL = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    LinkedInURL = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    CreatedDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    IsActive = table.Column<bool>(type: "bit", nullable: false),
                    IsDeleted = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_LayoutFooterSettings", x => x.Id);
                    table.ForeignKey(
                        name: "FK_LayoutFooterSettings_QuestionnaireGlobalLayouts_LayoutId",
                        column: x => x.LayoutId,
                        principalTable: "QuestionnaireGlobalLayouts",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateTable(
                name: "LayoutHeaderSettings",
                columns: table => new
                {
                    Id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    LayoutId = table.Column<long>(type: "bigint", nullable: false),
                    NavbarLeftRadius = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    HeaderBackgroundColor = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    HeaderLogo = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    CustomProgressBarSegments = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    BackButtonGlobal = table.Column<bool>(type: "bit", nullable: false),
                    BackButtonOnlyCurrent = table.Column<bool>(type: "bit", nullable: false),
                    ProgressBarColor = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ProgressBarBackgroundColor = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    BackButtonColor = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    HeaderTextColor = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ShowHelpButton = table.Column<bool>(type: "bit", nullable: false),
                    HelpButtonSupportHours = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    HelpButtonColor = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    HelpButtonTextColor = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    CreatedDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    IsActive = table.Column<bool>(type: "bit", nullable: false),
                    IsDeleted = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_LayoutHeaderSettings", x => x.Id);
                    table.ForeignKey(
                        name: "FK_LayoutHeaderSettings_QuestionnaireGlobalLayouts_LayoutId",
                        column: x => x.LayoutId,
                        principalTable: "QuestionnaireGlobalLayouts",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "IX_LayoutAnswerSettings_LayoutId",
                table: "LayoutAnswerSettings",
                column: "LayoutId");

            migrationBuilder.CreateIndex(
                name: "IX_LayoutFooterSettings_LayoutId",
                table: "LayoutFooterSettings",
                column: "LayoutId");

            migrationBuilder.CreateIndex(
                name: "IX_LayoutHeaderSettings_LayoutId",
                table: "LayoutHeaderSettings",
                column: "LayoutId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "LayoutAnswerSettings");

            migrationBuilder.DropTable(
                name: "LayoutFooterSettings");

            migrationBuilder.DropTable(
                name: "LayoutHeaderSettings");
        }
    }
}
