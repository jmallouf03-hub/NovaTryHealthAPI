﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace NovaHealth.Infrastructure.Migrations
{
    /// <inheritdoc />
    public partial class Domain : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Name",
                table: "Questions");

            migrationBuilder.AlterColumn<long>(
                name: "QuestionSpecialVisitId",
                table: "Questions",
                type: "bigint",
                nullable: true,
                oldClrType: typeof(long),
                oldType: "bigint");

            migrationBuilder.AddColumn<long>(
                name: "WebDomainId",
                table: "Questionnaires",
                type: "bigint",
                nullable: false,
                defaultValue: 0L);

            migrationBuilder.CreateIndex(
                name: "IX_Questionnaires_WebDomainId",
                table: "Questionnaires",
                column: "WebDomainId");

            migrationBuilder.AddForeignKey(
                name: "FK_Questionnaires_WebDomains_WebDomainId",
                table: "Questionnaires",
                column: "WebDomainId",
                principalTable: "WebDomains",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Questionnaires_WebDomains_WebDomainId",
                table: "Questionnaires");

            migrationBuilder.DropIndex(
                name: "IX_Questionnaires_WebDomainId",
                table: "Questionnaires");

            migrationBuilder.DropColumn(
                name: "WebDomainId",
                table: "Questionnaires");

            migrationBuilder.AlterColumn<long>(
                name: "QuestionSpecialVisitId",
                table: "Questions",
                type: "bigint",
                nullable: false,
                defaultValue: 0L,
                oldClrType: typeof(long),
                oldType: "bigint",
                oldNullable: true);

            migrationBuilder.AddColumn<string>(
                name: "Name",
                table: "Questions",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");
        }
    }
}
