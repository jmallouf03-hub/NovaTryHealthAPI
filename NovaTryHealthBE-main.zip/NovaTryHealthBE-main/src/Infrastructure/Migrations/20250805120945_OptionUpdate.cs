﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace NovaHealth.Infrastructure.Migrations
{
    /// <inheritdoc />
    public partial class OptionUpdate : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "IsSpecialVisitQuestion",
                table: "Questions");

            migrationBuilder.AddColumn<long>(
                name: "QuestionSpecialVisitId",
                table: "Questions",
                type: "bigint",
                nullable: true,
                defaultValue: 0L);

            migrationBuilder.AlterColumn<string>(
                name: "Text",
                table: "AnswerOptions",
                type: "nvarchar(max)",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)");

            migrationBuilder.AddColumn<long>(
                name: "ProductId",
                table: "AnswerOptions",
                type: "bigint",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_Questions_QuestionSpecialVisitId",
                table: "Questions",
                column: "QuestionSpecialVisitId");

            migrationBuilder.CreateIndex(
                name: "IX_AnswerOptions_ProductId",
                table: "AnswerOptions",
                column: "ProductId");

            migrationBuilder.AddForeignKey(
                name: "FK_AnswerOptions_Products_ProductId",
                table: "AnswerOptions",
                column: "ProductId",
                principalTable: "Products",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_Questions_QuestionSpecialVisits_QuestionSpecialVisitId",
                table: "Questions",
                column: "QuestionSpecialVisitId",
                principalTable: "QuestionSpecialVisits",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_AnswerOptions_Products_ProductId",
                table: "AnswerOptions");

            migrationBuilder.DropForeignKey(
                name: "FK_Questions_QuestionSpecialVisits_QuestionSpecialVisitId",
                table: "Questions");

            migrationBuilder.DropIndex(
                name: "IX_Questions_QuestionSpecialVisitId",
                table: "Questions");

            migrationBuilder.DropIndex(
                name: "IX_AnswerOptions_ProductId",
                table: "AnswerOptions");

            migrationBuilder.DropColumn(
                name: "QuestionSpecialVisitId",
                table: "Questions");

            migrationBuilder.DropColumn(
                name: "ProductId",
                table: "AnswerOptions");

            migrationBuilder.AddColumn<bool>(
                name: "IsSpecialVisitQuestion",
                table: "Questions",
                type: "bit",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AlterColumn<string>(
                name: "Text",
                table: "AnswerOptions",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "",
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldNullable: true);
        }
    }
}
