﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace NovaHealth.Infrastructure.Migrations
{
    /// <inheritdoc />
    public partial class LayoutSetting : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "LayoutTitleSettings",
                columns: table => new
                {
                    Id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    LayoutId = table.Column<long>(type: "bigint", nullable: false),
                    PreHeader = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ShowPreHeader = table.Column<bool>(type: "bit", nullable: false),
                    PreHeaderColor = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    MainHeader = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ShowMainHeader = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    MainHeaderColor = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    SubHeader = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ShowSubHeader = table.Column<bool>(type: "bit", nullable: false),
                    SubHeaderColor = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Banner = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ShowBanner = table.Column<bool>(type: "bit", nullable: false),
                    BannerTextColor = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    BannerBGColor = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ShowBannerIcon = table.Column<bool>(type: "bit", nullable: false),
                    BannerIconColor = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_LayoutTitleSettings", x => x.Id);
                    table.ForeignKey(
                        name: "FK_LayoutTitleSettings_QuestionnaireGlobalLayouts_LayoutId",
                        column: x => x.LayoutId,
                        principalTable: "QuestionnaireGlobalLayouts",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "IX_LayoutTitleSettings_LayoutId",
                table: "LayoutTitleSettings",
                column: "LayoutId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "LayoutTitleSettings");
        }
    }
}
