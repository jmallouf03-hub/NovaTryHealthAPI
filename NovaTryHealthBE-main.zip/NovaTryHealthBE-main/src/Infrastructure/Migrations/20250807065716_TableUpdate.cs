﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace NovaHealth.Infrastructure.Migrations
{
    /// <inheritdoc />
    public partial class TableUpdate : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Questionnaires_QuestionnaireDefaultLanguages_QuestionnaireDefaultLanguageId",
                table: "Questionnaires");

            migrationBuilder.DropForeignKey(
                name: "FK_Questionnaires_WebDomains_WebDomainId",
                table: "Questionnaires");

            migrationBuilder.DropIndex(
                name: "IX_Questionnaires_QuestionnaireDefaultLanguageId",
                table: "Questionnaires");

            migrationBuilder.DropIndex(
                name: "IX_Questionnaires_WebDomainId",
                table: "Questionnaires");

            migrationBuilder.DropColumn(
                name: "BelugaEnabledRX",
                table: "Questionnaires");

            migrationBuilder.DropColumn(
                name: "EnableTranslation",
                table: "Questionnaires");

            migrationBuilder.DropColumn(
                name: "QuestionnaireDefaultLanguageId",
                table: "Questionnaires");

            migrationBuilder.DropColumn(
                name: "Slug",
                table: "Questionnaires");

            migrationBuilder.DropColumn(
                name: "WebDomainId",
                table: "Questionnaires");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<bool>(
                name: "BelugaEnabledRX",
                table: "Questionnaires",
                type: "bit",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddColumn<bool>(
                name: "EnableTranslation",
                table: "Questionnaires",
                type: "bit",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddColumn<long>(
                name: "QuestionnaireDefaultLanguageId",
                table: "Questionnaires",
                type: "bigint",
                nullable: false,
                defaultValue: 0L);

            migrationBuilder.AddColumn<string>(
                name: "Slug",
                table: "Questionnaires",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<long>(
                name: "WebDomainId",
                table: "Questionnaires",
                type: "bigint",
                nullable: false,
                defaultValue: 0L);

            migrationBuilder.CreateIndex(
                name: "IX_Questionnaires_QuestionnaireDefaultLanguageId",
                table: "Questionnaires",
                column: "QuestionnaireDefaultLanguageId");

            migrationBuilder.CreateIndex(
                name: "IX_Questionnaires_WebDomainId",
                table: "Questionnaires",
                column: "WebDomainId");

            migrationBuilder.AddForeignKey(
                name: "FK_Questionnaires_QuestionnaireDefaultLanguages_QuestionnaireDefaultLanguageId",
                table: "Questionnaires",
                column: "QuestionnaireDefaultLanguageId",
                principalTable: "QuestionnaireDefaultLanguages",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_Questionnaires_WebDomains_WebDomainId",
                table: "Questionnaires",
                column: "WebDomainId",
                principalTable: "WebDomains",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }
    }
}
