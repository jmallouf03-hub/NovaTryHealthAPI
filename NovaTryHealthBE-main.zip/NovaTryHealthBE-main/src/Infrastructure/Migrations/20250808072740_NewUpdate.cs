﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace NovaHealth.Infrastructure.Migrations
{
    /// <inheritdoc />
    public partial class NewUpdate : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<bool>(
                name: "BelugaEnabledRX",
                table: "Questionnaires",
                type: "bit",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddColumn<string>(
                name: "Slug",
                table: "Questionnaires",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<long>(
                name: "WebDomainId",
                table: "Questionnaires",
                type: "bigint",
                nullable: false,
                defaultValue: 0L);

            migrationBuilder.CreateIndex(
                name: "IX_Questionnaires_WebDomainId",
                table: "Questionnaires",
                column: "WebDomainId");

            migrationBuilder.AddForeignKey(
                name: "FK_Questionnaires_WebDomains_WebDomainId",
                table: "Questionnaires",
                column: "WebDomainId",
                principalTable: "WebDomains",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Questionnaires_WebDomains_WebDomainId",
                table: "Questionnaires");

            migrationBuilder.DropIndex(
                name: "IX_Questionnaires_WebDomainId",
                table: "Questionnaires");

            migrationBuilder.DropColumn(
                name: "BelugaEnabledRX",
                table: "Questionnaires");

            migrationBuilder.DropColumn(
                name: "Slug",
                table: "Questionnaires");

            migrationBuilder.DropColumn(
                name: "WebDomainId",
                table: "Questionnaires");
        }
    }
}
