﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace NovaHealth.Infrastructure.Migrations
{
    /// <inheritdoc />
    public partial class AddQuetionnaireType : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Type",
                table: "Questions");

            migrationBuilder.AddColumn<long>(
                name: "QuestionTypeId",
                table: "Questions",
                type: "bigint",
                nullable: false,
                defaultValue: 0L);

            migrationBuilder.AlterColumn<string>(
                name: "Status",
                table: "Questionnaires",
                type: "nvarchar(max)",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)");

            migrationBuilder.AlterColumn<bool>(
                name: "Mode",
                table: "Questionnaires",
                type: "bit",
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)");

            migrationBuilder.AlterColumn<string>(
                name: "Domain",
                table: "Questionnaires",
                type: "nvarchar(max)",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)");

            migrationBuilder.AddColumn<long>(
                name: "QuestionnaireDefaultLanguageId",
                table: "Questionnaires",
                type: "bigint",
                nullable: false,
                defaultValue: 0L);

            migrationBuilder.AddColumn<long>(
                name: "QuestionnaireGlobalLayoutId",
                table: "Questionnaires",
                type: "bigint",
                nullable: false,
                defaultValue: 0L);

            migrationBuilder.AddColumn<long>(
                name: "QuestionnaireTreatmentTypeId",
                table: "Questionnaires",
                type: "bigint",
                nullable: false,
                defaultValue: 0L);

            migrationBuilder.AddColumn<long>(
                name: "QuestionnaireTypeId",
                table: "Questionnaires",
                type: "bigint",
                nullable: false,
                defaultValue: 0L);

            migrationBuilder.CreateTable(
                name: "QuestionnaireDefaultLanguages",
                columns: table => new
                {
                    Id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    DefaultLanguage = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_QuestionnaireDefaultLanguages", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "QuestionnaireGlobalLayouts",
                columns: table => new
                {
                    Id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    GlobalLayout = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_QuestionnaireGlobalLayouts", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "QuestionnaireTreatmentTypes",
                columns: table => new
                {
                    Id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    TreatmentType = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_QuestionnaireTreatmentTypes", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "QuestionnaireTypes",
                columns: table => new
                {
                    Id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Type = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_QuestionnaireTypes", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "QuestionTypes",
                columns: table => new
                {
                    Id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Type = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_QuestionTypes", x => x.Id);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Questions_QuestionTypeId",
                table: "Questions",
                column: "QuestionTypeId");

            migrationBuilder.CreateIndex(
                name: "IX_Questionnaires_QuestionnaireDefaultLanguageId",
                table: "Questionnaires",
                column: "QuestionnaireDefaultLanguageId");

            migrationBuilder.CreateIndex(
                name: "IX_Questionnaires_QuestionnaireGlobalLayoutId",
                table: "Questionnaires",
                column: "QuestionnaireGlobalLayoutId");

            migrationBuilder.CreateIndex(
                name: "IX_Questionnaires_QuestionnaireTreatmentTypeId",
                table: "Questionnaires",
                column: "QuestionnaireTreatmentTypeId");

            migrationBuilder.CreateIndex(
                name: "IX_Questionnaires_QuestionnaireTypeId",
                table: "Questionnaires",
                column: "QuestionnaireTypeId");

            migrationBuilder.AddForeignKey(
                name: "FK_Questionnaires_QuestionnaireDefaultLanguages_QuestionnaireDefaultLanguageId",
                table: "Questionnaires",
                column: "QuestionnaireDefaultLanguageId",
                principalTable: "QuestionnaireDefaultLanguages",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_Questionnaires_QuestionnaireGlobalLayouts_QuestionnaireGlobalLayoutId",
                table: "Questionnaires",
                column: "QuestionnaireGlobalLayoutId",
                principalTable: "QuestionnaireGlobalLayouts",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_Questionnaires_QuestionnaireTreatmentTypes_QuestionnaireTreatmentTypeId",
                table: "Questionnaires",
                column: "QuestionnaireTreatmentTypeId",
                principalTable: "QuestionnaireTreatmentTypes",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_Questionnaires_QuestionnaireTypes_QuestionnaireTypeId",
                table: "Questionnaires",
                column: "QuestionnaireTypeId",
                principalTable: "QuestionnaireTypes",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_Questions_QuestionTypes_QuestionTypeId",
                table: "Questions",
                column: "QuestionTypeId",
                principalTable: "QuestionTypes",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Questionnaires_QuestionnaireDefaultLanguages_QuestionnaireDefaultLanguageId",
                table: "Questionnaires");

            migrationBuilder.DropForeignKey(
                name: "FK_Questionnaires_QuestionnaireGlobalLayouts_QuestionnaireGlobalLayoutId",
                table: "Questionnaires");

            migrationBuilder.DropForeignKey(
                name: "FK_Questionnaires_QuestionnaireTreatmentTypes_QuestionnaireTreatmentTypeId",
                table: "Questionnaires");

            migrationBuilder.DropForeignKey(
                name: "FK_Questionnaires_QuestionnaireTypes_QuestionnaireTypeId",
                table: "Questionnaires");

            migrationBuilder.DropForeignKey(
                name: "FK_Questions_QuestionTypes_QuestionTypeId",
                table: "Questions");

            migrationBuilder.DropTable(
                name: "QuestionnaireDefaultLanguages");

            migrationBuilder.DropTable(
                name: "QuestionnaireGlobalLayouts");

            migrationBuilder.DropTable(
                name: "QuestionnaireTreatmentTypes");

            migrationBuilder.DropTable(
                name: "QuestionnaireTypes");

            migrationBuilder.DropTable(
                name: "QuestionTypes");

            migrationBuilder.DropIndex(
                name: "IX_Questions_QuestionTypeId",
                table: "Questions");

            migrationBuilder.DropIndex(
                name: "IX_Questionnaires_QuestionnaireDefaultLanguageId",
                table: "Questionnaires");

            migrationBuilder.DropIndex(
                name: "IX_Questionnaires_QuestionnaireGlobalLayoutId",
                table: "Questionnaires");

            migrationBuilder.DropIndex(
                name: "IX_Questionnaires_QuestionnaireTreatmentTypeId",
                table: "Questionnaires");

            migrationBuilder.DropIndex(
                name: "IX_Questionnaires_QuestionnaireTypeId",
                table: "Questionnaires");

            migrationBuilder.DropColumn(
                name: "QuestionTypeId",
                table: "Questions");

            migrationBuilder.DropColumn(
                name: "QuestionnaireDefaultLanguageId",
                table: "Questionnaires");

            migrationBuilder.DropColumn(
                name: "QuestionnaireGlobalLayoutId",
                table: "Questionnaires");

            migrationBuilder.DropColumn(
                name: "QuestionnaireTreatmentTypeId",
                table: "Questionnaires");

            migrationBuilder.DropColumn(
                name: "QuestionnaireTypeId",
                table: "Questionnaires");

            migrationBuilder.AddColumn<string>(
                name: "Type",
                table: "Questions",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AlterColumn<string>(
                name: "Status",
                table: "Questionnaires",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "",
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Mode",
                table: "Questionnaires",
                type: "nvarchar(max)",
                nullable: false,
                oldClrType: typeof(bool),
                oldType: "bit");

            migrationBuilder.AlterColumn<string>(
                name: "Domain",
                table: "Questionnaires",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "",
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldNullable: true);
        }
    }
}
