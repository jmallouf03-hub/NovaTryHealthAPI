﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace NovaHealth.Infrastructure.Migrations
{
    /// <inheritdoc />
    public partial class globalsetting : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "QuestionTemplates",
                columns: table => new
                {
                    Id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    TemplateName = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_QuestionTemplates", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "GlobalLayoutSettings",
                columns: table => new
                {
                    Id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    LayoutId = table.Column<long>(type: "bigint", nullable: false),
                    RoundedBoarderRaduis = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    NavigationButtonWidth = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    QuestionTemplateId = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_GlobalLayoutSettings", x => x.Id);
                    table.ForeignKey(
                        name: "FK_GlobalLayoutSettings_QuestionTemplates_QuestionTemplateId",
                        column: x => x.QuestionTemplateId,
                        principalTable: "QuestionTemplates",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_GlobalLayoutSettings_QuestionnaireGlobalLayouts_LayoutId",
                        column: x => x.LayoutId,
                        principalTable: "QuestionnaireGlobalLayouts",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "IX_GlobalLayoutSettings_LayoutId",
                table: "GlobalLayoutSettings",
                column: "LayoutId");

            migrationBuilder.CreateIndex(
                name: "IX_GlobalLayoutSettings_QuestionTemplateId",
                table: "GlobalLayoutSettings",
                column: "QuestionTemplateId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "GlobalLayoutSettings");

            migrationBuilder.DropTable(
                name: "QuestionTemplates");
        }
    }
}
