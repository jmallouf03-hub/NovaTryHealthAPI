﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace NovaHealth.Infrastructure.Migrations
{
    /// <inheritdoc />
    public partial class PatientGoal : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "PatientMetrics",
                columns: table => new
                {
                    Id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    MetricName = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_PatientMetrics", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "PatientTreatmentTypes",
                columns: table => new
                {
                    Id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    TreatmentType = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_PatientTreatmentTypes", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "PatientGoals",
                columns: table => new
                {
                    Id = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    UserId = table.Column<long>(type: "bigint", nullable: false),
                    PatientTreatmentTypeId = table.Column<long>(type: "bigint", nullable: false),
                    PatientMetricId = table.Column<long>(type: "bigint", nullable: false),
                    TargetValuelBsForWeight = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    StartDate = table.Column<DateOnly>(type: "date", nullable: false),
                    EndDate = table.Column<DateOnly>(type: "date", nullable: false),
                    CreatedDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    IsActive = table.Column<bool>(type: "bit", nullable: false),
                    IsDeleted = table.Column<bool>(type: "bit", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_PatientGoals", x => x.Id);
                    table.ForeignKey(
                        name: "FK_PatientGoals_PatientMetrics_PatientMetricId",
                        column: x => x.PatientMetricId,
                        principalTable: "PatientMetrics",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_PatientGoals_PatientTreatmentTypes_PatientTreatmentTypeId",
                        column: x => x.PatientTreatmentTypeId,
                        principalTable: "PatientTreatmentTypes",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_PatientGoals_Users_UserId",
                        column: x => x.UserId,
                        principalTable: "Users",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "IX_PatientGoals_PatientMetricId",
                table: "PatientGoals",
                column: "PatientMetricId");

            migrationBuilder.CreateIndex(
                name: "IX_PatientGoals_PatientTreatmentTypeId",
                table: "PatientGoals",
                column: "PatientTreatmentTypeId");

            migrationBuilder.CreateIndex(
                name: "IX_PatientGoals_UserId",
                table: "PatientGoals",
                column: "UserId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "PatientGoals");

            migrationBuilder.DropTable(
                name: "PatientMetrics");

            migrationBuilder.DropTable(
                name: "PatientTreatmentTypes");
        }
    }
}
