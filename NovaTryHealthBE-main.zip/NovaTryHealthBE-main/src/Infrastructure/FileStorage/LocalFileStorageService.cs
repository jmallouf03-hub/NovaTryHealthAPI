using Microsoft.Extensions.Options;
using NovaHealth.Application;
using NovaHealth.Application.Common.FileStorage;

namespace NovaHealth.Infrastructure.FileStorage;

public class LocalFileStorageService : IFileStorageService
{
    private readonly AppSettings _appSettings;

    public LocalFileStorageService(IOptions<AppSettings> appSettings)
    {
        _appSettings = appSettings.Value;
    }

    public async Task<FileUploadResponse> UploadAsync(FileUploadRequest request, CancellationToken cancellationToken = default)
    {
        var file = request.File;
        var pathToSave = GetFolderPath(_appSettings.ContentRootPath, request.UserId, request.CompanyId, request.FileTypeOption);

        if (!Directory.Exists(pathToSave))
        {
            Directory.CreateDirectory(pathToSave);
        }

        var pathToUpload = GetFolderUploadPath(_appSettings.ContentRootPath, request.UserId, request.CompanyId, request.FileTypeOption);

        var name = Guid.NewGuid().ToString();
        var fileName = file.FileName;
        var extension = Path.GetExtension(fileName);
        var saveFileName = $"{name}{extension}";
        var filePath = Path.Combine(pathToSave, saveFileName);
        var uploadPath = Path.Combine(pathToUpload, name + extension);

        await using var fileStream = new FileStream(filePath, FileMode.Create);
        await file.CopyToAsync(fileStream, cancellationToken);

        return new FileUploadResponse
        {
            Name = saveFileName,
            OriginalName = fileName,
            Extension = extension,
            Size = file.Length,
            SavedTo = uploadPath,
            FileTypeOption = request.FileTypeOption,
            FileStorage = FileStorageOption.Local
        };
    }

    public async Task<FileDownloadResponse> Resolve(FileDownloadRequest request, CancellationToken cancellationToken)
    {
        var name = request.Name;
        var folderPath = GetFolderPath(_appSettings.ContentRootPath, request.UserId, request.CompanyId, request.FileTypeOption);
        var filePath = Path.Combine(folderPath, name);

        if (!File.Exists(filePath))
        {
            return new FileDownloadResponse();
        }

        await using var documentStream = new FileStream(filePath, FileMode.Open, FileAccess.Read);
        var documentData = new byte[documentStream.Length];
        await documentStream.ReadAsync(documentData, 0, (int)documentStream.Length);

        return new FileDownloadResponse
        {
            ImageData = documentData
        };
    }

    private string GetFolderPath(string contentRootPath, long userId, long companyId, FileTypeOption fileTypeOption)
    {
        var rootFolderPath = contentRootPath;
        var userFolderName = userId > 0 ? $"user-{userId}" : "anonymous";

        var companyFolderName = companyId > 0 ? $"company-{companyId}" : "anonymous";
        var folderName = fileTypeOption switch
        {
            FileTypeOption.Documents => Path.Combine("upload", companyFolderName, userFolderName, "documents"),
            _ => Path.Combine("upload", userFolderName, "others"),
        };

        var folderPath = Path.Combine(Directory.GetCurrentDirectory(), rootFolderPath, folderName);

        return folderPath;
    }

    private string GetFolderUploadPath(string contentRootPath, long userId, long stationId, FileTypeOption fileTypeOption)
    {
        var rootFolderPath = contentRootPath;
        var userFolderName = userId > 0 ? $"user-{userId}" : "anonymous";

        var companyFolderName = stationId > 0 ? $"station-{stationId}" : "anonymous";
        var folderName = fileTypeOption switch
        {
            FileTypeOption.Documents => Path.Combine("upload", companyFolderName, userFolderName, "documents"),
            _ => Path.Combine("upload", userFolderName, "others"),
        };

        return folderName;
    }
}