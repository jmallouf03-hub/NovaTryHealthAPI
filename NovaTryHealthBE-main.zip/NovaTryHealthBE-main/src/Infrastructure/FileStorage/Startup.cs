﻿using Microsoft.Extensions.DependencyInjection;
using NovaHealth.Application.Common.FileStorage;

namespace NovaHealth.Infrastructure.FileStorage;

internal static class Startup
{
    internal static IServiceCollection AddFileStorage(this IServiceCollection services)
    {
        services.AddSingleton<LocalFileStorageService>();
        services.AddSingleton<AwsFileStorageService>();
        services.AddSingleton<AzureFileStorageService>();

        services.AddTransient<Func<FileStorageOption?, IFileStorageService>>(serviceProvider =>
        {
            IFileStorageService StorageServiceFunc(FileStorageOption? key = null)
            {
                return key switch
                {
                    FileStorageOption.Aws => serviceProvider.GetService<AwsFileStorageService>()!,
                    FileStorageOption.Azure => serviceProvider.GetService<AzureFileStorageService>()!,
                    _ => serviceProvider.GetService<LocalFileStorageService>()!
                };
            }

            return StorageServiceFunc;
        });

        return services;
    }
}