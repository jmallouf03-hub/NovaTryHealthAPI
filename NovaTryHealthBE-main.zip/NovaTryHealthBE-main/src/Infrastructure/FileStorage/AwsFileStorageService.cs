using NovaHealth.Application.Common.FileStorage;
using Microsoft.AspNetCore.Http;

namespace NovaHealth.Infrastructure.FileStorage;

public class AwsFileStorageService : IFileStorageService
{
    public Task<FileUploadResponse> UploadAsync(FileUploadRequest request, CancellationToken cancellationToken = default)
    {
        throw new NotImplementedException();
    }

    public Task<FileDownloadResponse> Resolve(FileDownloadRequest request, CancellationToken cancellationToken)
    {
        throw new NotImplementedException();
    }
}