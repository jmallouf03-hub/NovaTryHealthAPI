﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using NovaHealth.Application.Common.Caching;

namespace NovaHealth.Infrastructure.Caching;

internal static class Startup
{
    internal static IServiceCollection AddCaching(this IServiceCollection services, IConfiguration config)
    {
        services.Configure<CacheSettings>(config.GetSection(nameof(CacheSettings)));

        var settings = config.GetSection(nameof(CacheSettings)).Get<CacheSettings>();
        if (settings == null)
        {
            return services;
        }

        if (settings.UseDistributedCache)
        {
            if (settings.PreferRedis && !string.IsNullOrEmpty(settings.RedisUrl))
            {
                services.AddStackExchangeRedisCache(options =>
                {
                    options.Configuration = settings.RedisUrl;
                    options.ConfigurationOptions = new StackExchange.Redis.ConfigurationOptions()
                    {
                        AbortOnConnectFail = true,
                        EndPoints = { settings.RedisUrl }
                    };
                });
            }
            else
            {
                services.AddDistributedMemoryCache();
            }

            services.AddTransient<ICacheService, DistributedCacheService>();
        }
        else
        {
            services.AddTransient<ICacheService, LocalCacheService>();
        }

        services.AddMemoryCache();

        return services;
    }
}