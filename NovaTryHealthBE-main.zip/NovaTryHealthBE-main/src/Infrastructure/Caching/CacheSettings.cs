namespace NovaHealth.Infrastructure.Caching;

public class CacheSettings
{
    public bool UseDistributedCache { get; set; }
    
    public bool PreferRedis { get; set; }
    
    public string? RedisUrl { get; set; }
    
    public int ExpiryTimeInMinutes { get; set; }
}