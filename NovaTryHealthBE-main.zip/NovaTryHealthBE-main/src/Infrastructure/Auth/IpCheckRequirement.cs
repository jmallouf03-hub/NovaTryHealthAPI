﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using NovaHealth.Shared.Authorization;

namespace NovaHealth.Infrastructure.Auth;

/// <summary>
/// IpCheckRequirement
/// </summary>
public class IpCheckRequirement : IAuthorizationRequirement
{
    /// <summary>
    /// IpClaimRequired
    /// </summary>
    public bool IpClaimRequired { get; set; } = true;
}

/// <summary>
/// IpCheckHandler
/// </summary>
public class IpCheckHandler : AuthorizationHandler<IpCheckRequirement>
{
    private readonly IHttpContextAccessor _httpContextAccessor;

    /// <summary>
    /// IpCheckHandler
    /// </summary>
    public IpCheckHandler(IHttpContextAccessor httpContextAccessor)
    {
        _httpContextAccessor = httpContextAccessor ?? throw new ArgumentNullException(nameof(httpContextAccessor));
    }

    /// <summary>
    /// HandleRequirementAsync
    /// </summary>
    protected override Task HandleRequirementAsync(AuthorizationHandlerContext context, IpCheckRequirement requirement)
    {
        var ipClaim = context.User.FindFirst(claim => claim.Type == NovaHealthClaims.IpAddress);

        // No claim existing set and and its configured as optional so skip the check
        if (ipClaim == null && !requirement.IpClaimRequired)
        {
            return Task.CompletedTask;
        }

        if (ipClaim != null && ipClaim.Value == _httpContextAccessor.GetIpAddress())
        {
            context.Succeed(requirement);
        }
        else
        {
            // Only call fail, to guarantee a failure, even if further handlers may succeed
            context.Fail();
        }

        return Task.CompletedTask;
    }
}