﻿using NovaHealth.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace NovaHealth.Infrastructure.Persistence.Configurations;

public class UserConfiguration : IEntityTypeConfiguration<User>
{
    public void Configure(EntityTypeBuilder<User> builder)
    {

        builder.ToTable("Users");

        builder.HasKey(x => x.Id);
        builder.Property(x =>x.Id).ValueGeneratedOnAdd();

        builder.Property(x =>x.FirstName).HasMaxLength(15).IsRequired();
        builder.Property(x => x.LastName).HasMaxLength(15).IsRequired();
        builder.Property(x => x.PhoneNumber).HasMaxLength(100);
    }
}