﻿using Microsoft.EntityFrameworkCore.Storage;
using NovaHealth.Application.Common.Interfaces;

namespace NovaHealth.Infrastructure.Persistence;

public class UnitOfWork : IUnitOfWork
{
    private readonly NovaHealthDbContext _novaHealthDbContext;
    private IDbContextTransaction? _transaction;

    public UnitOfWork(NovaHealthDbContext novaHealthDbContext)
    {
        _novaHealthDbContext = novaHealthDbContext;
    }

    public void Dispose()
    {
        if (_transaction == null)
        {
            return;
        }

        _transaction.Dispose();
        _transaction = null;
    }

    public void BeginTransaction()
    {
        if (_transaction != null)
        {
            return;
        }

        _transaction = _novaHealthDbContext.Database.BeginTransaction();
    }

    public void Commit()
    {
        if (_transaction == null)
        {
            return;
        }

        _transaction.Commit();
        _transaction.Dispose();
        _transaction = null;
    }

    public void Rollback()
    {
        if (_transaction == null)
        {
            return;
        }

        _transaction.Rollback();
        _transaction.Dispose();
        _transaction = null;
    }

    public async Task<int> SaveChangesAsync(CancellationToken cancellationToken = default)
    {
        return await _novaHealthDbContext.SaveChangesAsync(cancellationToken);
    }

    public async Task SaveAndCommitAsync(CancellationToken cancellationToken = default)
    {
        await SaveChangesAsync(cancellationToken);

        Commit();
    }
}