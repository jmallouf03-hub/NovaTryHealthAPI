﻿using MediatR;
using Microsoft.EntityFrameworkCore;
using System.Reflection;
using NovaHealth.Domain.Common;
using NovaHealth.Domain.Entities;
using NovaHealth.Infrastructure.Common;
using NovaHealth.Infrastructure.Persistence.Interceptors;
using NovaHealth.Application.Common.Interfaces;

namespace NovaHealth.Infrastructure.Persistence;

public class NovaHealthDbContext : DbContext, INovaHealthDbContext
{
    private readonly IMediator _mediator;
    private readonly AuditableEntitySaveChangesInterceptor _auditableEntitySaveChangesInterceptor;

    public NovaHealthDbContext(DbContextOptions<NovaHealthDbContext> options, IMediator mediator, AuditableEntitySaveChangesInterceptor auditableEntitySaveChangesInterceptor)
        : base(options)
    {
        _mediator = mediator;
        _auditableEntitySaveChangesInterceptor = auditableEntitySaveChangesInterceptor;
    }
    public DbSet<User> Users => Set<User>();

    public DbSet<OTP> OTPs => Set<OTP>();

    public DbSet<Role> Roles => Set<Role>();
    public DbSet<MagicToken> MagicTokens => Set<MagicToken>();

    public DbSet<UserRole> UserRoles => Set<UserRole>();

    public DbSet<PasswordHistory>PasswordHistories => Set<PasswordHistory>();

    public DbSet<LoginLog> LoginLogs => Set<LoginLog>();

    public DbSet<UserAddress> UserAddress => Set<UserAddress>();

    public DbSet<State> States => Set<State>();

    public DbSet<Product> Products => Set<Product>();

    public DbSet<ProductIngredient> ProductIngredients => Set<ProductIngredient>(); 
    public DbSet<ProductVariant> ProductVariants => Set<ProductVariant>();

    public DbSet<Questionnaire> Questionnaires => Set<Questionnaire>();

    public DbSet<AnswerOption> AnswerOptions => Set<AnswerOption>();
    public DbSet<QuestionnaireProduct> QuestionnaireProducts => Set<QuestionnaireProduct>();

    public DbSet<Question> Questions => Set<Question>();

    public DbSet<QuestionnaireType> QuestionnaireTypes => Set<QuestionnaireType>();

    public DbSet<QuestionnaireTreatmentType> QuestionnaireTreatmentTypes => Set<QuestionnaireTreatmentType>();

    public DbSet<QuestionnaireGlobalLayout> QuestionnaireGlobalLayouts => Set<QuestionnaireGlobalLayout>(); 
    
    public DbSet<QuestionnaireDefaultLanguage> QuestionnaireDefaultLanguages => Set<QuestionnaireDefaultLanguage>();

    public DbSet<QuestionType>QuestionTypes => Set<QuestionType>();

    public DbSet<WebDomain> WebDomains => Set<WebDomain>();

    public DbSet<QuestionSpecialVisit> QuestionSpecialVisits => Set<QuestionSpecialVisit>();

    public DbSet<LayoutAnswerSetting> LayoutAnswerSettings => Set<LayoutAnswerSetting>(); 

    public DbSet<LayoutFooterSetting> LayoutFooterSettings => Set<LayoutFooterSetting>();   

    public DbSet<LayoutHeaderSetting> LayoutHeaderSettings => Set<LayoutHeaderSetting>();   


    public DbSet<PatientGoal> PatientGoals => Set<PatientGoal>();

    public DbSet<PatientMetric> PatientMetrics => Set<PatientMetric>();

    public DbSet<PatientTreatmentType> PatientTreatmentTypes => Set<PatientTreatmentType>();

    public DbSet<LayoutTitleSetting> LayoutTitleSettings => Set<LayoutTitleSetting>();

    public DbSet<QuestionProduct> QuestionProducts => Set<QuestionProduct>();
    public DbSet<BookOrder> BookOrders => Set<BookOrder>();

    public DbSet<GlobalLayoutSetting> GlobalLayoutSettings => Set<GlobalLayoutSetting>();

    public DbSet<QuestionTemplate> QuestionTemplates => Set<QuestionTemplate>();

    public DbSet<Category> Categories => Set<Category>();

    public DbSet<DoctorCategory> DoctorCategories => Set<DoctorCategory>();

    public DbSet<Message> Messages => Set<Message>();

    public DbSet<MessageRecipient> MessageRecipients => Set<MessageRecipient>();

    public DbSet<MessageSender> MessageSenders => Set<MessageSender>();

    public DbSet<PatientAnswer> PatientAnswers => Set<PatientAnswer>();
    public DbSet<TimelineEvent> TimelineEvents => Set<TimelineEvent>();
    public DbSet<PatientQuestionAnswer> PatientQuestionAnswers => Set<PatientQuestionAnswer>();

    public DbSet<ProductOrder> ProductOrders => Set<ProductOrder>();

    public DbSet<Notification>Notifications => Set<Notification>(); 

    public DbSet<UserNotificationReference>UserNotificationReferences => Set<UserNotificationReference>();
    public override async Task<int> SaveChangesAsync(CancellationToken cancellationToken = default)
    {
        await _mediator.DispatchDomainEvents(this);

        return await base.SaveChangesAsync(cancellationToken);
    }

    public async Task<int> SaveChangesAsync()
    {
        await _mediator.DispatchDomainEvents(this);

        return await base.SaveChangesAsync();
    }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {

    }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.AppendGlobalQueryFilter<ISoftDelete>(s => s.DeletedDate == null);

        base.OnModelCreating(modelBuilder);

        var eTypes = modelBuilder.Model.GetEntityTypes();
        foreach (var type in eTypes)
        {
            var foreignKeys = type.GetForeignKeys();
            foreach (var foreignKey in foreignKeys)
            {
                foreignKey.DeleteBehavior = DeleteBehavior.Restrict;
            }
        }

        modelBuilder.ApplyConfigurationsFromAssembly(Assembly.GetExecutingAssembly());
    }
}