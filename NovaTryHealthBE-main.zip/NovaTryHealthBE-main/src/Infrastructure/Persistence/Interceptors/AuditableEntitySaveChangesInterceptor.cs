﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.ChangeTracking;
using Microsoft.EntityFrameworkCore.Diagnostics;
using NovaHealth.Application.Common.Interfaces;
using NovaHealth.Domain.Common;

namespace NovaHealth.Infrastructure.Persistence.Interceptors;

public class AuditableEntitySaveChangesInterceptor : SaveChangesInterceptor
{
    private readonly ICurrentUser _currentUser;

    public AuditableEntitySaveChangesInterceptor(ICurrentUser currentUser)
    {
        _currentUser = currentUser;
    }

    public override InterceptionResult<int> SavingChanges(DbContextEventData eventData, InterceptionResult<int> result)
    {
        UpdateEntities(eventData.Context);

        return base.SavingChanges(eventData, result);
    }

    public override ValueTask<InterceptionResult<int>> SavingChangesAsync(DbContextEventData eventData, InterceptionResult<int> result, CancellationToken cancellationToken = default)
    {
        UpdateEntities(eventData.Context);

        return base.SavingChangesAsync(eventData, result, cancellationToken);
    }

    private void UpdateEntities(DbContext? context)
    {
        if (context == null)
        {
            return;
        }

        foreach (var entry in context.ChangeTracker.Entries<IAuditableEntity>())
        {
            if (entry.State == EntityState.Added)
            {
                //if (entry.Entity.CreatedBy == 0)
                //{
                //    entry.Entity.CreatedBy = _currentUser.Id;
                //}

                entry.Entity.CreatedDate = DateTime.UtcNow;
                //if (entry.Entity.LastModifiedBy == 0)
                //{
                //    entry.Entity.LastModifiedBy = _currentUser.Id;
                //}

                //entry.Entity.LastModifiedDate = DateTime.UtcNow;
            }
            //else if (entry.State == EntityState.Modified || entry.HasChangedOwnedEntities())
            //{
            //    if (entry.Entity.LastModifiedBy == 0)
            //    {
            //        entry.Entity.LastModifiedBy = _currentUser.Id;
            //    }

            //    entry.Entity.LastModifiedDate = DateTime.UtcNow;
            //}
            else if (entry.State == EntityState.Deleted && entry.Entity is ISoftDelete softDelete)
            {
                if (softDelete.DeletedBy == 0)
                {
                    softDelete.DeletedBy = _currentUser.Id;
                }

                softDelete.DeletedDate = DateTime.UtcNow;
            }
        }
    }
}

public static class Extensions
{
    public static bool HasChangedOwnedEntities(this EntityEntry entry) =>
        entry.References.Any(r =>
            r.TargetEntry != null &&
            r.TargetEntry.Metadata.IsOwned() &&
            (r.TargetEntry.State == EntityState.Added || r.TargetEntry.State == EntityState.Modified));
}