﻿
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

namespace NovaHealth.Infrastructure.Persistence;


public class NovaHealthDbContextInitializer
{
    private readonly NovaHealthDbContext _context;
    private readonly ILogger<NovaHealthDbContextInitializer> _logger;

    public NovaHealthDbContextInitializer(ILogger<NovaHealthDbContextInitializer> logger, NovaHealthDbContext context)
    {
        _logger = logger;
        _context = context;
    }

    public async Task InitialiseAsync()
    {
        try
        {
            if (_context.Database.IsSqlServer())
            {
                await _context.Database.MigrateAsync();
            }
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "An error occurred while initialising the database.");
            throw;
        }
    }
}