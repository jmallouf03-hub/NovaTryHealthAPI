﻿using NovaHealth.Application.Auth.Jwt;
using NovaHealth.Application.Common.Interfaces;
using NovaHealth.Application.Common.Mailing;
using NovaHealth.Infrastructure.Auth;
using NovaHealth.Infrastructure.Common.Services;
using NovaHealth.Infrastructure.Mailing;
using NovaHealth.Infrastructure.Middleware;
using NovaHealth.Infrastructure.Persistence.Interceptors;
using NovaHealth.Infrastructure.Persistence;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Options;
using Serilog;
using System.Text;
using NovaHealth.Infrastructure.FileStorage;
using NovaHealth.Infrastructure.Sms;
using Microsoft.EntityFrameworkCore;
using NovaHealth.Infrastructure.Caching;
using System.Text.Json;
using Serilog.Events;
using Serilog.Formatting.Compact;
using NovaHealth.Application.Common.Sms;

namespace NovaHealth.Infrastructure;

public static class ConfigureServices
{
    public static IServiceCollection AddInfrastructureServices(this IServiceCollection services, IConfiguration configuration)
    {
        // Add auditing interceptor for save changes
        services.AddScoped<AuditableEntitySaveChangesInterceptor>();

        // Add middleware and various infrastructure services
        services.AddExceptionMiddleware()
                .AddMailing(configuration)
                .AddFileStorage()
                .AddSms(configuration)
                .AddCaching(configuration);

        // Database configuration
        if (configuration.GetValue<bool>("UseInMemoryDatabase"))
        {
            services.AddDbContext<NovaHealthDbContext>(options =>
                options.UseInMemoryDatabase("ChaliceHealthDB"));
        }
        else
        {
            services.AddDbContext<NovaHealthDbContext>(options =>
                options.UseSqlServer(configuration.GetConnectionString("DefaultConnection"),
                    builder => builder.MigrationsAssembly(typeof(NovaHealthDbContext).Assembly.FullName)));
        }

        // Register application context and unit of work pattern
        services.AddScoped<INovaHealthDbContext>(provider => provider.GetRequiredService<NovaHealthDbContext>());
        services.AddScoped<IUnitOfWork, UnitOfWork>();
        services.AddScoped<NovaHealthDbContextInitializer>();

        // JWT configuration
        services.AddSingleton<IConfigureOptions<JwtBearerOptions>, ConfigureJwtBearerOptions>();

        services.AddAuthentication(authentication =>
        {
            authentication.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
            authentication.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
        })
        .AddJwtBearer(JwtBearerDefaults.AuthenticationScheme, null!);

        // Authorization configuration with IP check
        services.AddSingleton<IAuthorizationHandler, IpCheckHandler>();
        services.AddAuthorization(options =>
        {
            options.AddPolicy("SameIpPolicy", policy =>
            {
                policy.Requirements.Add(new IpCheckRequirement { IpClaimRequired = true });
            });
        });

        // Additional services
        services.AddTransient<IEmailTemplateService, EmailTemplateService>();
        services.AddTransient<IMailService, SmtpMailService>();
        services.AddTransient<ISerializerService, NewtonSoftService>();
        services.AddTransient<ISmsService, TwilioSmsService>();

        return services;
    }

    public static IApplicationBuilder UseInfrastructure(this IApplicationBuilder builder, IConfiguration config) =>
        builder.UseExceptionMiddleware();

    // Method for sending logs to external service

    // Method to configure Serilog
    public static void RegisterSerilog(this WebApplicationBuilder builder)
    {
        //  Log.Logger = new LoggerConfiguration()
        // .WriteTo.Console()
        // .WriteTo.MSSqlServer(
        // connectionString: builder.Configuration.GetConnectionString("DefaultConnection"),
        // sinkOptions: new Serilog.Sinks.MSSqlServer.MSSqlServerSinkOptions
        // {
        //     TableName = "AppLogs",
        //     AutoCreateSqlTable = true
        // }).Enrich.FromLogContext().CreateLogger();

        //builder.Host.UseSerilog();


    }
}