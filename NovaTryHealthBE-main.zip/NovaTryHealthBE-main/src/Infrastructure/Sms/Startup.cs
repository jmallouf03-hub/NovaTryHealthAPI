﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace NovaHealth.Infrastructure.Sms;

internal static class Startup
{
    internal static IServiceCollection AddSms(this IServiceCollection services, IConfiguration configuration)
    {
        services.Configure<TwilioSettings>(configuration.GetSection(nameof(TwilioSettings)));
        var settings = configuration.GetSection(nameof(TwilioSettings)).Get<TwilioSettings>();
        if (settings == null)
        {
            throw new Exception("Missing sms settings");
        }

        return services;
    }
}