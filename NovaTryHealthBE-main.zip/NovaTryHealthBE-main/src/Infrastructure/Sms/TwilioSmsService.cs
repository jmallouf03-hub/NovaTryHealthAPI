﻿using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using NovaHealth.Application.Common.Sms;
using Twilio.Rest.Api.V2010.Account;
using Twilio.Types;
using Twilio;
using NovaHealth.Application;

namespace NovaHealth.Infrastructure.Sms;

public class TwilioSmsService : ISmsService
{
    private readonly ILogger<TwilioSmsService> _logger;
    private readonly TwilioSettings _smsSettings;
    private readonly AppSettings _appSettings;

    public TwilioSmsService(ILogger<TwilioSmsService> logger, IOptions<TwilioSettings> smsSettings, IOptions<AppSettings> appSettings)
    {
        _logger = logger;
        _smsSettings = smsSettings.Value;
        _appSettings = appSettings.Value;
    }

    public async Task<SmsResponse> SendAsync(SmsRequest smsRequest)
    {
        TwilioClient.Init(_smsSettings.AccountSid, _smsSettings.AuthToken);

        // Ensure the phone number includes the country code
        string formattedPhoneNumber = FormatPhoneNumber(smsRequest.PhoneNumber, _appSettings.CountryCode);


        if (formattedPhoneNumber == null)
        {
            return new SmsResponse
            {
                IsValid = false,
                Message = $"Invalid phone number"
            };
        }

        try
        {
            var sendResponse = await MessageResource.CreateAsync(
                body: smsRequest.Message,
                from: new PhoneNumber(_smsSettings.FromNumber),
                to: new PhoneNumber(formattedPhoneNumber));

            if (sendResponse.ErrorCode.HasValue)
            {
                _logger.LogError("Send Sms error: ");// _serializerService.Serialize(sendResponse));
            }

            return new SmsResponse
            {
                IsValid = !sendResponse.ErrorCode.HasValue,
                Message = sendResponse.ErrorMessage
            };
        }

        catch (Twilio.Exceptions.ApiException ex)
        {
            _logger.LogError("Twilio API error: {Message}", ex.Message);
            return new SmsResponse
            {
                IsValid = false,
                Message = "Failed to send SMS due to Twilio API error."
            };
        }
    }

    private string FormatPhoneNumber(string phoneNumber, string countryCode)
    {
        phoneNumber = phoneNumber.Trim();

        if (!phoneNumber.StartsWith("+"))
        {
            // Remove leading zero if present
            if (phoneNumber.StartsWith("0"))
            {
                phoneNumber = phoneNumber.Substring(1);
            }

            // Prepend the country code
            phoneNumber = $"{countryCode}{phoneNumber}";
        }

        return phoneNumber;
    }
}