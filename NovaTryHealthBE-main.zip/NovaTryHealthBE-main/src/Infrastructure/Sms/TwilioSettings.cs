﻿namespace NovaHealth.Infrastructure.Sms;

public class TwilioSettings
{
    public string FromNumber { get; set; } = null!;

    public string AccountSid { get; set; } = null!;
    
    public string AuthToken { get; set; } = null!;

    public string ApiKeySid { get; set; } = null!;

    public string ApiKeySecret { get; set; } = null!;
}