﻿using System.Text.Json;
using System.Text.Json.Serialization;

namespace NovaHealth.Infrastructure.Common.Converters;

public class TcDateTimeNullableConverter : JsonConverter<DateTime?>
{
    public override DateTime? Read(ref Utf8JsonReader reader, Type typeToConvert, JsonSerializerOptions options)
    {
        var valueString = reader.GetString();

        return string.IsNullOrEmpty(valueString) ? null : DateTimeHelper.Parse(reader.GetString());
    }

    public override void Write(Utf8JsonWriter writer, DateTime? value, JsonSerializerOptions options)
    {
        if (value.HasValue)
        {
            writer.WriteStringValue(value.Value);
        }
    }
}