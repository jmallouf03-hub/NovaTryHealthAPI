﻿using System.Text.Json;
using System.Text.Json.Serialization;

namespace NovaHealth.Infrastructure.Common.Converters;

public class TcDateTimeConverter : JsonConverter<DateTime>
{
    public override DateTime Read(ref Utf8JsonReader reader, Type typeToConvert, JsonSerializerOptions options)
    {
        var valueString = reader.GetString();
        if (string.IsNullOrEmpty(valueString))
        {
            return reader.GetDateTime();
        }

        var parseResult = DateTimeHelper.Parse(reader.GetString());

        return parseResult ?? reader.GetDateTime();
    }

    public override void Write(Utf8JsonWriter writer, DateTime value, JsonSerializerOptions options)
    {
        writer.WriteStringValue(value);
    }
}