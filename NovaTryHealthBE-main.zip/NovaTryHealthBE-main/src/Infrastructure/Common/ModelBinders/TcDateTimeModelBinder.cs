//using Microsoft.AspNetCore.Mvc.ModelBinding;

//namespace NovaHealth.Infrastructure.Common.ModelBinders;

///// <summary>
///// DateTime Model Binder Provider
///// </summary>
//public class TcDateTimeModelBinderProvider : IModelBinderProvider
//{
//    /// <summary>
//    /// GetBinder
//    /// </summary>
//    public IModelBinder? GetBinder(ModelBinderProviderContext context)
//    {
//        if (context == null)
//        {
//            throw new ArgumentNullException(nameof(context));
//        }

//        return context.Metadata.ModelType == typeof(DateTime) ? new TcDateTimeModelBinder() : null;
//    }
//}

///// <summary>
///// CustomDateTimeModelBinder
///// </summary>
//public class TcDateTimeModelBinder : IModelBinder
//{
//    /// <summary>
//    /// SUPPORTED_DATETIME_TYPES
//    /// </summary>
//    private static readonly Type[] SUPPORTED_DATETIME_TYPES = { typeof(DateTime), typeof(DateTime?) };

//    /// <summary>
//    /// BindModelAsync
//    /// </summary>
//    public Task BindModelAsync(ModelBindingContext modelBindingContext)
//    {
//        if (modelBindingContext == null)
//        {
//            throw new ArgumentNullException(nameof(modelBindingContext));
//        }

//        if (!SUPPORTED_DATETIME_TYPES.Contains(modelBindingContext.ModelType))
//        {
//            return Task.CompletedTask;
//        }

//        var modelName = modelBindingContext.ModelName;
//        var valueProviderResult = modelBindingContext.ValueProvider.GetValue(modelName);
//        if (valueProviderResult == ValueProviderResult.None)
//        {
//            return Task.CompletedTask;
//        }

//        modelBindingContext.ModelState.SetModelValue(modelName, valueProviderResult);
//        var dateTimeToParse = valueProviderResult.FirstValue;
//        if (string.IsNullOrEmpty(dateTimeToParse))
//        {
//            return Task.CompletedTask;
//        }

//        var formattedDateTime = DateTimeHelper.Parse(dateTimeToParse);
//        modelBindingContext.Result = ModelBindingResult.Success(formattedDateTime);

//        return Task.CompletedTask;
//    }
//}