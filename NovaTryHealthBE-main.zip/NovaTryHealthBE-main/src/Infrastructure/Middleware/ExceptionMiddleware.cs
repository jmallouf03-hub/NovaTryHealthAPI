using System.Net;
using System.Text;
using Microsoft.AspNetCore.Http;
using Serilog;
using Serilog.Context;
using NovaHealth.Application.Common.Exceptions;
using NovaHealth.Application.Common.Interfaces;

namespace NovaHealth.Infrastructure.Middleware;

internal class ExceptionMiddleware : IMiddleware
{
    private readonly ICurrentUser _currentUser;
    private readonly ISerializerService _jsonSerializer;

    public ExceptionMiddleware(
        ICurrentUser currentUser,
        ISerializerService jsonSerializer)
    {
        _currentUser = currentUser;
        _jsonSerializer = jsonSerializer;
    }

    private async Task SendLog(ErrorResult errorResult, Exception exception)
    {
        try
        {
            var newErrorResult = new ErrorResult
            {
                Source = errorResult.Source,
                Exception = errorResult.Exception,
                ErrorId = errorResult.ErrorId,
                SupportMessage = errorResult.SupportMessage,
                Messages = new List<string>(errorResult.Messages) { exception.Message }
            };

            if (!string.IsNullOrEmpty(exception.StackTrace))
            {
                newErrorResult.Messages.Add(exception.StackTrace);
            }
            
            newErrorResult.Messages.Add(Environment.MachineName);

            var client = new HttpClient();
            client.BaseAddress = new Uri("https://logs-01.loggly.com/");

            var payload = _jsonSerializer.Serialize(newErrorResult);
            var content = new StringContent(payload, Encoding.UTF8, "application/json");
            await client.PostAsync("inputs/86bba125-6008-4277-be39-07456f7916f7/tag/ChaliceHealthAPI", content);
        }
        catch (Exception e)
        {
            Log.Error(e.StackTrace ?? e.Message);
        }
    }

    public async Task InvokeAsync(HttpContext context, RequestDelegate next)
    {
        try
        {
            await next(context);
        }
        catch (Exception exception)
        {
            var email = !string.IsNullOrEmpty(_currentUser.Email) ? _currentUser.Email : "Anonymous";
            var userId = _currentUser.Id;
            if (userId != 0)
            {
                LogContext.PushProperty("UserId", userId);
            }

            LogContext.PushProperty("UserEmail", email);
            var errorId = Guid.NewGuid().ToString();

            LogContext.PushProperty("ErrorId", errorId);
            LogContext.PushProperty("StackTrace", exception.StackTrace);

            var errorResult = new ErrorResult
            {
                Source = exception.TargetSite?.DeclaringType?.FullName,
                Exception = exception.Message.Trim(),
                ErrorId = errorId,
                SupportMessage = $"Provide the ErrorId {errorId} to the support team for further analysis."
            };

            if (exception is not CustomException && exception.InnerException != null)
            {
                while (exception.InnerException != null)
                {
                    exception = exception.InnerException;
                }
            }

            if (exception is FluentValidation.ValidationException fluentException)
            {
                errorResult.Exception = "One or More Validations failed.";
                foreach (var error in fluentException.Errors)
                {
                    errorResult.Messages.Add(error.ErrorMessage);
                }
            }

            switch (exception)
            {
                case CustomException customException:
                    errorResult.StatusCode = (int)customException.StatusCode;
                    if (customException.ErrorMessages is not null)
                    {
                        errorResult.Messages = customException.ErrorMessages;
                    }

                    break;

                case KeyNotFoundException:
                    errorResult.StatusCode = (int)HttpStatusCode.NotFound;
                    break;

                case FluentValidation.ValidationException:
                    errorResult.StatusCode = (int)HttpStatusCode.BadRequest;
                    break;

                default:
                    errorResult.StatusCode = (int)HttpStatusCode.InternalServerError;
                    break;
            }

            Log.Error($"{errorResult.Exception} Request failed with Status Code {errorResult.StatusCode} and Error Id {errorId}.");

            // Send to log server if 500
            if (errorResult.StatusCode == (int)HttpStatusCode.InternalServerError)
            {
                await SendLog(errorResult, exception);
            }

            var response = context.Response;
            if (!response.HasStarted)
            {
                response.ContentType = "application/json";
                response.StatusCode = errorResult.StatusCode;

                await response.WriteAsync(_jsonSerializer.Serialize(errorResult));
            }
            else
            {
                Log.Warning("Can't write error response. Response has already started.");
            }
        }
    }
}