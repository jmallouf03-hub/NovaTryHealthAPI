﻿namespace NovaHealth.Shared.Authorization;

public static class NovaHealthClaims
{
    public const string IpAddress = "IpAddress";
}
