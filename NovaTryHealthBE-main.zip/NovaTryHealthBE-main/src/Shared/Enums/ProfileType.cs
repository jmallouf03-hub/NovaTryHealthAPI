﻿namespace NovaHealth.Shared.Enums;

public enum ProfileType
{
    Admin = 1,

    Doctor = 2,

    Patient = 3
}