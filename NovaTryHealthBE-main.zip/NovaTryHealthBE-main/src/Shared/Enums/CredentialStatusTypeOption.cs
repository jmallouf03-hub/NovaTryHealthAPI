﻿namespace NovaHealth.Shared.Enums;

public enum CredentialStatusTypeOption 
{
    ApprovalPending = 1,

    Incomplete = 2,

    CompletedAndApproved = 3,

    NeedMoreInformation = 4,

    InvalidInformation = 5,

    NeedAttention = 6
}