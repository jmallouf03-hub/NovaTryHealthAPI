﻿    using System;
    namespace NovaHealth.Shared.Enums;

    public enum PaymentStatusType
    {
            Pending = 0,

            Completed = 1,

            Failed = 2,

            Canceled = 3,

            Refunded =4

}
