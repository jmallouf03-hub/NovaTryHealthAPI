﻿namespace NovaHealth.Shared.Enums;

public enum FileStorageOption
{
    Local = 1,

    Aws = 2,

    Azure = 3
}