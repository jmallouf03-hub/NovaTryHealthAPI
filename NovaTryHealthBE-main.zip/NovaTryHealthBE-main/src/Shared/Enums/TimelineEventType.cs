﻿namespace NovaHealth.Shared.Enums;

public enum TimelineEventType
{
    Login,
    OTP,
    Message,
    PasswordReset,
    OtpResend,
    SignUp,
    LabResult,
    Profile,
    Order
}