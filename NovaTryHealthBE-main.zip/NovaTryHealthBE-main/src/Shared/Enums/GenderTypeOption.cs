﻿namespace NovaHealth.Shared.Enums;

public enum GenderTypeOption
{
    Male = 1,

    Female = 2,

    Other = 3,

    NotSpecified = 4

}