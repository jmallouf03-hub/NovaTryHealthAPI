﻿namespace NovaHealth.Shared.Enums;public enum RoleType{    Admin = 1,

    Doctor = 2,    Patient = 3
}