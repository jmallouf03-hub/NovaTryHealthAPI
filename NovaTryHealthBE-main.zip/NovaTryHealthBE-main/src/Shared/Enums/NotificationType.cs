﻿namespace NovaHealth.Shared.Enums;

public enum NotificationType
{
    Order = 1,

    Message = 2,

    Patient = 3

}