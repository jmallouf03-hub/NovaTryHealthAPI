﻿namespace NovaHealth.Shared.Enums
{
    public enum NotificationReferenceType
    {
        Product = 1,
        Message = 2
    }
}
