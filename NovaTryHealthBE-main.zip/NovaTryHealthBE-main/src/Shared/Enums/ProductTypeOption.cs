﻿namespace NovaHealth.Shared.Enums;

public enum ProductTypeOption
{
    Drug = 1,

    LabTest = 2,

    ProductBunddle = 3,
}
