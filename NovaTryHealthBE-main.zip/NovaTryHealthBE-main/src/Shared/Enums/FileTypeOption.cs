namespace NovaHealth.Shared.Enums;

public enum FileTypeOption
{
    Documents = 1,

    ProfilePicture = 2,

    VideoIntroName = 3
}