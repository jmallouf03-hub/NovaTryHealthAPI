﻿using System.ComponentModel;
using System.Reflection;

namespace NovaHealth.Shared.Helpers;

public static class EnumHelper
{
    public static string GetDescription<T>(this T enumValue)
        where T : struct, IConvertible
    {
        if (!typeof(T).IsEnum)
        {
            return string.Empty;
        }

        return
            enumValue
                .GetType()
                .GetMember(enumValue.ToString() ?? string.Empty)
                .FirstOrDefault()
                ?.GetCustomAttribute<DescriptionAttribute>()
                ?.Description
            ?? enumValue.ToString()!;
    }

    public static object EnumToDataSource<T>() where T : struct, IConvertible
    {
        if (!typeof(T).IsEnum)
        {
            throw new Exception($"Type {typeof(T)} is not an enumeration.");
        }

        return Enum.GetValues(typeof(T)).Cast<T>().Select(x => new
            {
                Id = x.ToInt32(null),
                Name = x.ToString(),
                //LongName = $"{x.GetType()}.{x}",
                Description = x.GetDescription()
            })
            .OrderBy(x => x.Id).ToArray();
    }
}