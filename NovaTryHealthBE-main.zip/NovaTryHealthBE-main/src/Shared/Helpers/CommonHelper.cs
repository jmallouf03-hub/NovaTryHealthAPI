﻿namespace NovaHealth.Shared.Helpers;

public static class CommonHelper
{
    public static string GenerateOTP()
    {
        var random = new Random();
        return random.Next(100000, 999999).ToString(); // Generate 6-digit OTP
    }
}