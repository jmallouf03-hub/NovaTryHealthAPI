﻿using System.Security.Cryptography;
using System.Text;

namespace NovaHealth.Shared.Helpers;

public static class SecurityHelper
{
    private const string SALT = "s6p('qn4xQ9!ws(AN-.TWG!";
    private const string SALT_STRING = "pMR9(2`{~~<q9y<9PQux$U";

    public static string HashPassword(string password)
    {
        var saltBytes = Encoding.ASCII.GetBytes(SALT);

        using var rfc2898DeriveBytes = new Rfc2898DeriveBytes(password, saltBytes, 100);

        return Convert.ToBase64String(rfc2898DeriveBytes.GetBytes(100));
    }

    public static string Hash(string value)
    {
        var saltBytes = Encoding.ASCII.GetBytes(SALT_STRING);

        using var rfc2898DeriveBytes = new Rfc2898DeriveBytes(value, saltBytes, 100);

        return Convert.ToBase64String(rfc2898DeriveBytes.GetBytes(100));
    }

    const string ENCRYPTION_KEY = "6?zeqC5GwU*H?W%:27J!K_?+FUTfK,";



    public static string Encrypt(string txt)
    {
        byte[] clearBytes = Encoding.Unicode.GetBytes(txt);
        using (Aes encryptor = Aes.Create())
        {
            Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(ENCRYPTION_KEY, new byte[] { 0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x64, 0x65, 0x76 });
            encryptor.Key = pdb.GetBytes(32);
            encryptor.IV = pdb.GetBytes(16);
            using (MemoryStream ms = new MemoryStream())
            {
                using (CryptoStream cs = new CryptoStream(ms, encryptor.CreateEncryptor(), CryptoStreamMode.Write))
                {
                    cs.Write(clearBytes, 0, clearBytes.Length);
                    cs.Close();
                }

                txt = Convert.ToBase64String(ms.ToArray());
            }
        }

        return txt;
    }

    public static string Decrypt(string encryptText)
    {
        encryptText = encryptText.Replace(" ", "+");
        byte[] cipherBytes = Convert.FromBase64String(encryptText);
        using (Aes encryptor = Aes.Create())
        {
            Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(ENCRYPTION_KEY, new byte[] { 0x49, 0x76, 0x61, 0x6e, 0x20, 0x4d, 0x65, 0x64, 0x76, 0x65, 0x64, 0x65, 0x76 });
            encryptor.Key = pdb.GetBytes(32);
            encryptor.IV = pdb.GetBytes(16);
            using (MemoryStream ms = new MemoryStream())
            {
                using (CryptoStream cs = new CryptoStream(ms, encryptor.CreateDecryptor(), CryptoStreamMode.Write))
                {
                    cs.Write(cipherBytes, 0, cipherBytes.Length);
                    cs.Close();
                }

                encryptText = Encoding.Unicode.GetString(ms.ToArray());
            }
        }

        return encryptText;
    }

}