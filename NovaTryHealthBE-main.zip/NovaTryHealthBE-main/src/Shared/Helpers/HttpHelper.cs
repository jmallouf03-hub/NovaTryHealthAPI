﻿using MyCSharp.HttpUserAgentParser;

namespace NovaHealth.Shared.Helpers;

public static class HttpHelper
{
    public static HttpUserAgentInformation ParseUserAgent(string? userAgent)
    {
        return HttpUserAgentParser.Parse(userAgent);
    }
}