using System.Globalization;

namespace NovaHealth.Shared.Helpers;

public static class DateTimeHelper
{
    private static readonly string[] CUSTOM_DATETIME_FORMATS =
    {
        "ddMMyyyy",
        "dd-MM-yyyy-THH-mm-ss",
        "dd-MM-yyyy-HH-mm-ss",
        "dd-MM-yyyy-HH-mm",
        "yyyyMMddTHHmmssZ",
        "yyyyMMddTHHmmZ",
        "yyyyMMddTHHmmss",
        "yyyyMMddTHHmm",
        "yyyyMMddHHmmss",
        "yyyyMMddHHmm",
        "yyyyMMdd",
        "yyyy-MM-ddTHH-mm-ss",
        "yyyy-MM-dd-HH-mm-ss",
        "yyyy-MM-dd-HH-mm",
        "yyyy-MM-dd",
        "MM-dd-yyyy",
        "MMddyyyy",
        "MM/dd/yyyy",
        "M/d/yyyy"
    };

    public static DateTime? Parse(string? date)
    {
        if (string.IsNullOrEmpty(date))
        {
            return null;
        }

        foreach (var format in CUSTOM_DATETIME_FORMATS)
        {
            if (DateTime.TryParseExact(date, format, null, DateTimeStyles.None, out DateTime validDate))
            {
                return validDate;
            }
        }

        return null;
    }
}