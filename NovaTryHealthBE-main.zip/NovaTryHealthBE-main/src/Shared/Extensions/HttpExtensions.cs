﻿using Microsoft.AspNetCore.Http;
using System.Net;

namespace NovaHealth.Shared.Extensions;

public static class HttpExtensions
{
    public static string GetIpAddress(this IHttpContextAccessor httpContextAccessor)
    {
        if (httpContextAccessor.HttpContext == null)
        {
            return "N/A";
        }

        var headers = httpContextAccessor.HttpContext.Request.Headers;

        if (headers.ContainsKey("X-Forwarded-For"))
        {
            var forwardedIps = headers["X-Forwarded-For"].ToString();
            return forwardedIps.Split(',')[0].Trim();
        }

        if (headers.ContainsKey("X-Real-IP"))
        {
            return headers["X-Real-IP"];
        }

        var ip = httpContextAccessor.HttpContext.Connection.RemoteIpAddress;

        // If the IP is "::1" (IPv6 loopback), return "127.0.0.1"
        if (ip != null && ip.Equals(IPAddress.IPv6Loopback))
        {
            return "127.0.0.1";
        }

        return ip?.MapToIPv4().ToString() ?? "N/A";
    }
}
