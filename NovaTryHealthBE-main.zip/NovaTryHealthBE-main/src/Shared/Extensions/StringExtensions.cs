﻿namespace NovaHealth.Shared.Extensions;

public static class StringExtensions
{
    public static string Mask(this string source, int start, int maskLength)
    {
        return source.Mask(start, maskLength, '*');
    }

    public static string Mask(this string source, int start, int maskLength, char maskCharacter)
    {
        if (string.IsNullOrEmpty(source))
        {
            return string.Empty;
        }

        if (start > source.Length - 1)
        {
            throw new ArgumentException("Start position is greater than string length");
        }

        if (maskLength > source.Length)
        {
            throw new ArgumentException("Mask length is greater than string length");
        }

        if (start + maskLength > source.Length)
        {
            throw new ArgumentException("Start position and mask length imply more characters than are present");
        }

        var mask = new string(maskCharacter, maskLength);
        var unMaskStart = source.Substring(0, start);
        var unMaskEnd = source.Substring(start + maskLength);

        return unMaskStart + mask + unMaskEnd;
    }


    public static string MaskPhoneNumber(this string phoneNumber)
    {
        return phoneNumber.Mask(phoneNumber.Length / 3 - 1, phoneNumber.Length / 2);
    }

    public static string MaskSsn(this string ssn)
    {
        return ssn.Mask(0, ssn.Length - 4);
    }

    public static string MaskEmail(this string email)
    {
        if (string.IsNullOrEmpty(email) || !email.Contains("@"))
        {
            return email.Mask(email.Length / 3 - 1, email.Length / 2);
        }

        var emailArr = email.Split('@');
        var emailName = emailArr[0];
        var domain = emailArr[1];

        return $"{emailName.Mask(emailName.Length / 3 - 1, emailName.Length / 2)}@{domain}";
    }
}