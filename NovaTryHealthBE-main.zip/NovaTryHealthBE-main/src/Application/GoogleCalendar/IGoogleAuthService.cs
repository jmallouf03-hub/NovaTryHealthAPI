﻿using Google.Apis.Auth.OAuth2.Flows;

namespace NovaHealth.Application.GoogleCalendar;

public interface IGoogleAuthService
{
    GoogleAuthorizationCodeFlow GetFlow();
}