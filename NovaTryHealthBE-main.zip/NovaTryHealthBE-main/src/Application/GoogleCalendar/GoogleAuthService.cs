﻿using Google.Apis.Auth.OAuth2.Flows;
using Google.Apis.Auth.OAuth2;
using Google.Apis.Calendar.v3;
using Google.Apis.Util.Store;
using Microsoft.Extensions.Options;

namespace NovaHealth.Application.GoogleCalendar;

public class GoogleAuthService : IGoogleAuthService
{
    private readonly AppSettings _appSettings;

    public GoogleAuthService(IOptions<AppSettings> appSettings)
    {
        _appSettings = appSettings.Value;
    }

    public GoogleAuthorizationCodeFlow GetFlow()
    {
        string clientId = _appSettings.GoogleClientId;
        string clientSecret = _appSettings.GoogleClientSecret;
        // string RedirectUri = _appSettings.RedirectUri;

        var tokenFolder = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "App_Data", "Tokens");
        Directory.CreateDirectory(tokenFolder);

        return new GoogleAuthorizationCodeFlow(new GoogleAuthorizationCodeFlow.Initializer
        {
            ClientSecrets = new ClientSecrets
            {
                ClientId = clientId,
                ClientSecret = clientSecret
            },
            Scopes = new[] { CalendarService.Scope.Calendar },
            DataStore = new FileDataStore(tokenFolder)
        });
    }
}
