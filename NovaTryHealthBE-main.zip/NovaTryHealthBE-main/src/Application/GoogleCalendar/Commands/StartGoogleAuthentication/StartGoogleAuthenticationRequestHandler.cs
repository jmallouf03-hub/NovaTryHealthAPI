﻿using MediatR;
using Microsoft.Extensions.Options;
using System.Text.Json;

namespace NovaHealth.Application.GoogleCalendar.Commands.StartGoogleAuthentication;

public class StartGoogleAuthenticationRequestHandler : IRequestHandler<StartGoogleAuthenticationRequest, string>
{
    private readonly AppSettings _appSettings;
    private readonly IGoogleAuthService _googleAuthenticationService;

    public StartGoogleAuthenticationRequestHandler(IGoogleAuthService googleAuthenticationService, IOptions<AppSettings> appSettings)
    {
        _appSettings = appSettings.Value;
        _googleAuthenticationService = googleAuthenticationService;
    }

    public Task<string> Handle(StartGoogleAuthenticationRequest request, CancellationToken cancellationToken)
    {
        var flow = _googleAuthenticationService.GetFlow();
        var state = JsonSerializer.Serialize(request.BookingAppointmentId);
        var authorizationUrl = flow.CreateAuthorizationCodeRequest(_appSettings.RedirectUri);
        authorizationUrl.State = state;

        return Task.FromResult(authorizationUrl.Build().ToString());
    }
}