﻿using MediatR;

namespace NovaHealth.Application.GoogleCalendar.Commands.StartGoogleAuthentication;

public class StartGoogleAuthenticationRequest : IRequest<string>
{
    public List<long> BookingAppointmentId { get; set; } = new();
}