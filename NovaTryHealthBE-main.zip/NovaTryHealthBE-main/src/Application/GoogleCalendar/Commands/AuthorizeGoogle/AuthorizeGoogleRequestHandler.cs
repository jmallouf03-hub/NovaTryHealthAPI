﻿using NovaHealth.Application.Common.Exceptions;
using Google.Apis.Auth.OAuth2;
using Google.Apis.Calendar.v3.Data;
using Google.Apis.Calendar.v3;
using Google.Apis.Services;
using MediatR;
using Microsoft.Extensions.Options;
using System.Text.Json;
using NovaHealth.Application.Common.Interfaces;

namespace NovaHealth.Application.GoogleCalendar.Commands.AuthorizeGoogle;

public class AuthorizeGoogleRequest : IRequest<bool>
{
    public string Code { get; set; } = null!;

    public string State { get; set; } = null!;
}


public class AuthorizeGoogleRequestHandler : IRequestHandler<AuthorizeGoogleRequest, bool>
{
    private readonly AppSettings _appSettings;
    private readonly IGoogleAuthService _googleAuthenticationService;
    private readonly INovaHealthDbContext _novaHealthDbContext;

    public AuthorizeGoogleRequestHandler(IGoogleAuthService googleAuthenticationService, IOptions<AppSettings> appSettings, INovaHealthDbContext novaHealthDbContext)
    {
        _appSettings = appSettings.Value;
        _googleAuthenticationService = googleAuthenticationService;
        _novaHealthDbContext = novaHealthDbContext;
    }

    public async Task<bool> Handle(AuthorizeGoogleRequest request, CancellationToken cancellationToken)
    {
        if (string.IsNullOrEmpty(request.Code))
        {
            throw new NotFoundException("Authorization code is missing");
        }

        var flow = _googleAuthenticationService.GetFlow();
        var token = await flow.ExchangeCodeForTokenAsync("user", request.Code, _appSettings.RedirectUri, cancellationToken);
        var credential = new UserCredential(flow, "user", token);
        var bookingIds = JsonSerializer.Deserialize<List<long>>(request.State);

        if (bookingIds == null || !bookingIds.Any())
        {
            throw new ApplicationException("No booking IDs found in the state parameter.");
        }

        var calendarService = new CalendarService(new BaseClientService.Initializer
        {
            HttpClientInitializer = credential,
            ApplicationName = "Chalice Health Appointments"
        });

        //foreach (var bookingId in bookingIds)
        //{
        //    var bookingAppointment = await _novaHealthDbContext.BookAppointments
        //        .Include(x => x.AvailabilitySlot)
        //        .Include(x => x.Provider)
        //        .FirstOrDefaultAsync(x => x.Id == bookingId, cancellationToken);

        //    if (bookingAppointment == null)
        //    {
        //        throw new NotFoundException("Booking appointment not found.");
        //    };

        //    TimeOnly slotEndTime = bookingAppointment.AvailabilitySlot.EndTime;

        //    DateTimeOffset appointmentStart = bookingAppointment.AppointmentDateTime;
        //    DateTimeOffset appointmentEnd = appointmentStart.Date.Add(slotEndTime.ToTimeSpan());
        //    DateTimeOffset appointmentStartUtc = appointmentStart.ToUniversalTime();
        //    DateTimeOffset appointmentEndUtc = appointmentEnd.ToUniversalTime();

        //    var newEvent = new Event
        //    {
        //        Summary = $"Appointment with Dr. {bookingAppointment.Provider.FirstName} {bookingAppointment.Provider.LastName}",
        //        Description = $"{bookingAppointment.ReasonForVisit}",
        //        Start = new EventDateTime
        //        {
        //            DateTimeRaw = appointmentStartUtc.ToString("yyyy-MM-ddTHH:mm:ss"),
        //            TimeZone = "UTC"  // Set the time zone to UTC
        //        },
        //        End = new EventDateTime
        //        {
        //            DateTimeRaw = appointmentEndUtc.ToString("yyyy-MM-ddTHH:mm:ss"),
        //            TimeZone = "UTC"  // Set the time zone to UTC
        //        }
        //    };

        //    try
        //    {
        //        await calendarService.Events.Insert(newEvent, "primary").ExecuteAsync();
        //    }

        //    catch (Google.GoogleApiException gEx)
        //    {
        //        throw new ApplicationException("Google API error: " + gEx.Message, gEx);
        //    }
        //    catch (Exception ex)
        //    {
        //        throw new ApplicationException("Unexpected error: " + ex.Message, ex);
        //    }
        //}

        return true;
    }
}