using NovaHealth.Application.Common.Interfaces;

namespace NovaHealth.Application.Common.Mailing;

public interface IEmailTemplateService : ITransientService
{
    string GenerateEmailTemplate<T>(string templateName, T mailTemplateModel);
}