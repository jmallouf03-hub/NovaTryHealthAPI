using NovaHealth.Application.Common.Interfaces;

namespace NovaHealth.Application.Common.Mailing;

public interface IMailService : ITransientService
{
    Task SendAsync(MailRequest request, CancellationToken ct);
}