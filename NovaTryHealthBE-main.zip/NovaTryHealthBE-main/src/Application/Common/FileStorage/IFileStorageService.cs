using NovaHealth.Application.Common.Interfaces;
using Microsoft.AspNetCore.Http;

namespace NovaHealth.Application.Common.FileStorage;

public interface IFileStorageService : ITransientService
{
    public Task<FileUploadResponse> UploadAsync(FileUploadRequest request, CancellationToken cancellationToken = default);

    public Task<FileDownloadResponse> Resolve(FileDownloadRequest request, CancellationToken cancellationToken);
}