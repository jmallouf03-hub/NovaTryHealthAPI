using Microsoft.AspNetCore.Http;

namespace NovaHealth.Application.Common.FileStorage;

public class FileUploadRequest
{
    public IFormFile File { get; set; } = null!;
    
    public FileTypeOption FileTypeOption { get; set; }
    
    public long UserId { get; set; }

    public long CompanyId { get; set; }

    public long DoctorContactDetailId { get; set; }

    public long MessageComplaintId { get; set; }
}