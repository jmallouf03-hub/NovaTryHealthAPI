﻿namespace NovaHealth.Application.Common.FileStorage;

public class FileDownloadResponse
{
    public byte[] ImageData { get; set; } = null!;
}