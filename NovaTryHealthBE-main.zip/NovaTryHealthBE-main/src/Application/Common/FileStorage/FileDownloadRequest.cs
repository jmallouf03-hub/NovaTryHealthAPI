﻿namespace NovaHealth.Application.Common.FileStorage;

public class FileDownloadRequest
{
    public string Name { get; set; } = null!;

    public long UserId { get; set; }

    public long CompanyId { get; set; }

    public FileTypeOption FileTypeOption { get; set; }
}