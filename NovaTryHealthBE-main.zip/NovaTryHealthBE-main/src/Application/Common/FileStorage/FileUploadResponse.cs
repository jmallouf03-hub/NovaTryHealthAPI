namespace NovaHealth.Application.Common.FileStorage;

public class FileUploadResponse
{
    public string Name { get; set; } = null!;

    public string OriginalName { get; set; } = null!;
    
    public string Extension { get; set; } = null!;

    public long Size { get; set; }

    public string SavedTo { get; set; } = null!;

    public FileTypeOption FileTypeOption { get; set; }

    public FileStorageOption FileStorage { get; set; }
}