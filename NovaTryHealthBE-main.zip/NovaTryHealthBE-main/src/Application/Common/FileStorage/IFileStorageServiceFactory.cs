using NovaHealth.Application.Common.Interfaces;

namespace NovaHealth.Application.Common.FileStorage;

public interface IFileStorageServiceFactory : ITransientService
{
    IFileStorageService Get(FileStorageOption fileStorage);
}