﻿namespace NovaHealth.Application.Common.Sms;

public class SmsResponse
{
    public bool IsValid { get; set; }

    public string Message { get; set; } = null!;
}