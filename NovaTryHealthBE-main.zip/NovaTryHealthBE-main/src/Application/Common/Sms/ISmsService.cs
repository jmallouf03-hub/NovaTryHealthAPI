﻿using NovaHealth.Application.Common.Interfaces;

namespace NovaHealth.Application.Common.Sms;

public interface ISmsService : ITransientService
{
    Task<SmsResponse> SendAsync(SmsRequest smsRequest);
}