﻿namespace NovaHealth.Application.Common.Sms;

public class SmsRequest
{
    public string PhoneNumber { get; set; } = null!;

    public string Message { get; set; } = null!;
}