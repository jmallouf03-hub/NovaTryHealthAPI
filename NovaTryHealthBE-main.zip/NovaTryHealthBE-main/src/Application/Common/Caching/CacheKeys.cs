﻿namespace NovaHealth.Application.Common.Caching;

public class CacheKeys
{
    public const string UserProfile = "UserProfile";

    public const string UserPermission = "UserPermission";
}