﻿namespace NovaHealth.Application.Common.Models;

public record EmailRequest
{
    public string Email { get; set; } = null!;
}