﻿namespace NovaHealth.Application.Common.Models;

public class BaseFilter
{
    public string? Filter { get; set; }
}