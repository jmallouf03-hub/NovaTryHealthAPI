﻿namespace NovaHealth.Application.Common.Models;

public record Address
{
    public string? StreetAddress { get; set; }

    public string? Suite { get; set; }

    public string? City { get; set; }

    public string? State { get; set; }

    public string? Zipcode { get; set; }
}