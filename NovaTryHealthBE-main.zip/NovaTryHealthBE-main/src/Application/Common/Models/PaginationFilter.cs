﻿namespace NovaHealth.Application.Common.Models;

public class PaginationFilter : BaseFilter
{
    public int PageNumber { get; set; } = 1;

    public int PageSize { get; set; } = int.MaxValue;

    public string? OrderBy { get; set; }
}