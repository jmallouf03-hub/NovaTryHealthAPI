﻿using System.Diagnostics;
using MediatR;
using Microsoft.Extensions.Logging;
using NovaHealth.Application.Common.Interfaces;

namespace NovaHealth.Application.Common.Behaviours;

public class PerformanceBehaviour<TRequest, TResponse> : IPipelineBehavior<TRequest, TResponse> where TRequest : notnull
{
    private readonly ILogger<TRequest> _logger;
    private readonly Stopwatch _timer;
    private readonly ICurrentUser _currentUser;

    public PerformanceBehaviour(
        ILogger<TRequest> logger,
        ICurrentUser currentUser
      )
    {
        _timer = new Stopwatch();

        _logger = logger;
        _currentUser = currentUser;
    }

    public async Task<TResponse> Handle(TRequest request, RequestHandlerDelegate<TResponse> next, CancellationToken cancellationToken)
    {
        _timer.Start();

        TResponse response = await next();

        _timer.Stop();

        var elapsedMilliseconds = _timer.ElapsedMilliseconds;

        if (elapsedMilliseconds > 500)
        {
            var requestName = typeof(TRequest).Name;
            var userId = _currentUser.Id;
            var userName = string.Empty;

            _logger.LogWarning("Shift Management Long Running Request: {Name} ({ElapsedMilliseconds} milliseconds) {@UserId} {@UserName} {@Request}", requestName, elapsedMilliseconds, userId, userName, request);
        }

        return response;
    }
}