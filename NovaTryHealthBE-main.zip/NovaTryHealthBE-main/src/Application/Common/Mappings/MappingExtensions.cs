﻿using Microsoft.EntityFrameworkCore;
using NovaHealth.Application.Common.Models;

namespace NovaHealth.Application.Common.Mappings;

public static class MappingExtensions
{ 
    public static async Task<PaginationResponse<TDestination>> PaginatedListAsync<TDestination>(
    this IQueryable<TDestination> queryable,
    int pageNumber,
    int pageSize,

    CancellationToken cancellationToken = default) where TDestination : class
    {
        var count = await queryable.CountAsync(cancellationToken);

        var totalPages = (int)Math.Ceiling(count / (double)pageSize);
        if (pageNumber > totalPages) pageNumber = totalPages;
        if (pageNumber < 1) pageNumber = 1;

        var items = await queryable
            .Skip((pageNumber - 1) * pageSize)
            .Take(pageSize)
            .ToListAsync(cancellationToken);

        return new PaginationResponse<TDestination>(items, count, pageNumber, pageSize);
    }
}