﻿using FluentValidation;

namespace NovaHealth.Application.Common.Validations;

public static class ValidateExtensions
{
    internal static IRuleBuilderOptions<T, string> ValidatePassword<T>(this IRuleBuilder<T, string> ruleBuilder)
    {
        return ruleBuilder
            .NotEmpty().WithMessage("Your password cannot be empty")
            .MinimumLength(8).WithMessage("Your password length must be at least 8.")
            .MaximumLength(16).WithMessage("Your password length must not exceed 16.")
            .Matches(@"[A-Z]+").WithMessage("Your password must contain at least one uppercase letter.")
            .Matches(@"[a-z]+").WithMessage("Your password must contain at least one lowercase letter.")
            .Matches(@"[0-9]+").WithMessage("Your password must contain at least one number.")
            .Matches(@"[\!\@\#\$\%\^\&\*]+").WithMessage("Your password must contain at least one (!@#$%^&*).");
    }

    internal static IRuleBuilderOptions<T, DateTime> ValidateAge<T>(this IRuleBuilder<T, DateTime> ruleBuilder)
    {
        return ruleBuilder
        .NotEmpty().WithMessage("Date cannot be empty.")
        .Must(date => date <= DateTime.UtcNow.Date).WithMessage("Date must be greater than the current date.");
    }

    internal static IRuleBuilderOptions<T, DateTime> ValidateDate<T>(this IRuleBuilder<T, DateTime> ruleBuilder)
    {
        return ruleBuilder
        .NotEmpty().WithMessage("Date cannot be empty.")
        .Must(date => date <= DateTime.UtcNow.Date).WithMessage("Date must be greater than the current date.");
    }

    internal static IRuleBuilderOptions<T, string> ValidateSsn<T>(this IRuleBuilder<T, string> ruleBuilder)
    {
        return ruleBuilder
            .NotEmpty().WithMessage("'Ssn' must not be empty")
            .MinimumLength(9).WithMessage("The length of 'Ssn' must be at least 9 characters.")
            .MaximumLength(9).WithMessage("The length of 'Ssn' must be 9 characters.")
            .Matches(@"[0-9]+").WithMessage("'Ssn' must be 9 numbers.");
    }
}