﻿using System.Net;

namespace NovaHealth.Application.Common.Exceptions;

public class BadException : CustomException
{
    public BadException(string message)
        : base(message, null, HttpStatusCode.BadRequest)
    {
    }
}