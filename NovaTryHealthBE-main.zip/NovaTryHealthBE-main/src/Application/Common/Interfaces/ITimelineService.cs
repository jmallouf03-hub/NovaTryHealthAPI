﻿using NovaHealth.Domain.Entities;

namespace NovaHealth.Application.Common.Interfaces;

public interface ITimelineService
{
    Task LogTimelineEventAsync(
    long UserID,
    TimelineEventType eventType,
    string title,
    string description,
    object metadata = null,
    string createdBy = "System"
);

    Task<IEnumerable<TimelineEvent>> GetTimelineByPatientAsync(int patientId);
}
