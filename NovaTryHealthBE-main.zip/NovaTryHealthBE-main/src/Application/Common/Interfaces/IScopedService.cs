namespace NovaHealth.Application.Common.Interfaces;

public interface IScopedService
{
}