﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.ChangeTracking;
using NovaHealth.Domain.Entities;

namespace NovaHealth.Application.Common.Interfaces;

public interface INovaHealthDbContext
{
    DbSet<User> Users { get;  }
    DbSet<OTP> OTPs { get; }
    DbSet<Role> Roles { get; }
    DbSet<UserRole> UserRoles { get; }
    DbSet<PasswordHistory> PasswordHistories { get; }
    DbSet<LoginLog> LoginLogs { get; }
    DbSet<MagicToken> MagicTokens { get; }
    DbSet<UserAddress> UserAddress { get; }
    DbSet<State> States { get; }

    DbSet<ProductVariant> ProductVariants { get; }
    DbSet<Product> Products { get; }
    DbSet<ProductIngredient> ProductIngredients { get; }
    DbSet<Questionnaire> Questionnaires { get; }
    DbSet<AnswerOption> AnswerOptions { get; }
    DbSet<QuestionnaireProduct> QuestionnaireProducts { get; }
    DbSet<Domain.Entities.Question> Questions { get; }
    DbSet<QuestionnaireType> QuestionnaireTypes { get; }
    DbSet<QuestionnaireTreatmentType> QuestionnaireTreatmentTypes { get; }

    DbSet<QuestionnaireGlobalLayout> QuestionnaireGlobalLayouts { get; }

    DbSet<QuestionnaireDefaultLanguage> QuestionnaireDefaultLanguages { get; }

    DbSet<QuestionType> QuestionTypes { get; }

    DbSet<WebDomain>  WebDomains { get; }   

    DbSet<QuestionSpecialVisit> QuestionSpecialVisits { get; }

    DbSet<LayoutAnswerSetting> LayoutAnswerSettings { get; }
    DbSet<LayoutFooterSetting> LayoutFooterSettings { get; }

    DbSet<LayoutHeaderSetting> LayoutHeaderSettings { get; }    

    DbSet<PatientGoal> PatientGoals { get; }

    DbSet<PatientTreatmentType> PatientTreatmentTypes { get; }

    DbSet<PatientMetric> PatientMetrics { get; }

    DbSet<LayoutTitleSetting> LayoutTitleSettings { get; }

    DbSet<QuestionProduct> QuestionProducts { get; }

    DbSet<BookOrder> BookOrders { get; }

    DbSet<QuestionTemplate> QuestionTemplates { get; }

    DbSet<GlobalLayoutSetting> GlobalLayoutSettings { get; }

    DbSet<DoctorCategory> DoctorCategories { get; } 

    DbSet<Category> Categories { get; }

    DbSet<Message> Messages { get; }

    DbSet<MessageRecipient> MessageRecipients { get; }

    DbSet<MessageSender> MessageSenders { get; }

    DbSet<TimelineEvent> TimelineEvents { get; }
    DbSet<PatientQuestionAnswer> PatientQuestionAnswers { get; }
    DbSet<PatientAnswer> PatientAnswers { get; }
    DbSet<ProductOrder>ProductOrders { get; }

    DbSet<UserNotificationReference>UserNotificationReferences { get; }

    DbSet<Notification> Notifications { get; }
    EntityEntry<TEntity> Update<TEntity>(TEntity entity) where TEntity : class;

    EntityEntry<TEntity> Add<TEntity>(TEntity entity) where TEntity : class;

    Task<int> SaveChangesAsync(CancellationToken cancellationToken);

    Task<int> SaveChangesAsync();
}