﻿namespace NovaHealth.Application.Common.Interfaces;

public interface IUnitOfWork : IDisposable, ITransientService
{
    void BeginTransaction();

    void Commit();

    void Rollback();

    Task<int> SaveChangesAsync(CancellationToken cancellationToken = default);

    Task SaveAndCommitAsync(CancellationToken cancellationToken = default);
}