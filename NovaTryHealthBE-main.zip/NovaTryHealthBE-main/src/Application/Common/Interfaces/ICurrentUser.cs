﻿using System.Security.Claims;

namespace NovaHealth.Application.Common.Interfaces;

public interface ICurrentUser
{
    string? Name { get; }

    long Id { get; }

    string? Email { get; }

    bool IsAuthenticated { get; }

    IEnumerable<Claim>? Claims { get; }

    string? IpAddress { get; }
}