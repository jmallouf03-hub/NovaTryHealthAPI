﻿using NovaHealth.Application.Common.Interfaces;
using NovaHealth.Application.Common.Mailing;
using NovaHealth.Application.Common.Sms;
using NovaHealth.Application.Identity;
using MediatR;
using Microsoft.EntityFrameworkCore;

namespace NovaHealth.Application.Users.Command.ChangeUserPassword;

public record ChangeUserPasswordRequest(long UserId, string OldPassword, string NewPassword, string ConfirmPassword) : IRequest<bool>;

public class ChangeUserPasswordRequestHandler : IRequestHandler<ChangeUserPasswordRequest, bool>
{
    private readonly INovaHealthDbContext _novaHealthDbContext;
    private readonly IEmailTemplateService _emailTemplateService;
    private readonly IMailService _mailService;
    private readonly IIdentityService _identityService;
    private readonly ISmsService _smsService;

    public ChangeUserPasswordRequestHandler(INovaHealthDbContext novaHealthDbContext, IEmailTemplateService emailTemplateService, IMailService mailService, IIdentityService identityService, ISmsService smsService)
    {
        _novaHealthDbContext = novaHealthDbContext;
        _emailTemplateService = emailTemplateService;
        _mailService = mailService;
        _identityService = identityService;
        _smsService = smsService;
    }

    public async Task<bool> Handle(ChangeUserPasswordRequest request, CancellationToken cancellationToken)
    {
        var user = await _identityService.ValidatePassword(request.UserId, request.OldPassword);

        var hashedNewPassword = SecurityHelper.HashPassword(request.NewPassword);

        await _novaHealthDbContext.SaveChangesAsync(cancellationToken);

        var decryptedEmail = SecurityHelper.Decrypt(user.Email);

        //var notificationPreference = await _novaHealthDbContext.NotificationPreferences.FirstOrDefaultAsync(x => x.UserId == request.UserId, cancellationToken);

        //if (notificationPreference != null)
        //{
        //    if (notificationPreference.Preference == NotificationPreferenceOption.Phone || notificationPreference.Preference == NotificationPreferenceOption.Both)
        //    {
        //        if (!string.IsNullOrEmpty(notificationPreference.PhoneNumber))
        //        {
        //            string message = $"Hi {user.FirstName},\n\n" +
        //                             "Your password has been successfully changed.\n\n" +
        //                             "If you did not make this change, please contact support immediately.\n\n" +
        //                             "- Chalice Health";

        //            var smsRequest = new SmsRequest
        //            {
        //                PhoneNumber = notificationPreference.PhoneNumber,
        //                Message = message
        //            };

        //            var smsResponse = await _smsService.SendAsync(smsRequest);
        //        }
        //    }
        //}

        //if (notificationPreference == null || notificationPreference.Preference == NotificationPreferenceOption.Email || notificationPreference.Preference == NotificationPreferenceOption.Both)
        //{
        //    var mailRequest = new MailRequest(
        //    new List<string> { decryptedEmail }, "Your Account Password Has Been Changed",
        //    _emailTemplateService.GenerateEmailTemplate("change-password", new
        //    {
        //        user.FirstName,
        //    }));

        //    await _mailService.SendAsync(mailRequest, cancellationToken);
        //}

        return true;
    }
}