﻿using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using NovaHealth.Application.Common.Interfaces;
using NovaHealth.Application.Common.Mailing;
using NovaHealth.Application.Common.Sms;
using NovaHealth.Application.Identity;
using NovaHealth.Domain.Entities;

namespace NovaHealth.Application.Users.Command.CreateUserPassword;

public record CreateUserPasswordRequest(string NewPassword, string ConfirmPassword, string Hash) : IRequest<bool>;

public class CreateUserPasswordRequestHandler : IRequestHandler<CreateUserPasswordRequest, bool>
{
    private readonly INovaHealthDbContext _novaHealthDbContext;
    private readonly IEmailTemplateService _emailTemplateService;
    private readonly IMailService _mailService;
    private readonly IIdentityService _identityService;
    private readonly ISmsService _smsService;

    public CreateUserPasswordRequestHandler(INovaHealthDbContext novaHealthDbContext, IEmailTemplateService emailTemplateService, IMailService mailService, IIdentityService identityService, ISmsService smsService)
    {
        _novaHealthDbContext = novaHealthDbContext;
        _emailTemplateService = emailTemplateService;
        _mailService = mailService;
        _identityService = identityService;
        _smsService = smsService;
    }

    public async Task<bool> Handle(CreateUserPasswordRequest request, CancellationToken cancellationToken)
    {
        var user = await _identityService.CheckUser(request.Hash);
        var hash = Base64UrlEncoder.Decode(request.Hash);
        var decoded = SecurityHelper.Decrypt(hash);
        var separatedParams = decoded.Split(new[] { "$$$" }, StringSplitOptions.None);

        // Check for valid token format
        if (separatedParams.Length < 4)
            throw new Exception("Invalid token");

        var actionType = separatedParams[2];
        var token = separatedParams[3];

        // Check if user already has a password
        if (!string.IsNullOrEmpty(user.Password) && actionType != "forgot")
            throw new Exception("Your password is already initiated.");

        // Validate new and confirm password
        if (!string.Equals(request.NewPassword.Trim(), request.ConfirmPassword.Trim(), StringComparison.OrdinalIgnoreCase))
            throw new Exception("Passwords do not match.");

        // Token validations
        if (!Guid.TryParse(token, out var tokenGuid))
            throw new Exception("Invalid token format.");

        var tokenEntry = await _novaHealthDbContext.MagicTokens
            .FirstOrDefaultAsync(x => x.Token == tokenGuid && x.UserId == user.Id, cancellationToken);

        if (tokenEntry == null)
            throw new Exception("Invalid or expired token.");

        if (tokenEntry.IsUsed)
            throw new Exception("Token already used.");

        if (tokenEntry.Expiry < DateTime.UtcNow)
            throw new Exception("Token has expired. Please request a new one.");

        // Update password
        user.Password = SecurityHelper.HashPassword(request.NewPassword);
        user.IsActive = true;
        user.IsEmailVerified = true;
        tokenEntry.IsUsed = true;
        tokenEntry.IsActive = false;
        await _novaHealthDbContext.SaveChangesAsync(cancellationToken);

        // Send mail
        var mailSubject = actionType == "forgot"
            ? "Your Password Has Been Successfully Reset"
            : "Your Password Has Been Successfully Created";

        var templateKey = actionType == "forgot"
            ? "password-reset"
            : "password-create-success";

        var mailRequest = new MailRequest(
            new List<string> { user.Email },
            mailSubject,
            _emailTemplateService.GenerateEmailTemplate(templateKey, new
            {
                user.FirstName
            }));

        await _mailService.SendAsync(mailRequest, cancellationToken);

        return true;
    }
}