﻿using NovaHealth.Application.Common.Validations;
using FluentValidation;

namespace NovaHealth.Application.Users.Command.CreateUserPassword;

public class CreateUserPasswordRequestValidator : AbstractValidator<CreateUserPasswordRequest>
{
    public CreateUserPasswordRequestValidator()
    {
        RuleFor(x => x.NewPassword).ValidatePassword();

        RuleFor(x => x.ConfirmPassword).Equal(x => x.NewPassword).WithMessage("Passwords do not match.");

        RuleFor(x => x.Hash).Cascade(CascadeMode.Stop).NotEmpty().WithMessage("Invalid password reset token");
    }
}