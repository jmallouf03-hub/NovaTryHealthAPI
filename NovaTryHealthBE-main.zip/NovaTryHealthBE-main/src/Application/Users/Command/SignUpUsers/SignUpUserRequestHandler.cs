﻿using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using NovaHealth.Application.Auth.Jwt;
using NovaHealth.Application.Common.Interfaces;
using NovaHealth.Application.Common.Mailing;
using NovaHealth.Application.Common.Sms;
using NovaHealth.Domain.Entities;
using System.Text;

namespace NovaHealth.Application.Users.Command.SignUpUsers;

public class SignUpUserRequestHandler : IRequestHandler<SignUpUserRequest, bool>
{
    private readonly INovaHealthDbContext _novaHealthDbContext;
    private readonly IEmailTemplateService _emailTemplateService;
    private readonly IMailService _mailService;
    private readonly ISmsService _smsService;
    private readonly AppSettings _appSettings;
    private readonly JwtSettings _jwtSettings;
    public SignUpUserRequestHandler(INovaHealthDbContext novaHealthDbContext, IEmailTemplateService emailTemplateService, IMailService mailService, ISmsService smsService, IOptions<AppSettings> appSettings, IOptions<JwtSettings> jwtSettings)
    {
        _novaHealthDbContext = novaHealthDbContext;
        _emailTemplateService = emailTemplateService;
        _mailService = mailService;
        _smsService = smsService;
        _appSettings = appSettings.Value;
        _jwtSettings = jwtSettings.Value;
    }
    public async Task<bool> Handle(SignUpUserRequest request, CancellationToken cancellationToken)
    {
        string email = request.Email.Trim().ToLower();
        var existingUser = await _novaHealthDbContext.Users
                            .FirstOrDefaultAsync(x => x.Email == email && !x.IsDeleted, cancellationToken);

        async Task SendMagicLinkAsync(User user)
        {
            var magicToken = new MagicToken
            {
                UserId = user.Id,
                Email = user.Email,
                Expiry = DateTime.UtcNow.AddMinutes(15),
                IsUsed = false,
                CreatedDate = DateTime.UtcNow
            };

            _novaHealthDbContext.MagicTokens.Add(magicToken);
            await _novaHealthDbContext.SaveChangesAsync(cancellationToken);

            string data = $"{user.Email}$$${user.Id}$$${"sinup"}$$${magicToken.Token}";
            string encryptedData = SecurityHelper.Encrypt(data);
            string hash = Base64UrlEncoder.Encode(Encoding.UTF8.GetBytes(encryptedData));
            string magicLink = $"{_appSettings.NovaHealthUrl}set-password?token={hash}";

            var mailRequest = new MailRequest(new List<string> { user.Email }, "Create Password",
                               _emailTemplateService.GenerateEmailTemplate("password-create-Link", new
                               {
                                   user.FirstName,
                                   MagicLink = magicLink
                               }));
            await _mailService.SendAsync(mailRequest, cancellationToken);
        }

        if (existingUser != null)
        {
            if (string.IsNullOrEmpty(existingUser.Password))
            {
                await SendMagicLinkAsync(existingUser);
                return true;
            }

            throw new Exception("This email address is already registered with us.");
        }

        var newUser = new User
        {
            FirstName = request.FirstName,
            LastName = request.LastName,
            CreatedDate = DateTime.UtcNow,
            Email = email,
            //DateOfBirth = request.DateOfBirth,
            IsActive = false,
            IsDeleted = false,
            IsDisabledByAdmin = true,
            IsEmailVerified = false,
        };

        _novaHealthDbContext.Users.Add(newUser);
        await _novaHealthDbContext.SaveChangesAsync(cancellationToken);


        var doctorRole = await _novaHealthDbContext.Roles
            .FirstOrDefaultAsync(r => r.RoleType == RoleType.Doctor, cancellationToken);

        if (doctorRole == null)
        {
            throw new Exception("Doctor role not found in Roles table.");
        }

        var userRole = new UserRole
        {
            UserId = newUser.Id,
            RoleId = doctorRole.Id,
            IsActive = true,
            IsDeleted = false
        };

        _novaHealthDbContext.UserRoles.Add(userRole);


        if (request.CategoryIds.Any())
        {
            foreach (var categoryId in request.CategoryIds)
            {
                var doctorCategory = new DoctorCategory
                {
                    UserId = newUser.Id,
                    CategoryId = categoryId
                };
                _novaHealthDbContext.DoctorCategories.Add(doctorCategory);
            }
        }

        await _novaHealthDbContext.SaveChangesAsync(cancellationToken);

        await SendMagicLinkAsync(newUser);
        return true;
    }
}