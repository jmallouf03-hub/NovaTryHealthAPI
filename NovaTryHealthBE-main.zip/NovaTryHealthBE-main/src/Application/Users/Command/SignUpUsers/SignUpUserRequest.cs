﻿using MediatR;

namespace NovaHealth.Application.Users.Command.SignUpUsers;



public class SignUpUserRequest : IRequest<bool>
{
    public string FirstName { get; set; } = null!;

    public string LastName { get; set; } = null!;

    public string Email { get; set; } = null!;

    //public DateTime? DateOfBirth { get; set; }

    public List<long> CategoryIds { get; set; } = new List<long>();

}