﻿using FluentValidation;

namespace NovaHealth.Application.Users.Command.SignUpUsers;
public class SignUpUserRequestValidator : AbstractValidator<SignUpUserRequest>
{
    public SignUpUserRequestValidator()
    {
        RuleFor(x => x.FirstName).NotEmpty().WithMessage("First Name is required.")
        .MaximumLength(50).WithMessage("First Name must not exceed 100 characters.");

        RuleFor(x => x.LastName).NotEmpty().WithMessage("Last Name is required.")
        .MaximumLength(50).WithMessage("Last Name must not exceed 100 characters.");

        RuleFor(x => x.Email).NotEmpty().WithMessage("Email is required.")
        .Matches(@"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$")
        .WithMessage("A valid email address is required.");

        //RuleFor(x => x.Password)
        //       .NotEmpty().When(x => string.IsNullOrEmpty(x.Password)).WithMessage("Password is required.")
        //       .MinimumLength(8).When(x => !string.IsNullOrEmpty(x.Password)).WithMessage("Password must be at least 8 characters long.");
    }
}