﻿using NovaHealth.Application.Common.Exceptions;
using NovaHealth.Application.Common.Interfaces;
using MediatR;
using Microsoft.EntityFrameworkCore;

namespace NovaHealth.Application.Users.Command.AdminChangeStatus;

public record AdminChangeStatusRequest : IRequest<bool>
{
    public long UserId { get; set; }

    public CredentialStatusTypeOption CredentialStatus { get; set; }
}
public class AdminChangeStatusRequestHandler : IRequestHandler<AdminChangeStatusRequest, bool>
{
    private readonly INovaHealthDbContext _novaHealthDbContext;

    public AdminChangeStatusRequestHandler(INovaHealthDbContext novaHealthDbContext)
    {
        _novaHealthDbContext = novaHealthDbContext;
    }

    public async Task<bool> Handle(AdminChangeStatusRequest request, CancellationToken cancellationToken)
    {
        //var providerProfileDetails = await _novaHealthDbContext.ProviderProfileDetails.FirstOrDefaultAsync(x => x.UserId == request.UserId, cancellationToken);

        //if (providerProfileDetails == null)
        //{
        //    throw new NotFoundException($"Cannot find this provider profile with id :{request.UserId}");
        //}

        //if (request.CredentialStatus == CredentialStatusTypeOption.CompletedAndApproved)
        //{
        //    providerProfileDetails.IsVerified = true;
        //}

        //else
        //{
        //    providerProfileDetails.IsVerified = false;
        //}

        //providerProfileDetails.CredentialStatus = request.CredentialStatus;

        await _novaHealthDbContext.SaveChangesAsync(cancellationToken);

        return true;
    }
}