﻿using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using NovaHealth.Application.Common.Interfaces;
using NovaHealth.Application.Common.Mailing;
using NovaHealth.Application.Common.Sms;
using NovaHealth.Domain.Entities;
using System.Text;

namespace NovaHealth.Application.Users.Command.ForgotUserPassword;
public record ForgotUserPasswordRequest(string Email) : IRequest<bool>;
public class ForgotUserPasswordRequestHandler : IRequestHandler<ForgotUserPasswordRequest, bool>
{
    private readonly INovaHealthDbContext _novaHealthDbContext;
    private readonly IEmailTemplateService _emailTemplateService;
    private readonly IMailService _mailService;
    private readonly AppSettings _appSettings;
    private readonly ISmsService _smsService;

    public ForgotUserPasswordRequestHandler(INovaHealthDbContext novaHealthDbContext, IEmailTemplateService emailTemplateService, IMailService mailService, IOptions<AppSettings> appSettings, ISmsService smsService)
    {
        _novaHealthDbContext = novaHealthDbContext;
        _emailTemplateService = emailTemplateService;
        _mailService = mailService;
        _appSettings = appSettings.Value;
        _smsService = smsService;
    }

    public async Task<bool> Handle(ForgotUserPasswordRequest request, CancellationToken cancellationToken)
    {
        //bool IsOtpBypassed = _appSettings.IsOtpBypassed;

        //var otpRecord = await _novaHealthDbContext.OTPs
        //    .OrderByDescending(o => o.Id)
        //   .FirstOrDefaultAsync(o => o.UserId == request.UserId, cancellationToken);

        //if (otpRecord == null)
        //{
        //    throw new NotFoundException("Invalid OTP");
        //}

        //if (!IsOtpBypassed)
        //{
        //    if (otpRecord.OtpCode != request.Otp)
        //    {
        //        throw new NotFoundException("Invalid OTP");
        //    }

        //    if (otpRecord.ExpiryDate < DateTime.Now)
        //    {
        //        throw new NotFoundException("OTP has expired.");
        //    }
        //}

        //_novaHealthDbContext.OtpStores.Update(otpRecord);
        //await _novaHealthDbContext.SaveChangesAsync(cancellationToken);

        var user = await _novaHealthDbContext.Users.FirstOrDefaultAsync(u => u.Email == request.Email, cancellationToken);

        if (user == null)
        {
            throw new Exception("User not found.");
        }

        var magicToken = new MagicToken
        {
            UserId = user.Id,
            Email = user.Email,
            Expiry = DateTime.UtcNow.AddMinutes(15),
            IsUsed = false,
            CreatedDate = DateTime.UtcNow
        };
        _novaHealthDbContext.MagicTokens.Add(magicToken);
        await _novaHealthDbContext.SaveChangesAsync(cancellationToken);


                string data = $"{user.Email}$$${user.Id}$$${"forgot"}$$${magicToken.Token}";
                string encryptedData = SecurityHelper.Encrypt(data);
                string hash = Base64UrlEncoder.Encode(Encoding.UTF8.GetBytes(encryptedData));
                string magicLink = $"{_appSettings.NovaHealthUrl}set-password?token={hash}";

        var logoPath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "images", "logo.png");
        byte[]? logoBytes = null;

        if (File.Exists(logoPath))
        {
            logoBytes = File.ReadAllBytes(logoPath);
        }


        //            string message = $"Hi {user.FirstName},\n"
        //              + "You recently requested to reset the password for your Chalice Health account.\n"
        //              + $"Click the link below or copy and paste it into your browser to proceed:\n{resetPasswordUrl}\n" +
        //              $"Chalice Health";
        //            var smsRequest = new SmsRequest
        //            {
        //                PhoneNumber = notificationPreference.PhoneNumber,
        //                Message = message
        //            };
        //            var smsResponse = await _smsService.SendAsync(smsRequest);

        var resetPasswordMailRequest = new MailRequest(new List<string> { user.Email }, "Reset Your Password",
        _emailTemplateService.GenerateEmailTemplate("forgot-password", new
        {
            FirstName = user.FirstName,
            ResetUrl = magicLink,
        }),
        attachmentData: logoBytes != null ? new Dictionary<string, byte[]>
        {{ "NovaHealthLogo", logoBytes }} : null);

        await _mailService.SendAsync(resetPasswordMailRequest, cancellationToken);

        return true;
    }
}
