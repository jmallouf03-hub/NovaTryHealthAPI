﻿using AutoMapper;
using AutoMapper.QueryableExtensions;
using NovaHealth.Application.Common.Interfaces;
using NovaHealth.Application.Common.Mappings;
using NovaHealth.Application.Common.Models;
using MediatR;
using Microsoft.EntityFrameworkCore;
using System.Linq.Dynamic.Core;

namespace NovaHealth.Application.LoginLogs.Queries.GetLoginLogs;

public class GetLoginLogsRequest : PaginationFilter, IRequest<PaginationResponse<GetLoginLogsResponse>> { }

public class GetLoginLogsRequestHandler : IRequestHandler<GetLoginLogsRequest, PaginationResponse<GetLoginLogsResponse>>
{
    private readonly INovaHealthDbContext _novaHealthDbContext;
    private readonly IMapper _mapper;

    public GetLoginLogsRequestHandler(INovaHealthDbContext novaHealthDbContext, IMapper mapper)
    {
        _novaHealthDbContext = novaHealthDbContext;
        _mapper = mapper;
    }

    public async Task<PaginationResponse<GetLoginLogsResponse>> Handle(GetLoginLogsRequest request, CancellationToken cancellationToken)
    {
        var loginLogs = _novaHealthDbContext.LoginLogs
            .Include(x => x.User)
            .Select(x => new GetLoginLogsResponse
            {
                UserId = x.UserId,
                Name = x.User.FirstName + " " + x.User.LastName,
                Browser = x.Browser,
                Version = x.Version,
                IpAddress = x.IpAddress,
                Platform = x.Platform,
                RequestFrom = x.RequestFrom,
                CreatedDate = x.CreatedDate
            });

        if (!string.IsNullOrEmpty(request.Filter))
        {
            loginLogs = loginLogs.Where(request.Filter);
        }

        if (!string.IsNullOrEmpty(request.OrderBy))
        {
            loginLogs = loginLogs.OrderBy(request.OrderBy);
        }
        else
        {
            loginLogs = loginLogs.OrderByDescending(x => x.CreatedDate);
        }

        return await loginLogs.ProjectTo<GetLoginLogsResponse>(_mapper.ConfigurationProvider)
           .PaginatedListAsync(request.PageNumber, request.PageSize);
    }
}