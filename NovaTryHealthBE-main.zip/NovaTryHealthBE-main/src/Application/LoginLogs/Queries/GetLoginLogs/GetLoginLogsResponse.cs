﻿using AutoMapper;

namespace NovaHealth.Application.LoginLogs.Queries.GetLoginLogs;

public record GetLoginLogsResponse
{
    public long UserId { get; set; }

    public string Name { get; set; } = null!;

    public string? Platform { get; set; }

    public string? Browser { get; set; }

    public string? Version { get; set; }

    public string? RequestFrom { get; set; }

    public string? IpAddress { get; set; }

    public DateTimeOffset CreatedDate { get; set; }

    private class Mapping : Profile
    {
        public Mapping()
        {
            CreateMap<GetLoginLogsResponse, GetLoginLogsResponse>();
        }
    }
}
