﻿using MediatR;
using Microsoft.AspNetCore.Http;

namespace NovaHealth.Application.LayoutSettings.Command.UpdateLayoutSettings;

public class LayoutSettingRequest : IRequest<bool>
{
    public long QuestionId { get; set; }
    public long LayoutId { get; set; } 
    public string Name { get; set; } = null!;
    public LayoutHeaderSettingRequest   LayoutHeaderSetting { get; set; } = new();

    public LayoutFooterSettingRequest LayoutFooterSetting { get; set; } = new();    

    public LayoutAnswerSettingRequest LayoutAnswerSetting { get; set; } = new();

    public LayoutTitleSettingRequest LayoutTitleSetting { get; set; } = new();

    public GlobalLayoutSettingRequest GlobalLayoutSetting { get; set; } = new();

}


public class LayoutHeaderSettingRequest
{
    public string? NavbarLeftRadius { get; set; }
    public string? HeaderBackgroundColor { get; set; }
    public IFormFile? HeaderLogo { get; set; }
    public string? CustomProgressBarSegments { get; set; }
    public bool BackButtonGlobal { get; set; }
    public bool BackButtonOnlyCurrent { get; set; }
    public string? ProgressBarColor { get; set; }
    public string? ProgressBarBackgroundColor { get; set; }
    public string? BackButtonColor { get; set; }
    public string? HeaderTextColor { get; set; }
    public bool ShowHelpButton { get; set; }
    public string? HelpButtonSupportHours { get; set; }
    public string? HelpButtonColor { get; set; }
    public string? HelpButtonTextColor { get; set; }
}


public class LayoutFooterSettingRequest 
{
    public long LayoutId { get; set; }
    public bool ShowFooter { get; set; }
    public string? PrimaryTextColor { get; set; }
    public string? SecondaryTextColor { get; set; }
    public string? DividerColor { get; set; }
    public string? BackgroundColor { get; set; }
    public IFormFile? FooterLogo { get; set; }
    public string? CompanyName { get; set; }
    public string? PhoneNumber { get; set; }
    public string? EmailAddress { get; set; }
    public string? HelpCenterURL { get; set; }
    public string? CopyrightText { get; set; }
    public bool ShowFooterSocialIcons { get; set; }
    public string? FacebookURL { get; set; }
    public string? InstagramURL { get; set; }
    public string? TwitterURL { get; set; }
    public string? LinkedInURL { get; set; }
}
public class LayoutAnswerSettingRequest 
{
 //   public int? QuestionId { get; set; }
    public string? AnswerBackgroundColor { get; set; }
    public string? AnswerTextColor { get; set; }
    public string? AnswerHighlightColor { get; set; }
    public string? AnswerOutlineColor { get; set; }
}

public class LayoutTitleSettingRequest
{
    public string? PreHeader { get; set; }
    public bool ShowPreHeader { get; set; } = false;
    public string? PreHeaderColor { get; set; }

    public string? MainHeader { get; set; }
    public string? ShowMainHeader { get; set; }
    public string? MainHeaderColor { get; set; }

    public string? SubHeader { get; set; }
    public bool ShowSubHeader { get; set; }
    public string? SubHeaderColor { get; set; }

    public string? Banner { get; set; }
    public bool ShowBanner { get; set; }
    public string? BannerTextColor { get; set; }

    public string? BannerBGColor { get; set; }

    public bool ShowBannerIcon { get; set; }
    public string? BannerIconColor { get; set; }

}

public class GlobalLayoutSettingRequest
{
    public string? RoundedBoarderRaduis { get; set; }

    public string? NavigationButtonWidth { get; set; }

    public long? QuestionTemplateId { get; set; } = null;

    //public long QuestionTemplateId { get; set; } = 1;
}