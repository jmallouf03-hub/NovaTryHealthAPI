﻿using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using NovaHealth.Application.Common.FileStorage;
using NovaHealth.Application.Common.Interfaces;

namespace NovaHealth.Application.LayoutSettings.Command.UpdateLayoutSettings;
public class AddUpdateLayoutSettingByLayoutIdHandler : IRequestHandler<LayoutSettingRequest, bool>
{
    private readonly INovaHealthDbContext _novaHealthDbContext;
    private readonly Func<FileStorageOption?, IFileStorageService> _fileStorageFunc;
    private readonly AppSettings _appSettings;
    public AddUpdateLayoutSettingByLayoutIdHandler(Func<FileStorageOption?, IFileStorageService> fileStorageFunc, INovaHealthDbContext novaHealthDbContext, IOptions<AppSettings> appSettings)
    {
        _novaHealthDbContext = novaHealthDbContext;
        _fileStorageFunc = fileStorageFunc;
        _appSettings = appSettings.Value;
    }
    public async Task<bool> Handle(LayoutSettingRequest request, CancellationToken cancellationToken)
    {
        var QuestionTitle = await _novaHealthDbContext.Questions
            .Where(q => q.Id == request.QuestionId)
            .FirstOrDefaultAsync(cancellationToken);

         if (QuestionTitle == null)
            throw new Exception($"Question with Id {request.QuestionId} not found.");

        QuestionTitle.Name = request.Name;
         QuestionTitle.Title= request.LayoutTitleSetting.MainHeader;

        _novaHealthDbContext.Update(QuestionTitle);
        await _novaHealthDbContext.SaveChangesAsync(cancellationToken);

        var fileStorageService = _fileStorageFunc(_appSettings.DefaultFileStorage);
        var layout = await _novaHealthDbContext.Questions.Include(q => q.Questionnaire).Where(q => q.Id == request.QuestionId).FirstOrDefaultAsync(cancellationToken);
        // .Select(q => q.Questionnaire.QuestionnaireGlobalLayoutId).FirstOrDefaultAsync(cancellationToken);
        if ( request.LayoutId > 0 && layout != null)
        {
            layout.Questionnaire.QuestionnaireGlobalLayoutId = request.LayoutId;
            _novaHealthDbContext.Update(layout);
            await _novaHealthDbContext.SaveChangesAsync(cancellationToken);
        }
        if(layout == null)
            throw new Exception($"Question with Id not found.");

        var layoutHeaderSetting = await _novaHealthDbContext.LayoutHeaderSettings
            .FirstOrDefaultAsync(x => x.LayoutId == layout.Questionnaire.QuestionnaireGlobalLayoutId, cancellationToken);

        if (layoutHeaderSetting == null)
            throw new Exception($"LayoutId  not found");

        layoutHeaderSetting.NavbarLeftRadius = request.LayoutHeaderSetting.NavbarLeftRadius;
        layoutHeaderSetting.LayoutId = layout.Questionnaire.QuestionnaireGlobalLayoutId;
        layoutHeaderSetting.HeaderBackgroundColor = request.LayoutHeaderSetting.HeaderBackgroundColor;
        // layoutHeaderSetting.HeaderLogo = request.LayoutHeaderSetting.HeaderLogo;
        layoutHeaderSetting.CustomProgressBarSegments = request.LayoutHeaderSetting.CustomProgressBarSegments;
        layoutHeaderSetting.BackButtonGlobal = request.LayoutHeaderSetting.BackButtonGlobal;
        layoutHeaderSetting.BackButtonOnlyCurrent = request.LayoutHeaderSetting.BackButtonOnlyCurrent;
        layoutHeaderSetting.ProgressBarColor = request.LayoutHeaderSetting.ProgressBarColor;
        layoutHeaderSetting.ProgressBarBackgroundColor = request.LayoutHeaderSetting.ProgressBarBackgroundColor;
        layoutHeaderSetting.BackButtonColor = request.LayoutHeaderSetting.BackButtonColor;
        layoutHeaderSetting.HeaderTextColor = request.LayoutHeaderSetting.HeaderTextColor;
        layoutHeaderSetting.ShowHelpButton = request.LayoutHeaderSetting.ShowHelpButton;
        layoutHeaderSetting.HelpButtonSupportHours = request.LayoutHeaderSetting.HelpButtonSupportHours;
        layoutHeaderSetting.HelpButtonColor = request.LayoutHeaderSetting.HelpButtonColor;
        layoutHeaderSetting.HelpButtonTextColor = request.LayoutHeaderSetting.HelpButtonTextColor;

        if (request.LayoutHeaderSetting.HeaderLogo != null)
        {
            var fileUploadResponse = await fileStorageService.UploadAsync(new FileUploadRequest
            {
                File = request.LayoutHeaderSetting.HeaderLogo,
                FileTypeOption = FileTypeOption.ProfilePicture,
            }, cancellationToken);

            layoutHeaderSetting.HeaderLogo = fileUploadResponse.SavedTo;
        }
        _novaHealthDbContext.Update(layoutHeaderSetting);
        await _novaHealthDbContext.SaveChangesAsync(cancellationToken);

        var layoutFooterSetting = await _novaHealthDbContext.LayoutFooterSettings
            .FirstOrDefaultAsync(x => x.LayoutId == layout.Questionnaire.QuestionnaireGlobalLayoutId, cancellationToken);
        if (layoutFooterSetting == null)
            throw new Exception($"LayoutId not found");

        layoutFooterSetting.LayoutId = layout.Questionnaire.QuestionnaireGlobalLayoutId;
        layoutFooterSetting.ShowFooter = request.LayoutFooterSetting.ShowFooter;
        layoutFooterSetting.PrimaryTextColor = request.LayoutFooterSetting.PrimaryTextColor;
        layoutFooterSetting.SecondaryTextColor = request.LayoutFooterSetting.SecondaryTextColor;
        layoutFooterSetting.DividerColor = request.LayoutFooterSetting.DividerColor;
        layoutFooterSetting.BackgroundColor = request.LayoutFooterSetting.BackgroundColor;
        //  layoutFooterSetting.FooterLogo = request.LayoutFooterSetting.FooterLogo;
        layoutFooterSetting.CompanyName = request.LayoutFooterSetting.CompanyName;
        layoutFooterSetting.PhoneNumber = request.LayoutFooterSetting.PhoneNumber;
        layoutFooterSetting.EmailAddress = request.LayoutFooterSetting.EmailAddress;
        layoutFooterSetting.HelpCenterURL = request.LayoutFooterSetting.HelpCenterURL;
        layoutFooterSetting.CopyrightText = request.LayoutFooterSetting.CopyrightText;
        layoutFooterSetting.ShowFooterSocialIcons = request.LayoutFooterSetting.ShowFooterSocialIcons;
        layoutFooterSetting.FacebookURL = request.LayoutFooterSetting.FacebookURL;
        layoutFooterSetting.InstagramURL = request.LayoutFooterSetting.InstagramURL;
        layoutFooterSetting.TwitterURL = request.LayoutFooterSetting.TwitterURL;
        layoutFooterSetting.LinkedInURL = request.LayoutFooterSetting.LinkedInURL;

        if (request.LayoutFooterSetting.FooterLogo != null)
        {
            var fileUploadResponse = await fileStorageService.UploadAsync(new FileUploadRequest
            {
                File = request.LayoutFooterSetting.FooterLogo,
                FileTypeOption = FileTypeOption.ProfilePicture,
            }, cancellationToken);

            layoutFooterSetting.FooterLogo = fileUploadResponse.SavedTo;
        }
        _novaHealthDbContext.Update(layoutFooterSetting);
        await _novaHealthDbContext.SaveChangesAsync(cancellationToken);

        var layoutAnswerSetting = await _novaHealthDbContext.LayoutAnswerSettings
            .FirstOrDefaultAsync(x => x.LayoutId == layout.Questionnaire.QuestionnaireGlobalLayoutId, cancellationToken);

        if (layoutAnswerSetting == null)
            throw new Exception($"LayoutId not found");

        layoutHeaderSetting.LayoutId = layout.Questionnaire.QuestionnaireGlobalLayoutId;
        layoutAnswerSetting.AnswerBackgroundColor = request.LayoutAnswerSetting.AnswerBackgroundColor;
        layoutAnswerSetting.AnswerTextColor = request.LayoutAnswerSetting.AnswerTextColor;
        layoutAnswerSetting.AnswerHighlightColor = request.LayoutAnswerSetting.AnswerHighlightColor;

        _novaHealthDbContext.Update(layoutAnswerSetting);
        await _novaHealthDbContext.SaveChangesAsync(cancellationToken);

        var layoutTitleSetting = await _novaHealthDbContext.LayoutTitleSettings
             .FirstOrDefaultAsync(x => x.LayoutId == layout.Questionnaire.QuestionnaireGlobalLayoutId, cancellationToken);

        if (layoutTitleSetting == null)
            throw new Exception($"LayoutTitleSettings not found for LayoutId");

        layoutTitleSetting.LayoutId = layout.Questionnaire.QuestionnaireGlobalLayoutId;
        layoutTitleSetting.PreHeader = request.LayoutTitleSetting.PreHeader;
        layoutTitleSetting.ShowPreHeader = request.LayoutTitleSetting.ShowPreHeader;
        layoutTitleSetting.PreHeaderColor = request.LayoutTitleSetting.PreHeaderColor;
        layoutTitleSetting.MainHeader = request.LayoutTitleSetting.MainHeader;
        layoutTitleSetting.ShowMainHeader = request.LayoutTitleSetting.ShowMainHeader;
        layoutTitleSetting.MainHeaderColor = request.LayoutTitleSetting.MainHeaderColor;
        layoutTitleSetting.SubHeader = request.LayoutTitleSetting.SubHeader;
        layoutTitleSetting.ShowSubHeader = request.LayoutTitleSetting.ShowSubHeader;
        layoutTitleSetting.SubHeaderColor = request.LayoutTitleSetting.SubHeaderColor;
        layoutTitleSetting.Banner = request.LayoutTitleSetting.Banner;
        layoutTitleSetting.ShowBanner = request.LayoutTitleSetting.ShowBanner;
        layoutTitleSetting.BannerTextColor = request.LayoutTitleSetting.BannerTextColor;
        layoutTitleSetting.BannerBGColor = request.LayoutTitleSetting.BannerBGColor;
        layoutTitleSetting.ShowBannerIcon = request.LayoutTitleSetting.ShowBannerIcon;
        layoutTitleSetting.BannerIconColor = request.LayoutTitleSetting.BannerIconColor;

        _novaHealthDbContext.Update(layoutTitleSetting);
        await _novaHealthDbContext.SaveChangesAsync(cancellationToken);


        var layoutGlobalSetting = await _novaHealthDbContext.GlobalLayoutSettings
           .FirstOrDefaultAsync(x => x.LayoutId == layout.Questionnaire.QuestionnaireGlobalLayoutId, cancellationToken);

        if (layoutGlobalSetting == null)
            throw new Exception($"GlobalLayoutSettings not found for LayoutId");

        layoutGlobalSetting.LayoutId = layout.Questionnaire.QuestionnaireGlobalLayoutId;
        layoutGlobalSetting.RoundedBoarderRaduis = request.GlobalLayoutSetting.RoundedBoarderRaduis;
        layoutGlobalSetting.NavigationButtonWidth = request.GlobalLayoutSetting.NavigationButtonWidth;
        layoutGlobalSetting.QuestionTemplateId = request.GlobalLayoutSetting.QuestionTemplateId;

        _novaHealthDbContext.Update(layoutGlobalSetting);
        await _novaHealthDbContext.SaveChangesAsync(cancellationToken);


        return true;
    }
}