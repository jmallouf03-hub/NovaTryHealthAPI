﻿using MediatR;
using Microsoft.EntityFrameworkCore;
using NovaHealth.Application.Common.Exceptions;
using NovaHealth.Application.Common.Interfaces;

namespace NovaHealth.Application.LayoutSettings.Queries.GetLayoutSettings;

public class GetLayoutSettingByLayoutIdRequest : IRequest<GetLayoutSettingResponse>
{
    public long QuestionId { get; set; }
}

public class GetLayoutSettingByQuestionIdRequestHandler : IRequestHandler<GetLayoutSettingByLayoutIdRequest, GetLayoutSettingResponse>
{
    private readonly INovaHealthDbContext _novaHealthDbContext;

    public GetLayoutSettingByQuestionIdRequestHandler(INovaHealthDbContext novaHealthDbContext)
    {
        _novaHealthDbContext = novaHealthDbContext;
    }

    public async Task<GetLayoutSettingResponse> Handle(GetLayoutSettingByLayoutIdRequest request, CancellationToken cancellationToken)
    {
        var layoutId = await _novaHealthDbContext.Questions.Include(q => q.Questionnaire).Where(q => q.Id == request.QuestionId)
                      .Select(q => q.Questionnaire.QuestionnaireGlobalLayoutId).FirstOrDefaultAsync(cancellationToken);

        var header = await _novaHealthDbContext.LayoutHeaderSettings
            .AsNoTracking()
            .FirstOrDefaultAsync(x => x.LayoutId == layoutId, cancellationToken);

        var footer = await _novaHealthDbContext.LayoutFooterSettings
            .AsNoTracking()
            .FirstOrDefaultAsync(x => x.LayoutId == layoutId, cancellationToken);

        var answer = await _novaHealthDbContext.LayoutAnswerSettings
            .AsNoTracking()
            .FirstOrDefaultAsync(x => x.LayoutId == layoutId, cancellationToken);

        var title = await _novaHealthDbContext.LayoutTitleSettings
            .AsNoTracking()
            .FirstOrDefaultAsync(x => x.LayoutId == layoutId, cancellationToken);

        var global = await _novaHealthDbContext.GlobalLayoutSettings
      .AsNoTracking()
      .FirstOrDefaultAsync(x => x.LayoutId == layoutId, cancellationToken);

        //var question = await _novaHealthDbContext.Questions.Include(q=>q.QuestionType).Include(q=>q.QuestionProducts)
        //  .Include(q => q.Answers)
        //  .FirstOrDefaultAsync(q => q.Id == request.QuestionId && !q.IsDeleted, cancellationToken);


        var question = await _novaHealthDbContext.Questions.Include(q => q.QuestionType).Include(q => q.QuestionProducts)
                      .ThenInclude(qp => qp.Product).ThenInclude(p => p.Variants).Include(q => q.QuestionProducts).ThenInclude(qp => qp.Product)
                     .ThenInclude(p => p.Ingredients).Include(q => q.Answers)
                     .FirstOrDefaultAsync(q => q.Id == request.QuestionId && !q.IsDeleted, cancellationToken);


        if (question == null)
            throw new NotFoundException("Question not found.");


        if (header == null && footer == null && answer == null && title == null && global == null)
            throw new Exception($"No settings found for LayoutId ");

        return new GetLayoutSettingResponse
        {
            QuestionOptionResponse = question == null ? new GetQuestionByIdResponse() : new GetQuestionByIdResponse
            {
                Id = question.Id,
                QuestionnaireId = question.QuestionnaireId,
                Title = question.Title,
                Name = question.Name,
                QuestionTypeName = question.QuestionType.Type,
                QuestionSpecialVisitId = question.QuestionSpecialVisitId,
                QuestionTypeId = question.QuestionTypeId,

                AnswerOptions = question.Answers?.Select(a => new GetAnswerOptionResponse
                {
                    Id = a.Id,
                    Text = a.Text,
                    Priority = a.Priority,
                    NextQuestionId = a.NextQuestionId,
                    Flag = a.Flag
                }).ToList(),
                ProductIds = question.QuestionProducts?.Where(a => a.ProductId.HasValue).Select(a => a.ProductId.Value).ToList(),
                Products = question.QuestionProducts?
                .Where(qp => qp.Product != null && !qp.Product.IsDeleted)
                .Select(qp => new GetProductsByIdsResponse
                {
                    Id = qp.Product.Id,
                    DrugName = qp.Product.DrugName,
                    BrandName = qp.Product.BrandName,
                    ShortName = qp.Product.ShortName,
                    LabelerName = qp.Product.LabelerName,
                    GenericName = qp.Product.GenericName,
                    DosageForm = qp.Product.DosageForm,
                    ConsultOnlyPrice = qp.Product.ConsultOnlyPrice,
                    ProductType = qp.Product.ProductType,
                    RegularImageUrlFileName = qp.Product.Variants.Select(x => x.RegularImageUrlFileName).FirstOrDefault(),
                    RegularImageUrlFilePath = qp.Product.Variants.Select(x => x.RegularImageUrlFilePath).FirstOrDefault(),
                    TransparentImageUrlFileName = qp.Product.Variants.Select(x => x.TransparentImageUrlFileName).FirstOrDefault(),
                    TransparentImageUrlFilePath = qp.Product.Variants.Select(x => x.TransparentImageUrlFilePath).FirstOrDefault(),
                }).ToList(),


            },

            LayoutHeaderSetting = header == null ? new LayoutHeaderSettingResponse() : new LayoutHeaderSettingResponse
            {
                NavbarLeftRadius = header.NavbarLeftRadius,
                HeaderBackgroundColor = header.HeaderBackgroundColor,
                HeaderLogo = header.HeaderLogo,
                CustomProgressBarSegments = header.CustomProgressBarSegments,
                BackButtonGlobal = header.BackButtonGlobal,
                BackButtonOnlyCurrent = header.BackButtonOnlyCurrent,
                ProgressBarColor = header.ProgressBarColor,
                ProgressBarBackgroundColor = header.ProgressBarBackgroundColor,
                BackButtonColor = header.BackButtonColor,
                HeaderTextColor = header.HeaderTextColor,
                ShowHelpButton = header.ShowHelpButton,
                HelpButtonSupportHours = header.HelpButtonSupportHours,
                HelpButtonColor = header.HelpButtonColor,
                HelpButtonTextColor = header.HelpButtonTextColor
            },
            LayoutFooterSetting = footer == null ? new LayoutFooterSettingResponse() : new LayoutFooterSettingResponse
            {
                LayoutId = footer.LayoutId,
                ShowFooter = footer.ShowFooter,
                PrimaryTextColor = footer.PrimaryTextColor,
                SecondaryTextColor = footer.SecondaryTextColor,
                DividerColor = footer.DividerColor,
                BackgroundColor = footer.BackgroundColor,
                FooterLogo = footer.FooterLogo,
                CompanyName = footer.CompanyName,
                PhoneNumber = footer.PhoneNumber,
                EmailAddress = footer.EmailAddress,
                HelpCenterURL = footer.HelpCenterURL,
                CopyrightText = footer.CopyrightText,
                ShowFooterSocialIcons = footer.ShowFooterSocialIcons,
                FacebookURL = footer.FacebookURL,
                InstagramURL = footer.InstagramURL,
                TwitterURL = footer.TwitterURL,
                LinkedInURL = footer.LinkedInURL
            },
            LayoutAnswerSetting = answer == null ? new LayoutAnswerSettingResponse() : new LayoutAnswerSettingResponse
            {
                //  QuestionId = answer.QuestionId,
                AnswerBackgroundColor = answer.AnswerBackgroundColor,
                AnswerTextColor = answer.AnswerTextColor,
                AnswerHighlightColor = answer.AnswerHighlightColor,
                AnswerOutlineColor = answer.AnswerOutlineColor
            },

            LayoutTitleSetting = title == null ? new LayoutTitleSettingResponse() : new LayoutTitleSettingResponse
            {
                LayoutId = title.LayoutId,
                PreHeader = title.PreHeader,
                ShowPreHeader = title.ShowPreHeader,
                PreHeaderColor = title.PreHeaderColor,
                MainHeader = title.MainHeader,
                ShowMainHeader = title.ShowMainHeader,
                MainHeaderColor = title.MainHeaderColor,
                SubHeader = title.SubHeader,
                ShowSubHeader = title.ShowSubHeader,
                SubHeaderColor = title.SubHeaderColor,
                Banner = title.Banner,
                ShowBanner = title.ShowBanner,
                BannerTextColor = title.BannerTextColor,
                BannerBGColor = title.BannerBGColor,
                ShowBannerIcon = title.ShowBannerIcon,
                BannerIconColor = title.BannerIconColor
            },

            GlobalLayoutSetting = global == null ? new GlobalLayoutSettingResponse() : new GlobalLayoutSettingResponse
            {
                RoundedBoarderRaduis = global.RoundedBoarderRaduis,
                NavigationButtonWidth = global.NavigationButtonWidth,
                QuestionTemplateId = global.QuestionTemplateId
            }

        };
    }
}
