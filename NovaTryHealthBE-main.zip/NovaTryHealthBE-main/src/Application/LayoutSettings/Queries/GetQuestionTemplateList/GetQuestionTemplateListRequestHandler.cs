﻿using AutoMapper;
using AutoMapper.QueryableExtensions;
using MediatR;
using Microsoft.EntityFrameworkCore;
using NovaHealth.Application.Common.Interfaces;
using NovaHealth.Application.Common.Mappings;
using NovaHealth.Application.Common.Models;
using System.Linq.Dynamic.Core;


namespace NovaHealth.Application.LayoutSettings.Queries.GetQuestionTemplateList;

public class GetQuestionTemplateListRequest : PaginationFilter, IRequest<PaginationResponse<GetQuestionTemplateListResponse>> { }

public class GetQuestionTemplateListRequestHandler : IRequestHandler<GetQuestionTemplateListRequest, PaginationResponse<GetQuestionTemplateListResponse>>
{
    private readonly INovaHealthDbContext _novaHealthDbContext;
    private readonly IMapper _mapper;

    public GetQuestionTemplateListRequestHandler(INovaHealthDbContext novaHealthDbContext, IMapper mapper)
    {
        _novaHealthDbContext = novaHealthDbContext;
        _mapper = mapper;
    }

    public async Task<PaginationResponse<GetQuestionTemplateListResponse>> Handle(GetQuestionTemplateListRequest request, CancellationToken cancellationToken)
    {

        var query = _novaHealthDbContext.QuestionTemplates
          .AsNoTracking()
          .Select(x => new GetQuestionTemplateListResponse
          {
              Id = x.Id,
              Name = x.TemplateName,
          });

        // Apply filter if provided
        if (!string.IsNullOrEmpty(request.Filter))
        {
            query = query.Where(request.Filter);
        }

        // Apply order
        if (!string.IsNullOrEmpty(request.OrderBy))
        {
            query = query.OrderBy(request.OrderBy);
        }
        else
        {
            query = query.OrderBy(x => x.Id);
        }
        return await query.ProjectTo<GetQuestionTemplateListResponse>(_mapper.ConfigurationProvider)
                 .PaginatedListAsync(request.PageNumber, request.PageSize);
    }
}
    

