﻿using AutoMapper;
namespace NovaHealth.Application.LayoutSettings.Queries.GetQuestionTemplateList;

public class GetQuestionTemplateListResponse
{
    public long Id { get; set; }
    public string Name { get; set; } = null!;

    public class Mapping : Profile
    {
        public Mapping()
        {
            CreateMap<GetQuestionTemplateListResponse, GetQuestionTemplateListResponse>();
        }
    }
}
