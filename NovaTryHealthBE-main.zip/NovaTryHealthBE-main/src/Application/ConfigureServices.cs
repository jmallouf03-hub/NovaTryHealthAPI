﻿using System.Reflection;
using FluentValidation;
using MediatR;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using NovaHealth.Application.Auth.Jwt;
using NovaHealth.Application.Common.Behaviours;
using NovaHealth.Application.Identity;
using NovaHealth.Application.Identity.Tokens.Services;
using Stripe;
using Stripe.Checkout;
using IdentityService = NovaHealth.Application.Identity.IdentityService;
using NovaHealth.Application.GoogleCalendar;

namespace NovaHealth.Application;

public static class ConfigureServices
{
    public static IServiceCollection AddApplicationServices(this IServiceCollection services, IConfiguration configuration)
    {
        services.AddAutoMapper(Assembly.GetExecutingAssembly());
        services.AddValidatorsFromAssembly(Assembly.GetExecutingAssembly());
        services.AddMediatR(cfg =>
        {
            cfg.RegisterServicesFromAssembly(Assembly.GetExecutingAssembly());
            cfg.AddBehavior(typeof(IPipelineBehavior<,>), typeof(ValidationBehaviour<,>));
        });

        services.AddJwt(configuration);

        services.Configure<StripeSettings>(configuration.GetSection("Stripe"));
        services.Configure<AppSettings>(configuration.GetSection(nameof(AppSettings)));
        services.AddTransient<ITokenService, Identity.Tokens.Services.TokenService>();
        services.AddTransient<IIdentityService, IdentityService>();
        services.AddTransient<IOtpService, OtpService>();
        services.AddTransient<IGoogleAuthService, GoogleAuthService>();
        services.AddSingleton<SessionService>();
        services.AddSingleton<PaymentIntentService>();
        services.AddSingleton<RefundService>();
        services.AddSingleton<ChargeService>();
        services.AddSingleton<BalanceTransactionService>();

        return services;
    }
}