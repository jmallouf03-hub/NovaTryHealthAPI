﻿using NovaHealth.Application.Common.Interfaces;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.SignalR;
using NovaHealth.Application.SignalR.Queries;
using NovaHealth.Application.SignalR.Interface;

namespace NovaHealth.Application.Notifications.Queries.GetNotificationCountByUserId;
public class GetNotificationCountByUserIdRequest : IRequest<GetNotificationCountByUserIdResponse>
{
    public long UserId { get; set; }
}

public class GetNotificationCountByUserIdRequestHandler : IRequestHandler<GetNotificationCountByUserIdRequest, GetNotificationCountByUserIdResponse>
{
    private readonly INovaHealthDbContext _novaHealthDbContext;
    private readonly IHubContext<NotificationHub> _hubContext;
    private readonly IUserConnectionManager _userConnectionManager;

    public GetNotificationCountByUserIdRequestHandler(INovaHealthDbContext novaHealthDbContext, IHubContext<NotificationHub> hubContext, IUserConnectionManager userConnectionManager)
    {
        _novaHealthDbContext = novaHealthDbContext;
        _hubContext = hubContext;
        _userConnectionManager = userConnectionManager;

    }

    public async Task<GetNotificationCountByUserIdResponse> Handle(GetNotificationCountByUserIdRequest request, CancellationToken cancellationToken)
    {
        var count = await _novaHealthDbContext.UserNotificationReferences
                    .Where(nr => nr.UserId == request.UserId && !nr.IsDeleted && nr.IsActive && !nr.IsRead && !nr.Notification.IsDeleted)
                    .CountAsync(cancellationToken);

        await _hubContext.Clients.User(request.UserId.ToString())
                    .SendAsync("ReceiveNotificationCountUpdate", new { NotificationCount = count }, cancellationToken);
 

        return new GetNotificationCountByUserIdResponse { Count = count };
    }
}