﻿namespace NovaHealth.Application.Notifications.Queries.GetNotificationCountByUserId;

public class GetNotificationCountByUserIdResponse
{
    public int Count { get; set; }
}
