﻿using MediatR;
using Microsoft.EntityFrameworkCore;
using NovaHealth.Application.Common.Interfaces;
using System.Text.Json.Serialization;
namespace NovaHealth.Application.Notifications.Queries.GetArchiveListByUserId;

public class GetArchiveListByUserIdRequest : IRequest<List<GetArchiveListByUserIdResponse>>
{
    [JsonIgnore] public long UserId { get; set; }
}

public class GetArchiveListByUserIdRequestHandler : IRequestHandler<GetArchiveListByUserIdRequest, List<GetArchiveListByUserIdResponse>>
{
    private readonly INovaHealthDbContext _novaHealthDbContext;

    public GetArchiveListByUserIdRequestHandler(INovaHealthDbContext novaHealthDbContext)
    {
        _novaHealthDbContext = novaHealthDbContext;
    }

    public async Task<List<GetArchiveListByUserIdResponse>> Handle(GetArchiveListByUserIdRequest request, CancellationToken cancellationToken)
    {
        var notifications = await _novaHealthDbContext.UserNotificationReferences
                           .Where(unr => unr.UserId == request.UserId && unr.IsDeleted)
                           .Select(unr => new GetArchiveListByUserIdResponse
                           {
                               NotificationId = unr.Notification.Id,
                               Title = unr.Notification.Title,
                               Message = unr.Notification.Message,
                               NotificationType = unr.Notification.NotificationType.ToString(),
                               NotificationTypeId = unr.NotificationTypeId,
                               UserId = unr.UserId,
                               IsRead = unr.IsRead,
                               UserNotificationReferencesId = unr.Id,
                               CreatedDate = unr.Notification.CreatedDate

                           })
                           .ToListAsync(cancellationToken);
        return notifications;
    }
}