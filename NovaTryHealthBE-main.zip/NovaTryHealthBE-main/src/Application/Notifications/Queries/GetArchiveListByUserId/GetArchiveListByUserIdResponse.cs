﻿namespace NovaHealth.Application.Notifications.Queries.GetArchiveListByUserId;

public class GetArchiveListByUserIdResponse
{
    public string? NotificationType { get; set; }
    public string? Title { get; set; }
    public string? Message { get; set; }
    public bool IsRead { get; set; } = false;
    public long UserId { get; set; }
    public long NotificationId { get; set; }
    public DateTime CreatedDate { get; set; }
    public long NotificationTypeId { get; set; }

    public long UserNotificationReferencesId { get; set; }

}