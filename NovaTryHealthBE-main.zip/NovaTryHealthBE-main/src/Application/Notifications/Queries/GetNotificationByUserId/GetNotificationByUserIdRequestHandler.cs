﻿using AutoMapper;
using MediatR;
using Microsoft.EntityFrameworkCore;
using NovaHealth.Application.Common.Interfaces;
using System.Text.Json.Serialization;

namespace NovaHealth.Application.Notifications.Queries.GetNotificationByUserId;
public class GetNotificationByUserIdRequest : IRequest<List<GetNotificationByUserIdResponse>>
{
    [JsonIgnore] public long UserId { get; set; }
}

public class GetNotificationByUserIdRequestHandler : IRequestHandler<GetNotificationByUserIdRequest, List<GetNotificationByUserIdResponse>>
{
    private readonly INovaHealthDbContext _novaHealthDbContext;

    public GetNotificationByUserIdRequestHandler(INovaHealthDbContext novaHealthDbContext)
    {
        _novaHealthDbContext = novaHealthDbContext;
    }

    public async Task<List<GetNotificationByUserIdResponse>> Handle(GetNotificationByUserIdRequest request, CancellationToken cancellationToken)
    {
        var notifications = await _novaHealthDbContext.UserNotificationReferences
                         .Where(unr => unr.UserId == request.UserId && !unr.IsDeleted &&
                          unr.CreatedDate >= DateTime.UtcNow.AddDays(-7))
               .Select(unr => new GetNotificationByUserIdResponse
               {
                   NotificationId = unr.Notification.Id,
                   Title = unr.Notification.Title,
                   Message = unr.Notification.Message,
                   NotificationType = unr.Notification.NotificationType.ToString(),
                   NotificationTypeId = unr.NotificationTypeId,
                   UserId = unr.UserId,
                   IsRead = unr.IsRead,
                   UserNotificationReferencesId = unr.Id,
                   CreatedDate = unr.Notification.CreatedDate

               })
               .ToListAsync(cancellationToken);
        return notifications;
    }
}
