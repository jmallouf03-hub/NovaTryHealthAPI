﻿using MediatR;
using Microsoft.AspNetCore.SignalR;
using NovaHealth.Application.Common.Interfaces;
using NovaHealth.Application.SignalR.Interface;
using NovaHealth.Application.SignalR.Queries;

namespace NovaHealth.Application.Notifications.Commands.AllReadNotification;

public class AllReadNotificationRequestRequest : IRequest<bool>
{
    public long UserId { get; set; }

}

public class AllReadNotificationRequestHandler : IRequestHandler<AllReadNotificationRequestRequest, bool>
{
    private readonly INovaHealthDbContext _novaHealthDbContext;
    private readonly IUserConnectionManager _userConnectionManager;
    private readonly IHubContext<NotificationHub> _hubContext;

    public AllReadNotificationRequestHandler(INovaHealthDbContext novaHealthDbContext, IHubContext<NotificationHub> hubContext, IUserConnectionManager userConnectionManager)
    {
        _novaHealthDbContext = novaHealthDbContext;
        _hubContext = hubContext;
        _userConnectionManager = userConnectionManager;
    }

    public async Task<bool> Handle(AllReadNotificationRequestRequest request, CancellationToken cancellationToken)
    {

        var userNotifications = _novaHealthDbContext.UserNotificationReferences
                              .Where(x => x.UserId == request.UserId && !x.IsDeleted && x.IsActive && !x.IsRead)
                              .ToList();

        if (!userNotifications.Any())
        {
            return true;
        }
        foreach (var notification in userNotifications)
        {
            notification.IsRead = true;
        }
        await _novaHealthDbContext.SaveChangesAsync(cancellationToken);


        var connectionIds = _userConnectionManager.GetUserConnections(request.UserId.ToString());

        foreach (var connectionId in connectionIds)
        {
            await _hubContext.Clients.Client(connectionId).SendAsync("ReceiveNotificationCountUpdate", new
            {
                NotificationCount = 0
            });
        }
        return true;
    }
}