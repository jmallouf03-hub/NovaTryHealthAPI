﻿using MediatR;
using Microsoft.EntityFrameworkCore;
using NovaHealth.Application.Common.Interfaces;

namespace NovaHealth.Application.Notifications.Commands.ArchiveNotification;
public class ArchieveNotificationRequest : IRequest<bool>
{
    public long UserNotificationReferencesId { get; set; }
}
public class ArchiveNotificationRequestHandler : IRequestHandler<ArchieveNotificationRequest, bool>
{
    private readonly INovaHealthDbContext _novaHealthDbContext;

    public ArchiveNotificationRequestHandler(INovaHealthDbContext novaHealthDbContext)
    {
        _novaHealthDbContext = novaHealthDbContext;
    }

    public async Task<bool> Handle(ArchieveNotificationRequest request, CancellationToken cancellationToken)
    {
        var notification = await _novaHealthDbContext.UserNotificationReferences
                            .FirstOrDefaultAsync(x => x.Id == request.UserNotificationReferencesId && !x.IsDeleted, cancellationToken);

        if (notification == null)
        {
            throw new NotImplementedException($"Cannot find notification reference with id :{request.UserNotificationReferencesId}");
        }

        notification.IsDeleted = true;
        await _novaHealthDbContext.SaveChangesAsync(cancellationToken);

        return true;
    }
}
