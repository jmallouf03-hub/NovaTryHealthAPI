﻿using MediatR;
using Microsoft.EntityFrameworkCore;
using NovaHealth.Application.Common.Interfaces;

namespace NovaHealth.Application.Notifications.Commands.AllArchiveNotification;

public class AllArchiveNotificationRequest : IRequest<bool>
{
    public long UserId { get; set; }
}
public class AllArchiveNotificationRequestHandler : IRequestHandler<AllArchiveNotificationRequest, bool>
{
    private readonly INovaHealthDbContext _novaHealthDbContext;

    public AllArchiveNotificationRequestHandler(INovaHealthDbContext novaHealthDbContext)
    {
        _novaHealthDbContext = novaHealthDbContext;
    }

    public async Task<bool> Handle(AllArchiveNotificationRequest request, CancellationToken cancellationToken)
    {
        var userNotifications = await _novaHealthDbContext.UserNotificationReferences
                              .Where(x => x.UserId == request.UserId && !x.IsDeleted)
                              .ToListAsync(cancellationToken);

        if (!userNotifications.Any())
        {

            return true;
        }

        foreach (var notification in userNotifications)
        {
            notification.IsDeleted = true;
        }

        await _novaHealthDbContext.SaveChangesAsync(cancellationToken);

        return true;
    }
}

