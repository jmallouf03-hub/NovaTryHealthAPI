﻿using MediatR;
using Microsoft.AspNetCore.SignalR;
using Microsoft.EntityFrameworkCore;
using NovaHealth.Application.Common.Interfaces;
using NovaHealth.Application.SignalR.Interface;
using NovaHealth.Application.SignalR.Queries;

namespace NovaHealth.Application.Notifications.Commands.ReadNotification;
public class ReadNotificationRequestHandler : IRequestHandler<ReadNotificationRequest, bool>
{
    private readonly INovaHealthDbContext _novaHealthDbContext;
    private readonly IUserConnectionManager _userConnectionManager;
    private readonly IHubContext<NotificationHub> _hubContext;

    public ReadNotificationRequestHandler(INovaHealthDbContext novaHealthDbContext, IHubContext<NotificationHub> hubContext, IUserConnectionManager userConnectionManager)
    {
        _novaHealthDbContext = novaHealthDbContext;
        _hubContext = hubContext;
        _userConnectionManager = userConnectionManager;
    }

    public async Task<bool> Handle(ReadNotificationRequest request, CancellationToken cancellationToken)
    {
        var reference = await _novaHealthDbContext.UserNotificationReferences
                        .Include(x => x.Notification).Where(x => x.UserId == request.UserId &&
                          x.NotificationTypeId == request.NotificationTypeId && !x.IsDeleted && x.IsActive && !x.IsRead)
                        .FirstOrDefaultAsync(cancellationToken);



        if (reference != null)
        {
            reference.IsRead = true;

            await _novaHealthDbContext.SaveChangesAsync(cancellationToken);
        }

        var updatedUnreadCount = await _novaHealthDbContext.UserNotificationReferences
                                 .Include(x => x.Notification)
                                 .Where(x => x.UserId == request.UserId && !x.IsDeleted && x.IsActive && !x.IsRead && !x.Notification.IsDeleted)
                                 .CountAsync(cancellationToken);


        var connectionIds = _userConnectionManager.GetUserConnections(request.UserId.ToString());

        foreach (var connectionId in connectionIds)
        {
            await _hubContext.Clients.Client(connectionId).SendAsync("ReceiveNotificationCountUpdate", new
            {
                NotificationCount = updatedUnreadCount
            });
        }

        return true;
    }
}