﻿using MediatR;

namespace NovaHealth.Application.Notifications.Commands.ReadNotification;
public class ReadNotificationRequest : IRequest<bool>
{
    public long UserId { get; set; }

    public long NotificationTypeId { get; set; }
}