﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace NovaHealth.Application.Auth.Jwt;

internal static class Startup
{
    internal static IServiceCollection AddJwt(this IServiceCollection services, IConfiguration config) =>
        services.Configure<JwtSettings>(config.GetSection(nameof(JwtSettings)));
}