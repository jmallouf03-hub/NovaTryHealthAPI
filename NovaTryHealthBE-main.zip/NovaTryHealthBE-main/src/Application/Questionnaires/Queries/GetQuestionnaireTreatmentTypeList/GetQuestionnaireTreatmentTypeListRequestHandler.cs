﻿using AutoMapper.QueryableExtensions;
using MediatR;
using Microsoft.EntityFrameworkCore;
using NovaHealth.Application.Common.Interfaces;
using NovaHealth.Application.Common.Models;
using NovaHealth.Application.Common.Mappings;
using System.Linq.Dynamic.Core;
using AutoMapper;

namespace NovaHealth.Application.Questionnaires.Queries.GetQuestionnaireTreatmentTypeList;

public class GetQuestionnaireTreatmentTypeListRequest : PaginationFilter, IRequest<PaginationResponse<GetQuestionnaireTreatmentTypeListResponse>> { }

public class GetQuestionnaireTreatmentTypeListRequestHandler : IRequestHandler<GetQuestionnaireTreatmentTypeListRequest, PaginationResponse<GetQuestionnaireTreatmentTypeListResponse>>
{
    private readonly INovaHealthDbContext _novaHealthDbContext;
    private readonly IMapper _mapper;

    public GetQuestionnaireTreatmentTypeListRequestHandler(INovaHealthDbContext novaHealthDbContext, IMapper mapper)
    {
        _novaHealthDbContext = novaHealthDbContext;
        _mapper = mapper;
    }
    public async Task<PaginationResponse<GetQuestionnaireTreatmentTypeListResponse>> Handle(GetQuestionnaireTreatmentTypeListRequest request, CancellationToken cancellationToken)
    {
        var query = _novaHealthDbContext.QuestionnaireTreatmentTypes
                   .AsNoTracking()
                   .Select(x => new GetQuestionnaireTreatmentTypeListResponse
                   {
                       Id = x.Id,
                       TreatmentTypeName = x.TreatmentType,
                   });

        // Apply filter if provided
        if (!string.IsNullOrEmpty(request.Filter))
        {
            query = query.Where(request.Filter);
        }

        // Apply order
        if (!string.IsNullOrEmpty(request.OrderBy))
        {
            query = query.OrderBy(request.OrderBy);
        }
        else
        {
            query = query.OrderBy(x => x.Id);
        }


        return await query.ProjectTo<GetQuestionnaireTreatmentTypeListResponse>(_mapper.ConfigurationProvider)
                 .PaginatedListAsync(request.PageNumber, request.PageSize);
    }
}