﻿using AutoMapper;

namespace NovaHealth.Application.Questionnaires.Queries.GetQuestionnaireTreatmentTypeList;

public class GetQuestionnaireTreatmentTypeListResponse
{
    public long Id { get; set; }

    public string TreatmentTypeName { get; set; } = null!;
    public class Mapping : Profile
    {
        public Mapping()
        {
            CreateMap<GetQuestionnaireTreatmentTypeListResponse, GetQuestionnaireTreatmentTypeListResponse>();
        }
    }
}