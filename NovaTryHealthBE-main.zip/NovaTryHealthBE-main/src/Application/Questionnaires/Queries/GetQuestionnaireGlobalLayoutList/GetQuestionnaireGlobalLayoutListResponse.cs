﻿using AutoMapper;

namespace NovaHealth.Application.Questionnaires.Queries.GetQuestionnaireGlobalLayoutList;

public class GetQuestionnaireGlobalLayoutListResponse
{
    public long Id { get; set; }

    public string GlobalLayoutName { get; set; } = null!;

    public class Mapping : Profile
    {
        public Mapping()
        {
            CreateMap<GetQuestionnaireGlobalLayoutListResponse, GetQuestionnaireGlobalLayoutListResponse>();
        }

    }
}
