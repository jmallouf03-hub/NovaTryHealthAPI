﻿using AutoMapper;
using AutoMapper.QueryableExtensions;
using MediatR;
using Microsoft.EntityFrameworkCore;
using NovaHealth.Application.Common.Interfaces;
using NovaHealth.Application.Common.Mappings;
using NovaHealth.Application.Common.Models;
using System.Linq.Dynamic.Core;

namespace NovaHealth.Application.Questionnaires.Queries.GetQuestionnaireGlobalLayoutList;

public class GetQuestionnaireGlobalLayoutListRequest : PaginationFilter, IRequest<PaginationResponse<GetQuestionnaireGlobalLayoutListResponse>> { }

public class GetQuestionnaireGlobalLayoutListRequestHandler : IRequestHandler<GetQuestionnaireGlobalLayoutListRequest, PaginationResponse<GetQuestionnaireGlobalLayoutListResponse>>
{
    private readonly INovaHealthDbContext _novaHealthDbContext;
    private readonly IMapper _mapper;

    public GetQuestionnaireGlobalLayoutListRequestHandler(INovaHealthDbContext novaHealthDbContext, IMapper mapper)
    {
        _novaHealthDbContext = novaHealthDbContext;
        _mapper = mapper;
    }
    public async Task<PaginationResponse<GetQuestionnaireGlobalLayoutListResponse>> Handle(GetQuestionnaireGlobalLayoutListRequest request, CancellationToken cancellationToken)
    {

        var query = _novaHealthDbContext.QuestionnaireGlobalLayouts
                    .AsNoTracking()
                    .Select(x => new GetQuestionnaireGlobalLayoutListResponse
                    {
                        Id = x.Id,
                        GlobalLayoutName = x.GlobalLayout,
                    });
        if (!string.IsNullOrEmpty(request.Filter))
        {
            query = query.Where(request.Filter);
        }

        // Apply order
        if (!string.IsNullOrEmpty(request.OrderBy))
        {
            query = query.OrderBy(request.OrderBy);
        }
        else
        {
            query = query.OrderBy(x => x.Id);
        }

        return await query.ProjectTo<GetQuestionnaireGlobalLayoutListResponse>(_mapper.ConfigurationProvider)
           .PaginatedListAsync(request.PageNumber, request.PageSize);
    }
}