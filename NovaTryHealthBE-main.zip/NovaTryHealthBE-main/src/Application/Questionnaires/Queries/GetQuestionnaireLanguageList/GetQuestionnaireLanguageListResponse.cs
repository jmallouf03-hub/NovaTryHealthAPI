﻿using AutoMapper;

namespace NovaHealth.Application.Questionnaires.Queries.GetQuestionnaireLanguageList;

public class GetQuestionnaireLanguageListResponse
{
    public long Id { get; set; }

    public string LanguageName { get; set; } = null!;

    public class Mapping : Profile
    {
        public Mapping()
        {
            CreateMap<GetQuestionnaireLanguageListResponse, GetQuestionnaireLanguageListResponse>();
        }

    }
}