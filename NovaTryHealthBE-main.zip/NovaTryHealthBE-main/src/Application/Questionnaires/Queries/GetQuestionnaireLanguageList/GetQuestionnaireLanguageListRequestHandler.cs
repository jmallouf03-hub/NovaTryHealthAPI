﻿using AutoMapper;
using AutoMapper.QueryableExtensions;
using MediatR;
using Microsoft.EntityFrameworkCore;
using NovaHealth.Application.Common.Interfaces;
using NovaHealth.Application.Common.Mappings;
using NovaHealth.Application.Common.Models;
using System.Linq.Dynamic.Core;

namespace NovaHealth.Application.Questionnaires.Queries.GetQuestionnaireLanguageList;

public class GetQuestionnaireLanguageListRequest : PaginationFilter, IRequest<PaginationResponse<GetQuestionnaireLanguageListResponse>> { }

public class GetQuestionnaireLanguageListRequestHandler : IRequestHandler<GetQuestionnaireLanguageListRequest, PaginationResponse<GetQuestionnaireLanguageListResponse>>
{
    private readonly INovaHealthDbContext _novaHealthDbContext;
    private readonly IMapper _mapper;

    public GetQuestionnaireLanguageListRequestHandler(INovaHealthDbContext novaHealthDbContext, IMapper mapper)
    {
        _novaHealthDbContext = novaHealthDbContext;
        _mapper = mapper;
    }
    public async Task<PaginationResponse<GetQuestionnaireLanguageListResponse>> Handle(GetQuestionnaireLanguageListRequest request, CancellationToken cancellationToken)
    {
        var query = _novaHealthDbContext.QuestionnaireDefaultLanguages
                     .AsNoTracking()
                     .Select(x => new GetQuestionnaireLanguageListResponse
                     {
                         Id = x.Id,
                         LanguageName = x.DefaultLanguage,
                     });

        // Apply filter if provided
        if (!string.IsNullOrEmpty(request.Filter))
        {
            query = query.Where(request.Filter);
        }

        // Apply order
        if (!string.IsNullOrEmpty(request.OrderBy))
        {
            query = query.OrderBy(request.OrderBy);
        }
        else
        {
            query = query.OrderBy(x => x.Id);
        }

        return await query.ProjectTo<GetQuestionnaireLanguageListResponse>(_mapper.ConfigurationProvider)
                 .PaginatedListAsync(request.PageNumber, request.PageSize);
    }
}
