﻿using AutoMapper;
using AutoMapper.QueryableExtensions;
using MediatR;
using Microsoft.EntityFrameworkCore;
using NovaHealth.Application.Common.Interfaces;
using NovaHealth.Application.Common.Mappings;
using NovaHealth.Application.Common.Models;
using System.Linq.Dynamic.Core;


namespace NovaHealth.Application.Questionnaires.Queries.GetQuestionnaireWebDomainList;

public class GetQuestionnaireWebDomainListRequest : PaginationFilter, IRequest<PaginationResponse<GetQuestionnaireWebDomainListResponse>> { }

public class GetQuestionnaireWebDomainListRequestHandler : IRequestHandler<GetQuestionnaireWebDomainListRequest, PaginationResponse<GetQuestionnaireWebDomainListResponse>>
{
    private readonly INovaHealthDbContext _novaHealthDbContext;
    private readonly IMapper _mapper;

    public GetQuestionnaireWebDomainListRequestHandler(INovaHealthDbContext novaHealthDbContext, IMapper mapper)
    {
        _novaHealthDbContext = novaHealthDbContext;
        _mapper = mapper;
    }
    public async Task<PaginationResponse<GetQuestionnaireWebDomainListResponse>> Handle(GetQuestionnaireWebDomainListRequest request, CancellationToken cancellationToken)
    {
        var query = _novaHealthDbContext.WebDomains
                   .AsNoTracking()
                   .Select(x => new GetQuestionnaireWebDomainListResponse
                   {
                       Id = x.Id,
                       WebDomainUrl = x.Url,
                   });

        // Apply filter if provided
        if (!string.IsNullOrEmpty(request.Filter))
        {
            query = query.Where(request.Filter);
        }

        // Apply order
        if (!string.IsNullOrEmpty(request.OrderBy))
        {
            query = query.OrderBy(request.OrderBy);
        }
        else
        {
            query = query.OrderBy(x => x.Id);
        }

        return await query.ProjectTo<GetQuestionnaireWebDomainListResponse>(_mapper.ConfigurationProvider)
                 .PaginatedListAsync(request.PageNumber, request.PageSize);
    }
}