﻿using AutoMapper;

namespace NovaHealth.Application.Questionnaires.Queries.GetQuestionnaireWebDomainList;

public class GetQuestionnaireWebDomainListResponse
{
    public long Id { get; set; }

    public string WebDomainUrl { get; set; } = null!;

    public class Mapping : Profile
    {
        public Mapping()
        {
            CreateMap<GetQuestionnaireWebDomainListResponse, GetQuestionnaireWebDomainListResponse>();
        }
    }
}