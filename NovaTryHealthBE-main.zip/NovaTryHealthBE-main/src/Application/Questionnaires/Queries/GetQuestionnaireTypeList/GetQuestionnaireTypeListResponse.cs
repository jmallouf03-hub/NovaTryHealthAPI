﻿using AutoMapper;

namespace NovaHealth.Application.Questionnaires.Queries.GetQuestionnaireTypeList;

public class GetQuestionnaireTypeListResponse
{
    public long Id { get; set; }

    public string QuestionnaireTypes { get; set; } = null!;

    public class Mapping : Profile
    {
        public Mapping()
        {
            CreateMap<GetQuestionnaireTypeListResponse, GetQuestionnaireTypeListResponse>();
        }
    }
}