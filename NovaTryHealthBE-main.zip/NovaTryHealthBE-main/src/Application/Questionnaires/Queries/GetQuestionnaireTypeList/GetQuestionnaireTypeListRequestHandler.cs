﻿using MediatR;
using Microsoft.EntityFrameworkCore;
using NovaHealth.Application.Common.Interfaces;
using NovaHealth.Application.Common.Models;
using AutoMapper;
using System.Linq.Dynamic.Core;
using AutoMapper.QueryableExtensions;
using NovaHealth.Application.Common.Mappings;

namespace NovaHealth.Application.Questionnaires.Queries.GetQuestionnaireTypeList;

public class GetQuestionnaireTypeListRequest : PaginationFilter, IRequest<PaginationResponse<GetQuestionnaireTypeListResponse>> { }

public class GetQuestionnaireTypeListRequestHandler : IRequestHandler<GetQuestionnaireTypeListRequest, PaginationResponse<GetQuestionnaireTypeListResponse>>
{
    private readonly INovaHealthDbContext _novaHealthDbContext;
    private readonly IMapper _mapper;

    public GetQuestionnaireTypeListRequestHandler(INovaHealthDbContext novaHealthDbContext, IMapper mapper)
    {
        _novaHealthDbContext = novaHealthDbContext;
        _mapper = mapper;
    }

    public async Task<PaginationResponse<GetQuestionnaireTypeListResponse>> Handle(GetQuestionnaireTypeListRequest request, CancellationToken cancellationToken)
    {
        var query = _novaHealthDbContext.QuestionnaireTypes
            .Select(x => new GetQuestionnaireTypeListResponse
            {
                Id = x.Id,
                QuestionnaireTypes = x.Type
            });

        if (!string.IsNullOrEmpty(request.Filter))
        {
            query = query.Where(request.Filter);
        }

        if (!string.IsNullOrEmpty(request.OrderBy))
        {
            query = query.OrderBy(request.OrderBy);
        }
        else
        {
            query = query.OrderBy(x => x.Id);
        }

        return await query.ProjectTo<GetQuestionnaireTypeListResponse>(_mapper.ConfigurationProvider)
                 .PaginatedListAsync(request.PageNumber, request.PageSize);
    }
}
