﻿using MediatR;
using Microsoft.EntityFrameworkCore;
using NovaHealth.Application.Common.Exceptions;
using NovaHealth.Application.Common.Interfaces;
using System.Text.Json.Serialization;

namespace NovaHealth.Application.Questionnaires.Queries.GetQuestionnaireById;

public record GetQuestionnaireByIdRequest : IRequest<GetQuestionnaireByIdResponse>
{
    [JsonIgnore] public long QuestionnaireId { get; set; }
}

public class GetQuestionnaireByIdRequestHandler : IRequestHandler<GetQuestionnaireByIdRequest, GetQuestionnaireByIdResponse>
{
    private readonly INovaHealthDbContext _novaHealthDbContext;

    public GetQuestionnaireByIdRequestHandler(INovaHealthDbContext novaHealthDbContext)
    {
        _novaHealthDbContext = novaHealthDbContext;
    }

    public async Task<GetQuestionnaireByIdResponse> Handle(GetQuestionnaireByIdRequest request, CancellationToken cancellationToken)
    {
        var response = await _novaHealthDbContext.Questionnaires
            .AsNoTracking()
            .Where(q => q.Id == request.QuestionnaireId && !q.IsDeleted)
            .Select(q => new GetQuestionnaireByIdResponse
            {
                Id = q.Id,
                Title = q.Title,
                Slug = q.Slug,
                DomainId = q.WebDomainId,
                Domain = q.WebDomain.Url,
                IsPublished = q.IsPublished,
                Status = q.Status,
                Mode = q.Mode,
                BelugaEnabledRX = q.BelugaEnabledRX,
                //  EnableTranslation = q.EnableTranslation,

                QuestionnaireTreatmentTypeId = q.QuestionnaireTreatmentTypeId,
                QuestionnaireTreatmentType = q.QuestionnaireTreatmentType != null ? q.QuestionnaireTreatmentType.TreatmentType : null,

                QuestionnaireTypeId = q.QuestionnaireTypeId,
                QuestionnaireType = q.QuestionnaireType != null ? q.QuestionnaireType.Type : null,

                //  QuestionnaireDefaultLanguageId = q.QuestionnaireDefaultLanguageId,
                //  QuestionnaireDefaultLanguage = q.QuestionnaireDefaultLanguage != null ? q.QuestionnaireDefaultLanguage.DefaultLanguage : null,

                QuestionnaireGlobalLayoutId = q.QuestionnaireGlobalLayoutId,
                QuestionnaireGlobalLayout = q.QuestionnaireGlobalLayout != null ? q.QuestionnaireGlobalLayout.GlobalLayout : null,

                CreatedDate = q.CreatedDate,
                Products = q.QuestionnaireProducts.Where(qp => !qp.IsDeleted).Select(qp => new TotalProductsDto
                {
                    Id = qp.Product.Id,
                    Name = qp.Product.DrugName,
                    Slug = qp.Product.ShortName,
                    Domain = qp.Product.LabelerName,
                    CreatedDate = qp.Product.CreatedDate
                }).ToList()
            })
            .FirstOrDefaultAsync(cancellationToken);

        if (response == null)
            throw new NotFoundException($"Questionnaire with Id {request.QuestionnaireId} not found.");

        return response;
    }
}


