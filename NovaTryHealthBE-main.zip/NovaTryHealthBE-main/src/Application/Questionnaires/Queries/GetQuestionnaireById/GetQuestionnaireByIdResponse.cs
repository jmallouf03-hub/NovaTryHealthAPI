﻿namespace NovaHealth.Application.Questionnaires.Queries.GetQuestionnaireById;

public class GetQuestionnaireByIdResponse
{
    public long? Id { get; set; }
    public string Title { get; set; } = null!;
    public string Slug { get; set; } = null!;
    public bool IsPublished { get; set; }
    public string? Status { get; set; }
    public bool Mode { get; set; }

    public long DomainId { get; set; }

    public string? Domain { get; set; } 
    public long QuestionnaireTreatmentTypeId { get; set; }
    public string? QuestionnaireTreatmentType { get; set; }
    public long QuestionnaireTypeId { get; set; }
    public string? QuestionnaireType { get; set; }
   // public long QuestionnaireDefaultLanguageId { get; set; }
  //  public string? QuestionnaireDefaultLanguage { get; set; }
    public long QuestionnaireGlobalLayoutId { get; set; }
    public string? QuestionnaireGlobalLayout { get; set; }
    public DateTime CreatedDate { get; set; }

     public bool BelugaEnabledRX { get; set; }

  //  public bool EnableTranslation { get; set; }

  
    public List<TotalProductsDto>  Products { get; set; } = new List<TotalProductsDto>();

}
public class TotalProductsDto
{
    public long Id { get; set; }
    public string Name { get; set; } = null!;
    public string? Slug { get; set; }
    public string? Domain { get; set; }
    public bool IsPublished { get; set; }
    public string? Status { get; set; }
    public bool Mode { get; set; }
    public DateTime CreatedDate { get; set; }
}
