﻿using AutoMapper;

namespace NovaHealth.Application.Questionnaires.Queries.GetQuestionnaireList;

public class GetQuestionnaireListResponse
{
    public long? Id { get; set; }
    public string Title { get; set; } = null!;
    public string Slug { get; set; } = null!;
    public string? Domain { get; set; }
    public bool IsPublished { get; set; }
    public string? Status { get; set; }
    public bool Mode { get; set; }
    public long QuestionnaireTreatmentTypeId { get; set; }
    public string? QuestionnaireTreatmentType { get; set; }
    public long QuestionnaireTypeId { get; set; }
    public string? QuestionnaireType { get; set; }
    public long QuestionnaireDefaultLanguageId { get; set; }
    public string? QuestionnaireDefaultLanguage { get; set; }
    public long QuestionnaireGlobalLayoutId { get; set; }
    public string? QuestionnaireGlobalLayout { get; set; }
    public DateTime CreatedDate { get; set; }
    public int TotalProducts { get; set; }
    public int Questions { get; set; }

    public long? ProductId { get; set; }

    public class Mapping : Profile
    {
        public Mapping()
        {
            CreateMap<GetQuestionnaireListResponse, GetQuestionnaireListResponse>();
        }
    }
}
