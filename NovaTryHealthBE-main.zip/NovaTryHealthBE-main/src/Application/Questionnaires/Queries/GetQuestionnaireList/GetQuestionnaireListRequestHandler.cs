﻿using AutoMapper;
using AutoMapper.QueryableExtensions;
using MediatR;
using Microsoft.EntityFrameworkCore;
using NovaHealth.Application.Common.Exceptions;
using NovaHealth.Application.Common.Interfaces;
using NovaHealth.Application.Common.Mappings;
using NovaHealth.Application.Common.Models;
using System.Linq.Dynamic.Core;

namespace NovaHealth.Application.Questionnaires.Queries.GetQuestionnaireList;
public class GetQuestionnaireListRequest : PaginationFilter, IRequest<PaginationResponse<GetQuestionnaireListResponse>> { }

public class GetQuestionnaireListRequestHandler : IRequestHandler<GetQuestionnaireListRequest, PaginationResponse<GetQuestionnaireListResponse>>
{
    private readonly INovaHealthDbContext _novaHealthDbContext;
    private readonly IMapper _mapper;

    public GetQuestionnaireListRequestHandler(INovaHealthDbContext novaHealthDbContext, IMapper mapper)
    {
        _novaHealthDbContext = novaHealthDbContext;
        _mapper = mapper;
    }

    public async Task<PaginationResponse<GetQuestionnaireListResponse>> Handle(GetQuestionnaireListRequest request, CancellationToken cancellationToken)
    {
        var questionnaires = _novaHealthDbContext.Questionnaires.Include(x=>x.QuestionnaireProducts)
                            .AsNoTracking()
                            .Where(q => !q.IsDeleted)
                            .Select(q => new GetQuestionnaireListResponse
                            {
                                Id = q.Id,
                                Title = q.Title,
                                Slug = q.Slug,
                                Domain = q.WebDomain.Url,
                                IsPublished = q.IsPublished,
                                Status = q.Status,
                                Mode = q.Mode,

                                QuestionnaireTreatmentTypeId = q.QuestionnaireTreatmentTypeId,
                                QuestionnaireTreatmentType = q.QuestionnaireTreatmentType != null ? q.QuestionnaireTreatmentType.TreatmentType : null,

                                QuestionnaireTypeId = q.QuestionnaireTypeId,
                                QuestionnaireType = q.QuestionnaireType != null ? q.QuestionnaireType.Type : null,

                                //  QuestionnaireDefaultLanguageId = q.QuestionnaireDefaultLanguageId,
                                //  QuestionnaireDefaultLanguage = q.QuestionnaireDefaultLanguage != null ? q.QuestionnaireDefaultLanguage.DefaultLanguage : null,

                                QuestionnaireGlobalLayoutId = q.QuestionnaireGlobalLayoutId,
                                QuestionnaireGlobalLayout = q.QuestionnaireGlobalLayout != null ? q.QuestionnaireGlobalLayout.GlobalLayout : null,

                                CreatedDate = q.CreatedDate,
                                TotalProducts = q.QuestionnaireProducts.Count(p => !p.IsDeleted),
                                ProductId=q.QuestionnaireProducts.Select(x=>x.ProductId).FirstOrDefault(),
                                Questions = q.Questions.Count
                            });

        if (!questionnaires.Any())
            throw new NotFoundException("Questionnaire  not found.");

        if (!string.IsNullOrEmpty(request.Filter))
        {
            questionnaires = questionnaires.Where(request.Filter);
        }

        if (!string.IsNullOrEmpty(request.OrderBy))
        {
            questionnaires = questionnaires.OrderBy(request.OrderBy);
        }
        else
        {
            questionnaires = questionnaires.OrderByDescending(x => x.Id);
        }

        return await questionnaires.ProjectTo<GetQuestionnaireListResponse>(_mapper.ConfigurationProvider)
                    .PaginatedListAsync(request.PageNumber, request.PageSize);
    }
}


