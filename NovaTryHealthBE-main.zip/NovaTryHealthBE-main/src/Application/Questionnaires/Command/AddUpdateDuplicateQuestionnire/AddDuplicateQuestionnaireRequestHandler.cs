﻿using MediatR;
using Microsoft.EntityFrameworkCore;
using NovaHealth.Application.Common.Interfaces;
using NovaHealth.Domain.Entities;
using System.Text.Json.Serialization;

namespace NovaHealth.Application.Questionnaires.Command.AddUpdateDuplicateQuestionnire;

public class AddDuplicateQuestionnaireRequest : IRequest<bool>
{
    [JsonIgnore] public long Id { get; set; }

}
public class AddDuplicateQuestionnaireRequestHandler : IRequestHandler<AddDuplicateQuestionnaireRequest, bool>
{
    private readonly INovaHealthDbContext _novaHealthDbContext;

    public AddDuplicateQuestionnaireRequestHandler(INovaHealthDbContext novaHealthDbContext)
    {
        _novaHealthDbContext = novaHealthDbContext;
    }

    public async Task<bool> Handle(AddDuplicateQuestionnaireRequest request, CancellationToken cancellationToken)
    {
        // 🔍 Load the source questionnaire with products, questions, and answers
        var source = await _novaHealthDbContext.Questionnaires
                    .Include(q => q.QuestionnaireProducts)
                    .Include(q => q.Questions)
                        .ThenInclude(ques => ques.Answers)
                    .FirstOrDefaultAsync(q => q.Id == request.Id, cancellationToken);

        if (source == null)
            throw new Exception($"Questionnaire with ID  not found.");

        // 🆕 Create the duplicate questionnaire
        var duplicate = new Questionnaire
        {
            Title = $"{source.Title} (copy)",
            Slug = source.Slug + "-copy",
            WebDomainId = source.WebDomainId,
            IsPublished = source.IsPublished,
            Status = source.Status,
            Mode = source.Mode,
            QuestionnaireTreatmentTypeId = source.QuestionnaireTreatmentTypeId,
            QuestionnaireTypeId = source.QuestionnaireTypeId,
            QuestionnaireGlobalLayoutId = source.QuestionnaireGlobalLayoutId,
            BelugaEnabledRX = source.BelugaEnabledRX,
            IsActive = true,
            IsDeleted = false,
            CreatedDate = DateTime.UtcNow,
            QuestionnaireProducts = new List<QuestionnaireProduct>(),
            Questions = new List<Domain.Entities.Question>()
        };

        // 📦 Copy products
        foreach (var prod in source.QuestionnaireProducts.Where(p => !p.IsDeleted))
        {
            duplicate.QuestionnaireProducts.Add(new QuestionnaireProduct
            {
                ProductId = prod.ProductId,
                IsActive = true,
                IsDeleted = false,
                CreatedDate = DateTime.UtcNow
            });
        }

        // ❓ Copy questions and their answers
        foreach (var ques in source.Questions.Where(q => !q.IsDeleted))
        {
            var newQuestion = new Domain.Entities.Question
            {
                Title = ques.Title,
                Name = ques.Title,
                QuestionnaireId = duplicate.Id,
                QuestionTypeId = ques.QuestionTypeId,
                QuestionSpecialVisitId = ques.QuestionSpecialVisitId,
                IsDeleted = false,
                IsActive = true,
                CreatedDate = DateTime.UtcNow,
                Answers = new List<AnswerOption>()
            };

            if (ques.Answers != null && ques.Answers.Any(a => !a.IsDeleted))
            {
                foreach (var ans in ques.Answers.Where(a => !a.IsDeleted))
                {
                    newQuestion.Answers.Add(new AnswerOption
                    {
                        Text = ans.Text,
                        Priority = ans.Priority,
                        NextQuestionId = ans.NextQuestionId,
                        ProductId = ans.ProductId,
                        Flag = ans.Flag,
                        IsDeleted = false,
                        CreatedDate = DateTime.UtcNow
                    });
                }
            }
            duplicate.Questions.Add(newQuestion);
        }

        await _novaHealthDbContext.Questionnaires.AddAsync(duplicate, cancellationToken);
        await _novaHealthDbContext.SaveChangesAsync(cancellationToken);

        return true;
    }
}

