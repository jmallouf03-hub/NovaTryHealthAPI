﻿using MediatR;

namespace NovaHealth.Application.Questionnaires.Command.AddUpdateQuestionnaire;

public class AddUpdateQuestionnaireRequest : IRequest<bool>
{
    public long? Id { get; set; }
    public string Title { get; set; } = null!;
    public string Slug { get; set; } = null!;
    public bool IsPublished { get; set; }
    public string? Status { get; set; }
    public bool Mode { get; set; }    // e.g., Live, Test
    public bool BelugaEnabledRX { get; set; }

    //   public bool EnableTranslation { get; set; }
    public long DomainId { get; set; }

    public long QuestionnaireTreatmentTypeId { get; set; }

    public long QuestionnaireTypeId { get; set; }

    //   public long QuestionnaireDefaultLanguageId { get; set; }

    public long QuestionnaireGlobalLayoutId { get; set; }

    public List<long> Products { get; set; } = new();

}
