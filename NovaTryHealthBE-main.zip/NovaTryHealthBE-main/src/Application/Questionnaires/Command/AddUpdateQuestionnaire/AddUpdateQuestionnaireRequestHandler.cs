﻿//using MediatR;
//using Microsoft.EntityFrameworkCore;
//using NovaHealth.Application.Common.Interfaces;
//using NovaHealth.Domain.Entities;
//using System;
//using System.Linq;
//using System.Threading;
//using System.Threading.Tasks;

//namespace NovaHealth.Application.Questionnaires.Command.AddUpdateQuestionnaire;

//public class AddUpdateQuestionnaireRequestHandler : IRequestHandler<AddUpdateQuestionnaireRequest, bool>
//{
//    private readonly INovaHealthDbContext _novaHealthDbContext;

//    public AddUpdateQuestionnaireRequestHandler(INovaHealthDbContext novaHealthDbContext)
//    {
//        _novaHealthDbContext = novaHealthDbContext;
//    }

//    public async Task<bool> Handle(AddUpdateQuestionnaireRequest request, CancellationToken cancellationToken)
//    {
//        var questionnaire = await _novaHealthDbContext.Questionnaires
//            .Include(q => q.QuestionnaireProducts)
//            .FirstOrDefaultAsync(x => x.Id == request.Id && !x.IsDeleted, cancellationToken);

//        if (questionnaire != null)
//        {
//            // 🔄 Update existing
//            questionnaire.Title = request.Title;
//            questionnaire.Slug = request.Slug;
//            questionnaire.WebDomainId = request.DomainId;
//            questionnaire.IsPublished = request.IsPublished;
//            questionnaire.Status = request.Status;
//            questionnaire.Mode = request.Mode;
//            questionnaire.QuestionnaireTreatmentTypeId = request.QuestionnaireTreatmentTypeId;
//            questionnaire.QuestionnaireTypeId = request.QuestionnaireTypeId;
//            questionnaire.QuestionnaireDefaultLanguageId = request.QuestionnaireDefaultLanguageId;
//            questionnaire.QuestionnaireGlobalLayoutId = request.QuestionnaireGlobalLayoutId;
//            questionnaire.IsActive = true;
//            questionnaire.BelugaEnabledRX = request.BelugaEnabledRX;
//            questionnaire.EnableTranslation = request.EnableTranslation;
//            questionnaire.CreatedDate = DateTime.UtcNow;
//        }
//        else
//        {
//            // ➕ Insert new
//            questionnaire = new Questionnaire
//            {
//                Title = request.Title,
//                Slug = request.Slug,
//                WebDomainId = request.DomainId,
//                IsPublished = request.IsPublished,
//                Status = request.Status,
//                Mode = request.Mode,
//                QuestionnaireTreatmentTypeId = request.QuestionnaireTreatmentTypeId,
//                QuestionnaireTypeId = request.QuestionnaireTypeId,
//                QuestionnaireDefaultLanguageId = request.QuestionnaireDefaultLanguageId,
//                QuestionnaireGlobalLayoutId = request.QuestionnaireGlobalLayoutId,
//                IsActive = true,
//                IsDeleted = false,
//                BelugaEnabledRX = request.BelugaEnabledRX,
//                EnableTranslation = request.EnableTranslation,
//                CreatedDate = DateTime.UtcNow
//            };

//            await _novaHealthDbContext.Questionnaires.AddAsync(questionnaire, cancellationToken);
//        }


//        if (request.Products != null)
//        {
//            var validProductIds = await _novaHealthDbContext.Products
//                .Where(p => request.Products.Contains(p.Id))
//                .Select(p => p.Id)
//                .ToListAsync(cancellationToken);

//            var existingProductLinks = questionnaire.QuestionnaireProducts
//                .Where(qp => !qp.IsDeleted)
//                .ToList();


//            foreach (var link in existingProductLinks)
//            {
//                if (!validProductIds.Contains(link.ProductId))
//                {
//                    link.IsDeleted = true;
//                    link.IsActive = false;
//                }
//            }


//            foreach (var productId in validProductIds)
//            {
//                if (!existingProductLinks.Any(qp => qp.ProductId == productId && !qp.IsDeleted))
//                {
//                    questionnaire.QuestionnaireProducts.Add(new QuestionnaireProduct
//                    {
//                        ProductId = productId,
//                        IsActive = true,
//                        IsDeleted = false,
//                        CreatedDate = DateTime.UtcNow
//                    });
//                }
//            }
//        }

//        await _novaHealthDbContext.SaveChangesAsync(cancellationToken);
//        return true;
//    }
//}

using MediatR;
using Microsoft.EntityFrameworkCore;
using NovaHealth.Application.Common.Interfaces;
using NovaHealth.Domain.Entities;

namespace NovaHealth.Application.Questionnaires.Command.AddUpdateQuestionnaire;

public class AddUpdateQuestionnaireRequestHandler : IRequestHandler<AddUpdateQuestionnaireRequest, bool>
{
    private readonly INovaHealthDbContext _novaHealthDbContext;

    public AddUpdateQuestionnaireRequestHandler(INovaHealthDbContext novaHealthDbContext)
    {
        _novaHealthDbContext = novaHealthDbContext;
    }

    public async Task<bool> Handle(AddUpdateQuestionnaireRequest request, CancellationToken cancellationToken)
    {
        var questionnaire = await _novaHealthDbContext.Questionnaires
                            .Include(q => q.QuestionnaireProducts)
                            .FirstOrDefaultAsync(q => q.Id == request.Id, cancellationToken);

        if (questionnaire != null)
        {
            // 🔄 Update existing
            questionnaire.Title = request.Title;
            questionnaire.Slug = request.Slug;
            questionnaire.WebDomainId = request.DomainId;
            questionnaire.IsPublished = request.IsPublished;
            questionnaire.Status = request.Status;
            questionnaire.Mode = request.Mode;
            questionnaire.QuestionnaireTreatmentTypeId = request.QuestionnaireTreatmentTypeId;
            questionnaire.QuestionnaireTypeId = request.QuestionnaireTypeId;
            //   questionnaire.QuestionnaireDefaultLanguageId = request.QuestionnaireDefaultLanguageId;
            questionnaire.QuestionnaireGlobalLayoutId = request.QuestionnaireGlobalLayoutId;
            questionnaire.BelugaEnabledRX = request.BelugaEnabledRX;
            //   questionnaire.EnableTranslation = request.EnableTranslation;
            questionnaire.IsActive = true;
            questionnaire.CreatedDate = DateTime.UtcNow;

            // 🔄 Handle Product Associations
            if (request.Products != null && request.Products.Any())
            {
                var incomingProductIds = request.Products.Distinct().ToList();

                // Remove unlinked products
                var toRemove = questionnaire.QuestionnaireProducts
                                .Where(p => !incomingProductIds.Contains(p.ProductId) && !p.IsDeleted)
                                .ToList();

                foreach (var remove in toRemove)
                {
                    remove.IsDeleted = true;
                    remove.IsActive = false;
                }

                // Add or reactivate incoming products
                foreach (var productId in incomingProductIds)
                {
                    var existing = questionnaire.QuestionnaireProducts
                        .FirstOrDefault(p => p.ProductId == productId);

                    if (existing != null)
                    {
                        existing.IsDeleted = false;
                        existing.IsActive = true;
                    }
                    else
                    {
                        questionnaire.QuestionnaireProducts.Add(new QuestionnaireProduct
                        {
                            ProductId = productId,
                            IsActive = true,
                            IsDeleted = false,
                            CreatedDate = DateTime.UtcNow
                        });
                    }
                }
            }
            else
            {
                // No product list → mark all as deleted
                foreach (var product in questionnaire.QuestionnaireProducts)
                {
                    product.IsDeleted = true;
                    product.IsActive = false;
                }
            }
        }
        else
        {
            // ➕ Insert new
            questionnaire = new Questionnaire
            {
                Title = request.Title,
                Slug = request.Slug,
                WebDomainId = request.DomainId,
                IsPublished = request.IsPublished,
                Status = request.Status,
                Mode = request.Mode,
                QuestionnaireTreatmentTypeId = request.QuestionnaireTreatmentTypeId,
                QuestionnaireTypeId = request.QuestionnaireTypeId,
                //   QuestionnaireDefaultLanguageId = request.QuestionnaireDefaultLanguageId,
                QuestionnaireGlobalLayoutId = request.QuestionnaireGlobalLayoutId,
                BelugaEnabledRX = request.BelugaEnabledRX,
                //  EnableTranslation = request.EnableTranslation,
                IsActive = true,
                IsDeleted = false,
                CreatedDate = DateTime.UtcNow,
                QuestionnaireProducts = new List<QuestionnaireProduct>()
            };

            if (request.Products != null && request.Products.Any())
            {
                foreach (var productId in request.Products.Distinct())
                {
                    questionnaire.QuestionnaireProducts.Add(new QuestionnaireProduct
                    {
                        ProductId = productId,
                        IsActive = true,
                        IsDeleted = false,
                        CreatedDate = DateTime.UtcNow
                    });
                }
            }

            await _novaHealthDbContext.Questionnaires.AddAsync(questionnaire, cancellationToken);
        }

        await _novaHealthDbContext.SaveChangesAsync(cancellationToken);
        return true;
    }
}
