﻿using MediatR;
using Microsoft.EntityFrameworkCore;
using NovaHealth.Application.Common.Exceptions;
using NovaHealth.Application.Common.Interfaces;
using System.Text.Json.Serialization;

namespace NovaHealth.Application.Questionnaires.Command.DeleteQuestionnaire;

public class QuestionnaireDeleteByIdRequest : IRequest<bool>
{
    [JsonIgnore] public long QuestionnaireId { get; set; }

    [JsonIgnore] public bool IsDeleted { get; set; }
}

public class QuestionDeleteByIdRequestHandler : IRequestHandler<QuestionnaireDeleteByIdRequest, bool>
{

    private readonly INovaHealthDbContext _novaHealthDbContext;
    public QuestionDeleteByIdRequestHandler(INovaHealthDbContext novaHealthDbContext)
    {
        _novaHealthDbContext = novaHealthDbContext;
    }

    public async Task<bool> Handle(QuestionnaireDeleteByIdRequest request, CancellationToken cancellationToken)
    {
        var Questionnaire = await _novaHealthDbContext.Questionnaires
                           .FirstOrDefaultAsync(q => q.Id == request.QuestionnaireId, cancellationToken);

        if (Questionnaire == null)
            throw new NotFoundException("QuestionnaireId not found.");

        Questionnaire.IsDeleted = request.IsDeleted;

        await _novaHealthDbContext.SaveChangesAsync(cancellationToken);

        return true;
    }
}