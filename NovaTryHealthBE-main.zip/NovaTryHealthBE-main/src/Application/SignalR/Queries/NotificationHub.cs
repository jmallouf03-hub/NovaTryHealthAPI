﻿using Microsoft.AspNetCore.SignalR;
using NovaHealth.Application.SignalR.Interface;

namespace NovaHealth.Application.SignalR.Queries;
public class NotificationHub : Hub
{
    private readonly IUserConnectionManager _userConnectionManager;

    public NotificationHub(IUserConnectionManager userConnectionManager)
    {
        _userConnectionManager = userConnectionManager;
    }

    public string GetConnectionId()
    {
        var httpContext = this.Context.GetHttpContext();
        var userId = httpContext?.Request.Query["userId"].ToString();

        if (!string.IsNullOrEmpty(userId))
        {
            _userConnectionManager.KeepUserConnection(userId, Context.ConnectionId);
        }

        return Context.ConnectionId;
    }


    public async Task SendMessage(string user, string message)
    {
        await Clients.User(user).SendAsync("ReceiveNotification", message);
    }


    public async Task SendNotificationCountUpdate(string userId, int count)
    {
        await Clients.User(userId).SendAsync("ReceiveNotificationCountUpdate", count);
    }
}