﻿namespace NovaHealth.Application.SignalR.Interface;

public class UserConnectionManager : IUserConnectionManager
{
    private static readonly Dictionary<string, List<string>> userConnectionMap = new();
    private static readonly object userConnectionMapLocker = new();

    public void KeepUserConnection(string userId, string connectionId)
    {
        lock (userConnectionMapLocker)
        {
            if (!userConnectionMap.ContainsKey(userId))
            {
                userConnectionMap[userId] = new List<string>();
            }

            var connectionList = userConnectionMap[userId];

            // Remove any existing connectionId for the user
            if (connectionList.Contains(connectionId))
            {
                connectionList.Remove(connectionId);
            }

            // Add the new connectionId
            connectionList.Add(connectionId);
        }
    }

    public void RemoveUserConnection(string connectionId)
    {
        lock (userConnectionMapLocker)
        {
            foreach (var userId in userConnectionMap.Keys)
            {
                if (userConnectionMap[userId].Contains(connectionId))
                {
                    userConnectionMap[userId].Remove(connectionId);
                    if (!userConnectionMap[userId].Any())
                    {
                        userConnectionMap.Remove(userId);
                    }
                    break;
                }
            }
        }
    }
    public List<string> GetUserConnections(string userId)
    {
        lock (userConnectionMapLocker)
        {
            if (userConnectionMap.ContainsKey(userId))
            {
                return userConnectionMap[userId];
            }
            return new List<string>();
        }
    }
}