﻿using AutoMapper;
using MediatR;
using Microsoft.EntityFrameworkCore;
using NovaHealth.Application.Common.Interfaces;
using NovaHealth.Application.Common.Mappings;
using NovaHealth.Application.Common.Models;
using System.Linq.Dynamic.Core;
using System.Text.Json.Serialization;

namespace NovaHealth.Application.Patient.Queries.GetPatientOrderList;

public class GetPatientOrderListRequest : PaginationFilter, IRequest<PaginationResponse<GetPatientOrderListResponse>>
{
    [JsonIgnore] public long UserId { get; set; }
}

public class GetPatientOrderListRequestHandler : IRequestHandler<GetPatientOrderListRequest, PaginationResponse<GetPatientOrderListResponse>>
{
    private readonly INovaHealthDbContext _novaHealthDbContext;
    private readonly IMapper _mapper;

    public GetPatientOrderListRequestHandler(INovaHealthDbContext novaHealthDbContext, IMapper mapper)
    {
        _novaHealthDbContext = novaHealthDbContext;
        _mapper = mapper;
    }

    public async Task<PaginationResponse<GetPatientOrderListResponse>> Handle(GetPatientOrderListRequest request, CancellationToken cancellationToken)
    {

        var user = await _novaHealthDbContext.Users
                    .Include(u => u.UserRoles).ThenInclude(ur => ur.Role)
                    .FirstOrDefaultAsync(u => u.Id == request.UserId && !u.IsDeleted && u.IsActive, cancellationToken);

        if (user == null || !user.UserRoles.Any(ur => ur.Role.RoleType == RoleType.Patient))
        {
            throw new Exception("doctor not found exists.");
        }

        var doctorOrders = _novaHealthDbContext.BookOrders
                            .Include(x => x.ProductOrders).ThenInclude(x => x.Product).ThenInclude(x => x.Variants)
                          .Include(o => o.User).ThenInclude(u => u.UserRoles).Where(o => o.UserId == request.UserId)


          .Select(o => new GetPatientOrderListResponse
          {
              Id = o.Id,
              GuidNumber = o.Guid,
              Guid = o.Guid.ToString("N").ToLower().Substring(o.Guid.ToString("N").Length - 6),
              UserId = o.UserId,

              OrderDate = o.CreatedDate,
              Status = o.PaymentStatus,
              TotalAmount = o.Amount,
              CratedDate= o.CreatedDate,


              Address1 = o.User.UserAddresses.FirstOrDefault() != null
                                        ? o.User.UserAddresses.FirstOrDefault()!.Address1 : null,
              Address2 = o.User.UserAddresses.FirstOrDefault() != null
                                        ? o.User.UserAddresses.FirstOrDefault()!.Address2 : null,
              City = o.User.UserAddresses.FirstOrDefault() != null
                                        ? o.User.UserAddresses.FirstOrDefault()!.City : null,
              StateId = o.User.UserAddresses.FirstOrDefault() != null
                                        ? o.User.UserAddresses.FirstOrDefault()!.StateId : null,
              ZipCode = o.User.UserAddresses.FirstOrDefault() != null
                                        ? o.User.UserAddresses.FirstOrDefault()!.ZipCode : null,
              PhoneNumber = o.User.PhoneNumber,
              PatientName = o.User.FirstName + " " + o.User.LastName,

              SessionId = o.SessionId,
              // Product info (flattened query)
              RegularImageUrlFilePath = o.ProductOrders
                                .OrderBy(po => po.Id)
                                .Select(po => po.Product.Variants.OrderBy(v => v.Id).Select(v => v.RegularImageUrlFilePath).FirstOrDefault())
                                .FirstOrDefault(),

              ProductName = o.ProductOrders
                                .OrderBy(po => po.Id)
                                .Select(po => po.Product.DrugName ?? po.Product.BrandName ?? po.Product.ShortName)
                                .FirstOrDefault(),

              ProductId = o.ProductOrders
                                .OrderBy(po => po.Id)
                                .Select(po => po.ProductId)
                                .FirstOrDefault(),

              Quantity = o.ProductOrders
                                .OrderBy(po => po.Id)
                                .Select(po => po.Quantity)
                                .FirstOrDefault(),

              Amount = o.ProductOrders
                                .OrderBy(po => po.Id)
                                .Select(po => po.Amount)
                                .FirstOrDefault(),

              Strength = o.ProductOrders
                                .OrderBy(po => po.Id)
                                .Select(po => po.Product.Variants.OrderBy(v => v.Id).Select(v => v.Strength).FirstOrDefault())
                                .FirstOrDefault(),

              Dose = o.ProductOrders
                                .OrderBy(po => po.Id)
                                .Select(po => po.Product.Variants.OrderBy(v => v.Id).Select(v => v.Dose).FirstOrDefault())
                                .FirstOrDefault(),

              Price = o.ProductOrders
                                .OrderBy(po => po.Id)
                                .Select(po => po.Product.Variants.OrderBy(v => v.Id).Select(v => v.Price).FirstOrDefault())
                                .FirstOrDefault(),

              ProfilePictureName = o.User.ProfilePictureName,
              ProfilePicturePath = o.User.ProfilePicturePath,

          });



        // Apply filter dynamically if provided
        if (!string.IsNullOrEmpty(request.Filter))
        {
            doctorOrders = doctorOrders.Where(request.Filter);
        }

        // Apply ordering if provided
        if (!string.IsNullOrEmpty(request.OrderBy))
        {
            doctorOrders = doctorOrders.OrderBy(request.OrderBy);
        }


        else
        {
            // Default: latest order first
            doctorOrders = doctorOrders.OrderByDescending(o => o.OrderDate);
        }

        // Paginate and return
        return await doctorOrders.PaginatedListAsync(request.PageNumber, request.PageSize);
    }
}