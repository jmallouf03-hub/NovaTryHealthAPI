﻿using MediatR;
using Microsoft.EntityFrameworkCore;
using NovaHealth.Application.Common.Interfaces;
using System.Text.Json.Serialization;

namespace NovaHealth.Application.Patient.Queries.GetPatientOrderCount;

public class GetPatientOrderCountRequest : IRequest<GetPatientOrderCountResponse>
{
    [JsonIgnore] public long UserId { get; set; }
}

public class GetPatientOrderCountRequestHandler : IRequestHandler<GetPatientOrderCountRequest, GetPatientOrderCountResponse>
{
    private readonly INovaHealthDbContext _novaHealthDbContext;

    public GetPatientOrderCountRequestHandler(INovaHealthDbContext novaHealthDbContext)
    {
        _novaHealthDbContext = novaHealthDbContext;

    }
    public async Task<GetPatientOrderCountResponse> Handle(GetPatientOrderCountRequest request, CancellationToken cancellationToken)
    {

        var query = _novaHealthDbContext.BookOrders
                    .Where(x => x.UserId == request.UserId && !x.IsDeleted && x.IsActive);

        var totalCount = await query.CountAsync(cancellationToken);

        var totalPending = await query.CountAsync(x => x.PaymentStatus == PaymentStatusType.Pending, cancellationToken);
        var totalCompleted = await query.CountAsync(x => x.PaymentStatus == PaymentStatusType.Completed, cancellationToken);
        var totalFailed = await query.CountAsync(x => x.PaymentStatus == PaymentStatusType.Failed, cancellationToken);
        var totalCanceled = await query.CountAsync(x => x.PaymentStatus == PaymentStatusType.Canceled, cancellationToken);


        return new GetPatientOrderCountResponse
        {
            TotalBookOrderCount = totalCount,
            TotalPendingStatus = totalPending,
            TotalCompletedStatus = totalCompleted,
            TotalFailedStatus = totalFailed,
            TotalCanceledStatus = totalCanceled
        };
    }
}