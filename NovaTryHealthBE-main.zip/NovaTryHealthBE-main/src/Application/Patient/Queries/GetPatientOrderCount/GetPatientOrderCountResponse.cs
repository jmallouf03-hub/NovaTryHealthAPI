﻿namespace NovaHealth.Application.Patient.Queries.GetPatientOrderCount;

public class GetPatientOrderCountResponse
{
    public int TotalBookOrderCount { get; set; }

    public int TotalPendingStatus { get; set; }
    public int TotalCompletedStatus { get; set; }

    public int TotalFailedStatus { get; set; }

    public int TotalCanceledStatus { get; set; }
}