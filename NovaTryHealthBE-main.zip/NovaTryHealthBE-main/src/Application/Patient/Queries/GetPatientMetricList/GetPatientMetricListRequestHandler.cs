﻿using AutoMapper;
using MediatR;
using NovaHealth.Application.Common.Interfaces;
using NovaHealth.Application.Common.Models;
using NovaHealth.Application.Common.Mappings;
using Microsoft.EntityFrameworkCore;
using System.Linq.Dynamic.Core;
using AutoMapper.QueryableExtensions;

namespace NovaHealth.Application.Patient.Queries.GetPatientMetricList;

public class GetPatientMetricListRequest : PaginationFilter, IRequest<PaginationResponse<GetPatientMetricListResponse>> { }

public class GetPatientMetricListRequestHandler : IRequestHandler<GetPatientMetricListRequest, PaginationResponse<GetPatientMetricListResponse>>
{
    private readonly INovaHealthDbContext _novaHealthDbContext;
    private readonly IMapper _mapper;

    public GetPatientMetricListRequestHandler(INovaHealthDbContext novaHealthDbContext, IMapper mapper)
    {
        _novaHealthDbContext = novaHealthDbContext;
        _mapper = mapper;
    }
    public async Task<PaginationResponse<GetPatientMetricListResponse>> Handle(GetPatientMetricListRequest request, CancellationToken cancellationToken)
    {

        var query = _novaHealthDbContext.PatientMetrics
                    .AsNoTracking()
                    .Select(x => new GetPatientMetricListResponse
                    {
                        Id = x.Id,
                        MetricName = x.MetricName,
                    });

        if (!string.IsNullOrEmpty(request.Filter))
        {
            query = query.Where(request.Filter);
        }

        // Apply order
        if (!string.IsNullOrEmpty(request.OrderBy))
        {
            query = query.OrderBy(request.OrderBy);
        }
        else
        {
            query = query.OrderBy(x => x.Id);
        }

        return await query.ProjectTo<GetPatientMetricListResponse>(_mapper.ConfigurationProvider)
           .PaginatedListAsync(request.PageNumber, request.PageSize);
    }
}
