﻿using AutoMapper;

namespace NovaHealth.Application.Patient.Queries.GetPatientMetricList;

public class GetPatientMetricListResponse
{
    public long Id { get; set; }

    public string MetricName { get; set; } = null!;

    public class Mapping : Profile
    {
        public Mapping()
        {
            CreateMap<GetPatientMetricListResponse, GetPatientMetricListResponse>();
        }

    }
}