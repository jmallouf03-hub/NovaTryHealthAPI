﻿using AutoMapper;

namespace NovaHealth.Application.Patient.Queries.GetPatientList;

public class GetPatientListResponse
{
    public long Id { get; set; }
    public string FullName { get; set; } = null!;

    public string? PhoneNumber { get; set; }

    public DateTime? DateOfBirth { get; set; }

    public GenderTypeOption GenderType { get; set; }

    public string Email { get; set; } = null!;

    public DateTime CreatedDate { get; set; }

    public bool IsDisabledByAdmin { get; set; }
    public string? ProfilePictureName { get; set; }

    public string? ProfilePicturePath { get; set; }

    public long SuperParentMessageId { get; set; }

    public long MessageId { get; set; }

    public int UnreadMessageCount { get; set; }
    public class Mapping : Profile
    {
        public Mapping()
        {
            CreateMap<GetPatientListResponse, GetPatientListResponse>();
        }
    }
}