﻿using AutoMapper;
using AutoMapper.QueryableExtensions;
using MediatR;
using Microsoft.EntityFrameworkCore;
using NovaHealth.Application.Common.Interfaces;
using NovaHealth.Application.Common.Mappings;
using NovaHealth.Application.Common.Models;
using System.Linq.Dynamic.Core;

namespace NovaHealth.Application.Patient.Queries.GetPatientList;

public class GetPatientListRequest : PaginationFilter, IRequest<PaginationResponse<GetPatientListResponse>>
{
    public long UserId { get; set; }
}

public class GetPatientListRequestHandler : IRequestHandler<GetPatientListRequest, PaginationResponse<GetPatientListResponse>>
{
    private readonly INovaHealthDbContext _novaHealthDbContext;
    private readonly IMapper _mapper;

    public GetPatientListRequestHandler(INovaHealthDbContext novaHealthDbContext, IMapper mapper)
    {
        _novaHealthDbContext = novaHealthDbContext;
        _mapper = mapper;
    }

    public async Task<PaginationResponse<GetPatientListResponse>> Handle(GetPatientListRequest request, CancellationToken cancellationToken)
    {
        // Step 1: Check if requester is Admin
        var isAdmin = await _novaHealthDbContext.Users
                    .Where(u => u.Id == request.UserId && u.IsActive && !u.IsDeleted)
                    .AnyAsync(u => u.UserRoles.Any(ur => ur.Role.RoleType == RoleType.Admin && ur.IsActive && !ur.IsDeleted), cancellationToken);

        // Step 2: Base query for patients
        var query = _novaHealthDbContext.Users
                    .AsNoTracking()
                    .Include(u => u.UserRoles)
                        .ThenInclude(ur => ur.Role)
                    .Where(u => !u.IsDeleted && u.UserRoles.Any(ur => ur.Role.RoleType == RoleType.Patient));

        // Step 3: Apply the "is disabled" logic
        // Admin sees all, non-admin sees only disabled patients
        query = query.Where(u => isAdmin || u.IsDisabledByAdmin);

        // Step 4: Project to DTO
        var patientQuery = query.Select(x => new GetPatientListResponse
        {
            Id = x.Id,
            FullName = x.FirstName + " " + x.LastName,
            DateOfBirth = x.DateOfBirth,
            Email = x.Email,
            PhoneNumber = x.PhoneNumber,
            GenderType = x.Gender,
            CreatedDate = x.CreatedDate,
            IsDisabledByAdmin = x.IsDisabledByAdmin,
            ProfilePictureName = x.ProfilePictureName,
            ProfilePicturePath = x.ProfilePicturePath,

            SuperParentMessageId = (
                                    from recipient in _novaHealthDbContext.MessageRecipients
                                    join message in _novaHealthDbContext.Messages on recipient.MessageId equals message.Id
                                    join sender in _novaHealthDbContext.MessageSenders on message.Id equals sender.MessageId
                                    where (sender.SenderId == request.UserId && recipient.ReceiverId == x.Id)
                                       || (sender.SenderId == x.Id && recipient.ReceiverId == request.UserId) && message.SupportMessage == false
                                    select recipient.SuperParentMessageId
                                ).FirstOrDefault(),

            MessageId = (
                            from recipient in _novaHealthDbContext.MessageRecipients
                            join message in _novaHealthDbContext.Messages on recipient.MessageId equals message.Id
                            join sender in _novaHealthDbContext.MessageSenders on message.Id equals sender.MessageId
                            where (sender.SenderId == request.UserId && recipient.ReceiverId == x.Id)
                               || (sender.SenderId == x.Id && recipient.ReceiverId == request.UserId) && message.SupportMessage == false
                            orderby message.Id descending
                            select message.Id
                        ).FirstOrDefault(),
        });

        // Step 5: Optional filter
        if (!string.IsNullOrEmpty(request.Filter))
        {
            patientQuery = patientQuery.Where(request.Filter);
        }

        // Step 6: Ordering
        if (!string.IsNullOrEmpty(request.OrderBy))
        {
            patientQuery = patientQuery.OrderBy(request.OrderBy);
        }
        else
        {
            patientQuery = patientQuery.OrderByDescending(x => x.Id);
        }

        // Step 7: Return paginated response
        return await patientQuery
            .ProjectTo<GetPatientListResponse>(_mapper.ConfigurationProvider)
            .PaginatedListAsync(request.PageNumber, request.PageSize);
    }
}
