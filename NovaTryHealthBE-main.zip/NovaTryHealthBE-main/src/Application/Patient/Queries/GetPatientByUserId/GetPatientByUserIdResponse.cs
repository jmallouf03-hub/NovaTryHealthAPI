﻿namespace NovaHealth.Application.Patient.Queries.GetPatientByUserId;
public class GetPatientByUserIdResponse
{
    public long? UserId { get; set; }

    public string? FirstName { get; set; }

    public string? LastName { get; set; }

    public string? Email { get; set; }

    public string? PhoneNumber { get; set; }

    public DateTime? DateOfBirth { get; set; }

    public GenderTypeOption? Gender { get; set; }

    public string? Address1 { get; set; }

    public string? Address2 { get; set; }

    public string? City { get; set; }

    public string? StateName { get; set; }

    public int StateId { get; set; }

    public string? ZipCode { get; set; }

    public string? ProfilePictureName { get; set; }

    public string? ProfilePicturePath { get; set; }
}
