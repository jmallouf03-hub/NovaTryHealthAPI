﻿using MediatR;
using Microsoft.EntityFrameworkCore;
using NovaHealth.Application.Common.Exceptions;
using NovaHealth.Application.Common.Interfaces;
using System.Text.Json.Serialization;
namespace NovaHealth.Application.Patient.Queries.GetPatientByUserId;

public record GetPatientByUserIdRequest : IRequest<GetPatientByUserIdResponse>
{
    [JsonIgnore] public long UserId { get; set; }
}

public class GetPatientByUserIdRequestHandler : IRequestHandler<GetPatientByUserIdRequest, GetPatientByUserIdResponse>
{
    private readonly INovaHealthDbContext _novaHealthDbContext;

    public GetPatientByUserIdRequestHandler(INovaHealthDbContext novaHealthDbContext)
    {
        _novaHealthDbContext = novaHealthDbContext;
    }

    public async Task<GetPatientByUserIdResponse> Handle(GetPatientByUserIdRequest request, CancellationToken cancellationToken)
    {
        var patientProfile = await _novaHealthDbContext.Users
             .Include(u => u.UserAddresses)
                 .ThenInclude(a => a.State)
             .Include(u => u.DoctorCategories)
                 .ThenInclude(dc => dc.Category)
             .FirstOrDefaultAsync(u => u.Id == request.UserId && u.IsActive &&
             u.UserRoles.Any(ur => ur.Role.RoleType == RoleType.Patient), cancellationToken);

        if (patientProfile == null)
        {
            throw new NotFoundException($"Patient profile with UserId {request.UserId} not found.");
        }

        // Get the single address
        var address = patientProfile.UserAddresses.FirstOrDefault();

        var response = new GetPatientByUserIdResponse
        {
            UserId = patientProfile.Id,
            FirstName = patientProfile.FirstName,
            LastName = patientProfile.LastName,
            Email = patientProfile.Email,
            PhoneNumber = patientProfile.PhoneNumber,
            DateOfBirth = patientProfile.DateOfBirth,
            Gender = patientProfile.Gender,
            Address1 = address?.Address1,
            Address2 = address?.Address2,
            City = address?.City,
            StateId = address?.StateId ?? 0,
            StateName = address?.State?.StateName,
            ZipCode = address?.ZipCode,
            ProfilePictureName = patientProfile.ProfilePictureName,
            ProfilePicturePath = patientProfile.ProfilePicturePath

        };

        return response;
    }
}