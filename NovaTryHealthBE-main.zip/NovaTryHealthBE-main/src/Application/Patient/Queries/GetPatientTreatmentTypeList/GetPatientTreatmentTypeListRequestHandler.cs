﻿using AutoMapper;
using AutoMapper.QueryableExtensions;
using MediatR;
using Microsoft.EntityFrameworkCore;
using NovaHealth.Application.Common.Interfaces;
using NovaHealth.Application.Common.Mappings;
using NovaHealth.Application.Common.Models;
using System.Linq.Dynamic.Core;

namespace NovaHealth.Application.Patient.Queries.GetPatientTreatmentTypeList;

public class GetPatientTreatmentTypeListRequest : PaginationFilter, IRequest<PaginationResponse<GetPatientTreatmentTypeListResponse>> { }

public class GetPatientTreatmentTypeListRequestHandler : IRequestHandler<GetPatientTreatmentTypeListRequest, PaginationResponse<GetPatientTreatmentTypeListResponse>>
{
    private readonly INovaHealthDbContext _novaHealthDbContext;
    private readonly IMapper _mapper;

    public GetPatientTreatmentTypeListRequestHandler(INovaHealthDbContext novaHealthDbContext, IMapper mapper)
    {
        _novaHealthDbContext = novaHealthDbContext;
        _mapper = mapper;
    }
    public async Task<PaginationResponse<GetPatientTreatmentTypeListResponse>> Handle(GetPatientTreatmentTypeListRequest request, CancellationToken cancellationToken)
    {

        var query = _novaHealthDbContext.PatientTreatmentTypes
                    .AsNoTracking()
                    .Select(x => new GetPatientTreatmentTypeListResponse
                    {
                        Id = x.Id,
                        TreatmentTypeName = x.TreatmentType,
                    });
        if (!string.IsNullOrEmpty(request.Filter))
        {
            query = query.Where(request.Filter);
        }

        // Apply order
        if (!string.IsNullOrEmpty(request.OrderBy))
        {
            query = query.OrderBy(request.OrderBy);
        }
        else
        {
            query = query.OrderBy(x => x.Id);
        }

        return await query.ProjectTo<GetPatientTreatmentTypeListResponse>(_mapper.ConfigurationProvider)
           .PaginatedListAsync(request.PageNumber, request.PageSize);
    }
}