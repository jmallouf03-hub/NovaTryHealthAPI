﻿using AutoMapper;

namespace NovaHealth.Application.Patient.Queries.GetPatientTreatmentTypeList;

public class GetPatientTreatmentTypeListResponse
{
    public long Id { get; set; }

    public string TreatmentTypeName { get; set; } = null!;

    public class Mapping : Profile
    {
        public Mapping()
        {
            CreateMap<GetPatientTreatmentTypeListResponse, GetPatientTreatmentTypeListResponse>();
        }

    }
}