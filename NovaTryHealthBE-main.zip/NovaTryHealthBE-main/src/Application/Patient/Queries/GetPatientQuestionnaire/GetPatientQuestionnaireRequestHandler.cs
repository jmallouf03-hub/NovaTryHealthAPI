﻿using MediatR;
using Microsoft.EntityFrameworkCore;
using NovaHealth.Application.Common.Interfaces;
using System.Text.Json.Serialization;

namespace NovaHealth.Application.Patient.Queries.GetPatientQuestionnaire;

public record GetPatientQuestionnaireRequest : IRequest<GetPatientDetailQuestionnaireResponse>
{
    [JsonIgnore] public long UserId { get; set; }

    [JsonIgnore] public string SessionId { get; set; }
}

public class GetPatientQuestionnaireRequestHandler : IRequestHandler<GetPatientQuestionnaireRequest, GetPatientDetailQuestionnaireResponse>
{
    private readonly INovaHealthDbContext _novaHealthDbContext;

    public GetPatientQuestionnaireRequestHandler(INovaHealthDbContext novaHealthDbContext)
    {
        _novaHealthDbContext = novaHealthDbContext;
    }

    public async Task<GetPatientDetailQuestionnaireResponse> Handle(GetPatientQuestionnaireRequest request, CancellationToken cancellationToken)
    {
        //var lastSessionId = await _novaHealthDbContext.PatientQuestionAnswers
        //.Where(pqa => pqa.PatientId == request.UserId)
        //.OrderByDescending(pqa => pqa.CreatedDate)
        //.Select(pqa => pqa.SessionId)
        //.FirstOrDefaultAsync(cancellationToken);

        if (request.SessionId == null)
            return null;

        var sessionId = request.SessionId.Trim();

        // Get patient info + questions in one object
        var response = await _novaHealthDbContext.Users
            .Where(p => p.Id == request.UserId)
            .Select(p => new GetPatientDetailQuestionnaireResponse
            {
                UserId = p.Id,
                Name = p.FirstName + " " + p.LastName,
                Email = p.Email,
                PhoneNumber = p.PhoneNumber,
                DOB = p.DateOfBirth ?? null,
                Questions = _novaHealthDbContext.PatientQuestionAnswers
                            .Where(pqa => pqa.SessionId == sessionId
                                       && pqa.Question.QuestionType.Type.ToLower() != "auth" && pqa.Question.QuestionType.Type.ToLower() != "checkout" && pqa.Question.QuestionType.Type.ToLower() != "finalcheckout")
                    .Select(pqa => new GetPatientQuestionnaireResponse
                    {
                        QuestionId = pqa.QuestionId,
                        QuestionName = pqa.Question.Name,
                        AnswerText = pqa.AnswerText,
                        FileUrl = pqa.FileUrl,
                        Options = pqa.PatientAnswers.Select(pa => new AnswerOptionResponse
                        {
                            AnswerOptionId = pa.AnswerOptionId,
                            OptionText = pa.AnswerOption.Text,
                            ProductId = pa.AnswerOption.ProductId,
                        }).ToList()
                    }).ToList()
            })
            .FirstOrDefaultAsync(cancellationToken);

        return response;
    }
}