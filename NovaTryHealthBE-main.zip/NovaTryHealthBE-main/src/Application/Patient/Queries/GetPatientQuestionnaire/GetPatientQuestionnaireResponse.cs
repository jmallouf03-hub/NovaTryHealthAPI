﻿namespace NovaHealth.Application.Patient.Queries.GetPatientQuestionnaire;

public class GetPatientDetailQuestionnaireResponse
{
    public long UserId { get; set; }
    public string? Name { get; set; }
    public string Email { get; set; }

    public string? PhoneNumber { get; set; }
    public DateTime? DOB { get; set; }
    public List<GetPatientQuestionnaireResponse>? Questions { get; set; } = new List<GetPatientQuestionnaireResponse>();


}
public class GetPatientQuestionnaireResponse
{
    public long QuestionId { get; set; }
    public string? QuestionName { get; set; }
    public string? AnswerText { get; set; }
    public string? FileUrl { get; set; }
    public List<AnswerOptionResponse>? Options { get; set; } = new List<AnswerOptionResponse>();
}

public class AnswerOptionResponse
{
    public long AnswerOptionId { get; set; }
    public string? OptionText { get; set; }
    public long? ProductId { get; set; }
    public bool? Flag { get; set; }
}