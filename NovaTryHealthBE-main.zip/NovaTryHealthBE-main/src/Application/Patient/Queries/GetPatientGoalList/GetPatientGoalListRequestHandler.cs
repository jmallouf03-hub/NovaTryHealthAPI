﻿using AutoMapper;
using AutoMapper.QueryableExtensions;
using MediatR;
using Microsoft.EntityFrameworkCore;
using NovaHealth.Application.Common.Interfaces;
using NovaHealth.Application.Common.Mappings;
using NovaHealth.Application.Common.Models;
using System.Linq.Dynamic.Core;

namespace NovaHealth.Application.Patient.Queries.GetPatientGoalList;

public class GetPatientGoalListRequest : PaginationFilter, IRequest<PaginationResponse<GetPatientGoalListResponse>> { }

public class GetPatientGoalListRequestHandler : IRequestHandler<GetPatientGoalListRequest, PaginationResponse<GetPatientGoalListResponse>>
{
    private readonly INovaHealthDbContext _novaHealthDbContext;
    private readonly IMapper _mapper;

    public GetPatientGoalListRequestHandler(INovaHealthDbContext novaHealthDbContext, IMapper mapper)
    {
        _novaHealthDbContext = novaHealthDbContext;
        _mapper = mapper;
    }
    public async Task<PaginationResponse<GetPatientGoalListResponse>> Handle(GetPatientGoalListRequest request, CancellationToken cancellationToken)
    {

        var query = _novaHealthDbContext.PatientGoals
            .AsNoTracking()
            .Where(x => !x.IsDeleted)
            .Select(x => new GetPatientGoalListResponse
            {
                Id = x.Id,
                Goal = x.Goal,
                PatientTreatmentTypeId = x.PatientTreatmentTypeId,
                PatientMetricId = x.PatientMetricId,
                StartDate = x.StartDate,
                EndDate = x.EndDate,
                TargetValuelBsForWeight = x.TargetValuelBsForWeight,
                CreatedDate = x.CreatedDate,
            });
        if (!string.IsNullOrEmpty(request.Filter))
        {
            query = query.Where(request.Filter);
        }
        // Apply order
        if (!string.IsNullOrEmpty(request.OrderBy))
        {
            query = query.OrderBy(request.OrderBy);
        }
        else
        {
            query = query.OrderBy(x => x.Id);
        }
        return await query.ProjectTo<GetPatientGoalListResponse>(_mapper.ConfigurationProvider)
           .PaginatedListAsync(request.PageNumber, request.PageSize);
    }
}
