﻿using AutoMapper;

namespace NovaHealth.Application.Patient.Queries.GetPatientGoalList;

public class GetPatientGoalListResponse
{
    public long Id { get; set; }
    public long UserId { get; set; }

    public string Goal = null!;

    public long PatientTreatmentTypeId { get; set; }

    public long PatientMetricId { get; set; }

    public string TargetValuelBsForWeight { get; set; } = null!;

    //public decimal TargetValuelBsForWeight { get; set; }

    public DateOnly StartDate { get; set; }

    public DateOnly EndDate { get; set; }

    public DateTime CreatedDate { get; set; }

    public class Mapping : Profile
    {
        public Mapping()
        {
            CreateMap<GetPatientGoalListResponse, GetPatientGoalListResponse>();
        }

    }
}
