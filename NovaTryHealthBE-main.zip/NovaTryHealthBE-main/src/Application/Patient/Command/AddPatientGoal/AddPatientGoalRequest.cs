﻿using MediatR;

namespace NovaHealth.Application.Patient.Command.AddPatientGoal;

public class AddPatientGoalRequest : IRequest<bool>
{
    public long UserId { get; set; }

    public string Goal = null!;

    public long PatientTreatmentTypeId { get; set; }

    public long PatientMetricId { get; set; }

    public string TargetValuelBsForWeight { get; set; } = null!;

    //public decimal TargetValuelBsForWeight { get; set; }

    public DateOnly StartDate { get; set; }

    public DateOnly EndDate { get; set; }
}
