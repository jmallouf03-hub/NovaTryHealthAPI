﻿using MediatR;
using Microsoft.EntityFrameworkCore;
using NovaHealth.Application.Common.Interfaces;
using NovaHealth.Domain.Entities;

namespace NovaHealth.Application.Patient.Command.AddPatientGoal;

public class AddPatientGoalRequestHandler : IRequestHandler<AddPatientGoalRequest, bool>
{
    private readonly INovaHealthDbContext _novaHealthDbContext;

    public AddPatientGoalRequestHandler(INovaHealthDbContext novaHealthDbContext)
    {
        _novaHealthDbContext = novaHealthDbContext;
    }

    public async Task<bool> Handle(AddPatientGoalRequest request, CancellationToken cancellationToken)
    {
        try
        {
            // ✅ Check if the patient exists
            var patient = await _novaHealthDbContext.Users
                            .Include(u => u.UserRoles).ThenInclude(ur => ur.Role)
                            .FirstOrDefaultAsync(
                            u => u.Id == request.UserId && u.UserRoles.Any(ur => ur.Role.RoleType == RoleType.Patient), cancellationToken  );

            if (patient == null)
            {
                throw new UnauthorizedAccessException("Only users with 'Patient' role can add patient goals.");
            }

            // ✅ Create new patient goal
            var newPatientGoal = new PatientGoal
            {
                UserId = request.UserId,
                Goal = request.Goal,
                PatientTreatmentTypeId = request.PatientTreatmentTypeId,
                PatientMetricId = request.PatientMetricId,
                StartDate = request.StartDate,
                EndDate = request.EndDate,
                TargetValuelBsForWeight = request.TargetValuelBsForWeight,
                CreatedDate = DateTime.UtcNow,
                IsActive = true,
                IsDeleted = false
            };

            await _novaHealthDbContext.PatientGoals.AddAsync(newPatientGoal, cancellationToken);
            await _novaHealthDbContext.SaveChangesAsync(cancellationToken);

            return true;
        }
        catch (UnauthorizedAccessException ex)
        {
            // Specific exception for unauthorized users
            throw;
        }
        catch (DbUpdateException ex)
        {
            // Database-related issues
            throw new Exception("A database error occurred while saving patient goal.", ex);
        }
        catch (Exception ex)
        {
            // General fallback error
            throw new Exception("An unexpected error occurred while adding patient goal.", ex);
        }
    }
}
