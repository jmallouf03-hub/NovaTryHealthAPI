﻿using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.SignalR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using NovaHealth.Application.Auth.Jwt;
using NovaHealth.Application.Common.Interfaces;
using NovaHealth.Application.Common.Mailing;
using NovaHealth.Application.Common.Sms;
using NovaHealth.Application.SignalR.Interface;
using NovaHealth.Application.SignalR.Queries;
using NovaHealth.Domain.Entities;
using Twilio.TwiML.Messaging;


namespace NovaHealth.Application.Patient.Command.SignUpPatient;

public class SignUpPatientRequest : IRequest<SignUpPatientResponse>
{
    public string FirstName { get; set; } = null!;

    public string? LastName { get; set; } = null;

    public string Email { get; set; } = null!;

    public DateTime? DateOfBirth { get; set; }

    public GenderTypeOption Gender { get; set; }

    public string Password { get; set; } = null!;

    public string? PhoneNumber { get; set; } = null;
}


public class SignUpPatientRequestHandler : IRequestHandler<SignUpPatientRequest, SignUpPatientResponse>
{
    private readonly INovaHealthDbContext _novaHealthDbContext;
    private readonly IEmailTemplateService _emailTemplateService;
    private readonly IMailService _mailService;
    private readonly ISmsService _smsService;
    private readonly AppSettings _appSettings;
    private readonly JwtSettings _jwtSettings;
    private readonly IHubContext<NotificationHub> _hubContext;
    private readonly IUserConnectionManager _userConnectionManager;
    private readonly IHttpContextAccessor _httpContextAccessor;
    private readonly ITimelineService _timelineService;

    public SignUpPatientRequestHandler(INovaHealthDbContext novaHealthDbContext, IEmailTemplateService emailTemplateService, IMailService mailService, ISmsService smsService, IOptions<AppSettings> appSettings, IOptions<JwtSettings> jwtSettings, IHttpContextAccessor httpContextAccessor, ITimelineService timelineService, IHubContext<NotificationHub> hubContext, IUserConnectionManager userConnectionManager)
    {
        _novaHealthDbContext = novaHealthDbContext;
        _emailTemplateService = emailTemplateService;
        _mailService = mailService;
        _smsService = smsService;
        _userConnectionManager = userConnectionManager;
        _appSettings = appSettings.Value;
        _hubContext = hubContext;
        _jwtSettings = jwtSettings.Value;
        _httpContextAccessor = httpContextAccessor;
        _timelineService = timelineService;
    }
    public async Task<SignUpPatientResponse> Handle(SignUpPatientRequest request, CancellationToken cancellationToken)
    {
        string email = request.Email.Trim().ToLower();
        var existingUser = await _novaHealthDbContext.Users
            .FirstOrDefaultAsync(x => x.Email == email && !x.IsDeleted, cancellationToken);
        if (existingUser != null)
        {
            throw new Exception("Email already exists.");
        }

        var newUser = new User
        {
            FirstName = request.FirstName,
            LastName = request.LastName,
            CreatedDate = DateTime.UtcNow,
            Password = SecurityHelper.HashPassword(request.Password),
            Email = email,
            DateOfBirth = request.DateOfBirth,
            IsActive = true,
            IsDeleted = false,
            IsDisabledByAdmin = true,
            IsEmailVerified = false,
            PhoneNumber = request.PhoneNumber,
            Gender = request.Gender,
        };

        _novaHealthDbContext.Users.Add(newUser);
        await _novaHealthDbContext.SaveChangesAsync(cancellationToken);

        string otp = CommonHelper.GenerateOTP();

        var otpStore = new OTP
        {
            UserId = newUser.Id,
            OtpCode = otp,
            ExpiryDate = DateTime.Now.AddMinutes(5),
            CreatedDate = DateTime.Now,
        };


        _novaHealthDbContext.OTPs.Add(otpStore);

        await _novaHealthDbContext.SaveChangesAsync(cancellationToken);

        var patientRole = await _novaHealthDbContext.Roles
                  .FirstOrDefaultAsync(r => r.RoleType == RoleType.Patient, cancellationToken);

        if (patientRole == null)
            throw new Exception("Patient role does not exist in the system.");

        var newRole = new UserRole
        {
            UserId = newUser.Id,
            RoleId = patientRole.Id,
            IsActive = true,
            IsDeleted = false
        };

        await _novaHealthDbContext.UserRoles.AddAsync(newRole, cancellationToken);

        await _novaHealthDbContext.SaveChangesAsync(cancellationToken);

        var logoPath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "images", "logo.png");
        byte[]? logoBytes = null;

        if (File.Exists(logoPath))
        {
            logoBytes = File.ReadAllBytes(logoPath);
        }

        string loginEmailNormalized = newUser.Email.Trim().ToLower();

        var inlineAttachments = logoBytes != null
            ? new Dictionary<string, byte[]> { { "NovaHealthLogo", logoBytes } }
            : null;

        string emailBody = _emailTemplateService.GenerateEmailTemplate("sign-in-otp", new
        {
            FirstName = newUser.FirstName,
            OtpCode = otp,
            LogoCid = "cid:NovaHealthLogo"
        });

        var otpMailRequest = new MailRequest(
            to: new List<string> { newUser.Email },
            subject: "OTP for Your Account",
            body: emailBody,
            inlineAttachments: inlineAttachments,
            isHtmlBody: true
        );

        await _mailService.SendAsync(otpMailRequest, cancellationToken);


        var notification = new Notification
        {
            NotificationType = NotificationType.Patient,
            Title = "New Patient Arrived",
            Message = $"Patient {newUser.FirstName} {newUser.LastName} has registered.",
            CreatedBy = newUser.Id,
            CreatedDate = DateTime.UtcNow,
            IsActive = true
        };

        // Step 2: Find Admin UserId (receiver)
        var adminId = await _novaHealthDbContext.UserRoles
            .Where(ur => ur.Role.RoleType == RoleType.Admin && ur.IsActive && !ur.IsDeleted)
            .Select(ur => ur.UserId)
            .FirstOrDefaultAsync(cancellationToken);

        if (adminId > 0)
        {
            // Patient ne bheja → Admin ko mila
            var notificationRecipient = new UserNotificationReference
            {
                Notification = notification,
                UserId = adminId,
                NotificationTypeId = newUser.Id,
                IsRead = false,
                IsActive = true,
                IsDeleted = false,
                CreatedDate = DateTime.UtcNow
            };

            await _novaHealthDbContext.Notifications.AddAsync(notification, cancellationToken);
            await _novaHealthDbContext.UserNotificationReferences.AddAsync(notificationRecipient, cancellationToken);

            await _novaHealthDbContext.SaveChangesAsync(cancellationToken);


            var connections = _userConnectionManager.GetUserConnections(adminId.ToString());

            foreach (var connectionId in connections)
            {
                await _hubContext.Clients.Client(connectionId).SendAsync("ReceiveNotification", new
                {
                    NotificationId = notification.Id,
                    Title = notification.Title,
                    Message = notification.Message,
                    CreatedDate = notification.CreatedDate,
                    NotificationType = notification.NotificationType.ToString(),
                    SenderId = newUser.Id,
                    ReceiverId = adminId
                }, cancellationToken);
            }
        }

        var ipAddress = _httpContextAccessor.HttpContext?.Connection?.RemoteIpAddress?.ToString();

        if (_httpContextAccessor.HttpContext?.Request.Headers.ContainsKey("X-Forwarded-For") == true)
        {
            ipAddress = _httpContextAccessor.HttpContext.Request.Headers["X-Forwarded-For"].FirstOrDefault();
        }
        await _timelineService.LogTimelineEventAsync(
                     newUser.Id,
                     TimelineEventType.SignUp,
                     "Patient Signed Up",
                     "New patient account created successfully",
                     new { ipAddress }
                 );


        //  await SendMagicLinkAsync(newUser);
        return new SignUpPatientResponse
        {
            UserId = newUser.Id,
            Email = newUser.Email,
        };
    }
}
