﻿namespace NovaHealth.Application.Patient.Command.SignUpPatient;

public class SignUpPatientResponse
{
    public long UserId { get; set; }
    public string? Email { get; set; }
}
