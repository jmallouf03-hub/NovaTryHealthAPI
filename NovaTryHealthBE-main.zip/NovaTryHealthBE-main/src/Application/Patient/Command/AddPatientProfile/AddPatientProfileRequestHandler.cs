﻿using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using NovaHealth.Application.Common.FileStorage;
using NovaHealth.Application.Common.Interfaces;
using NovaHealth.Domain.Entities;
using Twilio.TwiML.Messaging;

namespace NovaHealth.Application.Patient.Command.AddPatientProfile;

public class AddPatientProfileRequestHandler : IRequestHandler<AddPatientProfileRequest, bool>
{
    private readonly INovaHealthDbContext _novaHealthDbContext;
    private readonly Func<FileStorageOption?, IFileStorageService> _fileStorageFunc;
    private readonly AppSettings _appSettings;
    private readonly IHttpContextAccessor _httpContextAccessor;
    private readonly ITimelineService _timelineService;

    public AddPatientProfileRequestHandler(
        Func<FileStorageOption?, IFileStorageService> fileStorageFunc,
        INovaHealthDbContext novaHealthDbContext,
        IOptions<AppSettings> appSettings, IHttpContextAccessor httpContextAccessor, ITimelineService timelineService)
    {
        _novaHealthDbContext = novaHealthDbContext;
        _fileStorageFunc = fileStorageFunc;
        _appSettings = appSettings.Value;
        _httpContextAccessor = httpContextAccessor;
        _timelineService = timelineService;
    }

    public async Task<bool> Handle(AddPatientProfileRequest request, CancellationToken cancellationToken)
    {
        var fileStorageService = _fileStorageFunc(_appSettings.DefaultFileStorage);

        // 1. Get the patient role
        var patientRole = await _novaHealthDbContext.Roles
                       .FirstOrDefaultAsync(r => r.RoleType == RoleType.Patient, cancellationToken);

        if (patientRole == null)
        {
            throw new Exception("Patient role does not exist in the system.");  
        }

        // 2. Try to find existing patient by UserId
        var user = await _novaHealthDbContext.Users
                       .Include(u => u.UserRoles)
                        .FirstOrDefaultAsync(x => x.Id == request.UserId && !x.IsDeleted && x.IsActive
                         && x.UserRoles.Any(ur => ur.RoleId == patientRole.Id), cancellationToken);

        if (user != null)
        {
            // === Update existing patient ===
            user.FirstName = request.FirstName;
            user.LastName = request.LastName;
            user.PhoneNumber = request.PhoneNumber;
            user.DateOfBirth = request.DateOfBirth;
            // user.Gender = request.Gender ?? 0;
            user.Gender = request.Gender ?? GenderTypeOption.NotSpecified;

            // Check email only if it's being changed
            if (!string.Equals(user.Email, request.Email, StringComparison.OrdinalIgnoreCase))
            {
                bool emailExists = await _novaHealthDbContext.Users
                    .AnyAsync(x => x.Email == request.Email && !x.IsDeleted && x.Id != user.Id, cancellationToken);

                if (emailExists)
                    throw new Exception("Email already exists.");

                user.Email = request.Email;
            }

            // Profile picture upload
            if (request.ProfilePictureName != null)
            {
                var fileUploadResponse = await fileStorageService.UploadAsync(new FileUploadRequest
                {
                    File = request.ProfilePictureName,
                    FileTypeOption = FileTypeOption.ProfilePicture,
                    UserId = user.Id,
                }, cancellationToken);

                user.ProfilePictureName = fileUploadResponse.OriginalName;
                user.ProfilePicturePath = fileUploadResponse.SavedTo;
            }
        }
        else
        {
            // === Create new patient ===
            if (await _novaHealthDbContext.Users.AnyAsync(x => x.Email == request.Email && !x.IsDeleted, cancellationToken))
            {
                throw new Exception("Email already exists.");
            }

            user = new User
            {
                FirstName = request.FirstName,
                LastName = request.LastName,
                Email = request.Email,
                IsActive = true,
                IsDeleted = false,
                CreatedDate = DateTime.UtcNow
            };

            await _novaHealthDbContext.Users.AddAsync(user, cancellationToken);
            await _novaHealthDbContext.SaveChangesAsync(cancellationToken);

            var newRole = new UserRole
            {
                UserId = user.Id,
                RoleId = patientRole.Id,
                IsActive = true,
                IsDeleted = false
            };

            await _novaHealthDbContext.UserRoles.AddAsync(newRole, cancellationToken);
        }

        await _novaHealthDbContext.SaveChangesAsync(cancellationToken);


        var ipAddress = _httpContextAccessor.HttpContext?.Connection?.RemoteIpAddress?.ToString();

        if (_httpContextAccessor.HttpContext?.Request.Headers.ContainsKey("X-Forwarded-For") == true)
        {
            ipAddress = _httpContextAccessor.HttpContext.Request.Headers["X-Forwarded-For"].FirstOrDefault();
        }

        await _timelineService.LogTimelineEventAsync(
              user.Id,
              TimelineEventType.Profile,
              user.Id > 0 ? "Patient Profile Updated" : "Patient Profile Created",
              $"Patient profile for {user.FirstName} {user.LastName} has been {(user.Id > 0 ? "updated" : "created")}.",
              new { ipAddress, userId = user.Id }
         );
        return true;
    }
}