﻿using MediatR;
using Microsoft.AspNetCore.Http;

namespace NovaHealth.Application.Patient.Command.AddPatientProfile;

public class AddPatientProfileRequest : IRequest<bool>
{
    public long? UserId { get; set; }
    public string FirstName { get; set; } = null!;

    public string? LastName { get; set; }

    public string Email { get; set; } = null!;
    
    public string? PhoneNumber { get; set; } 

    public DateTime? DateOfBirth { get; set; }

    public GenderTypeOption? Gender { get; set; }

    public IFormFile? ProfilePictureName { get; set; }
}

