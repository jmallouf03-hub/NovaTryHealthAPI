﻿using MediatR;
using Microsoft.EntityFrameworkCore;
using NovaHealth.Application.Common.Interfaces;
using NovaHealth.Application.Common.Exceptions;
using Microsoft.Extensions.Options;
using Microsoft.AspNetCore.Http;

namespace NovaHealth.Application.Identity.Commands.OTPVerification;

public record OTPVerificationRequest(long UserId, string Otp) : IRequest<OTPVerificationResponse>;

public class OTPVerificationResponse
{
    public long UserId { get; set; }
    public string Hash { get; set; } = null!;
    public string? Role { get; set; }
}

public class OTPVerificationRequestHandler : IRequestHandler<OTPVerificationRequest, OTPVerificationResponse>
{
    private readonly INovaHealthDbContext _novaHealthDbContext;
    private readonly AppSettings _appSettings;
    private readonly ITimelineService _timelineService;
    private readonly IHttpContextAccessor _httpContextAccessor;



    public OTPVerificationRequestHandler(INovaHealthDbContext novaHealthDbContext, IOptions<AppSettings> appSettings, ITimelineService timelineService, IHttpContextAccessor httpContextAccessor)
    {
        _novaHealthDbContext = novaHealthDbContext;
        _appSettings = appSettings.Value;
        _timelineService = timelineService;
        _httpContextAccessor = httpContextAccessor;
    }

    public async Task<OTPVerificationResponse> Handle(OTPVerificationRequest request, CancellationToken cancellationToken)
    {
        bool IsOtpBypassed = _appSettings.IsOtpBypassed;

        var otpRecord = await _novaHealthDbContext.OTPs
                       .OrderByDescending(o => o.Id)
                       .FirstOrDefaultAsync(o => o.UserId == request.UserId, cancellationToken);

        if (otpRecord == null)
        {
            throw new NotFoundException("Invalid OTP");
        }

        if (!IsOtpBypassed)
        {
            if (otpRecord.OtpCode != request.Otp)
            {
                throw new NotFoundException("Invalid OTP");
            }

            if (otpRecord.ExpiryDate < DateTime.Now)
            {
                throw new NotFoundException("OTP has expired.");
            }
        }

        // Fix the CS0103 error by correcting the Include statement
        var user = await _novaHealthDbContext.Users
                    .Include(u => u.UserRoles).ThenInclude(u => u.Role)
                    .FirstOrDefaultAsync(x => x.Id == request.UserId && !x.IsDeleted, cancellationToken);


        if (user == null)
        {
            throw new NotFoundException($"User not found with id {request.UserId}.");
        }

        var roleNames = user.UserRoles.Select(ur => ur.Role.Name).FirstOrDefault();

        user.IsEmailVerified = true;

        await _novaHealthDbContext.SaveChangesAsync(cancellationToken);

        var hash = SecurityHelper.Hash(request.UserId.ToString());


        var roleName = roleNames;

        var ipAddress = _httpContextAccessor.HttpContext?.Connection?.RemoteIpAddress?.ToString();

        if (_httpContextAccessor.HttpContext.Request.Headers.ContainsKey("X-Forwarded-For"))
        {
            ipAddress = _httpContextAccessor.HttpContext.Request.Headers["X-Forwarded-For"].FirstOrDefault();
        }
        await _timelineService.LogTimelineEventAsync(
                        user.Id,
                        TimelineEventType.Login,
                        $"{roleName} Logged In",
                         $"{roleName} logged in successfully",
                        new { ipAddress = ipAddress }
                        );

        return new OTPVerificationResponse { UserId = user.Id, Hash = hash, Role = roleNames ?? "Null" };
    }
}