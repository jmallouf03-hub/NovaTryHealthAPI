﻿namespace NovaHealth.Application.Identity.Command.GoogleSignIn;

public class GoogleSignInResponse
{
    public long UserId { get; set; }

    public string FirstName { get; set; } = null!;

    public string LastName { get; set; } = null!;

    public string? PhoneNumber { get; set; }

    public ProfileType AccountType { get; set; }

    public string? Email { get; set; }

    public string? Hash { get; set; }

    public CredentialStatusTypeOption CredentialStatus { get; set; }
}