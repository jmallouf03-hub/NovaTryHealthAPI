﻿using NovaHealth.Application.Common.Interfaces;
using NovaHealth.Application.Identity.Tokens.Services;
using MediatR;
using Microsoft.EntityFrameworkCore;

namespace NovaHealth.Application.Identity.Command.GoogleSignIn;
public record GoogleSignInRequest(string token) : IRequest<GoogleSignInResponse>;

public class GoogleSignInRequestHandler : IRequestHandler<GoogleSignInRequest, GoogleSignInResponse>
{
    private readonly INovaHealthDbContext _novaHealthDbContext;
    private readonly ITokenService _tokenService;

    public GoogleSignInRequestHandler(INovaHealthDbContext novaHealthDbContext, ITokenService tokenService)
    {
        _tokenService = tokenService;
        _novaHealthDbContext = novaHealthDbContext;
    }

    public async Task<GoogleSignInResponse> Handle(GoogleSignInRequest request, CancellationToken cancellationToken)
    {
        var googleUserInfo = await _tokenService.DecodeGoogleTokenAsync(request.token);

        if (googleUserInfo == null || string.IsNullOrWhiteSpace(googleUserInfo.Email))
        {
            throw new ArgumentException("Invalid token or email.");
        }

        string normalizedEmail = googleUserInfo.Email.ToLower(); // Normalize case
        string encryptedEmail = SecurityHelper.Encrypt(normalizedEmail);

        var user = await _novaHealthDbContext.Users
            .FirstOrDefaultAsync(u => u.Email == encryptedEmail, cancellationToken);

        if (user == null)
        {
            throw new KeyNotFoundException("User with the specified email does not exist.");
        }

        var hash = SecurityHelper.Hash(user.Id.ToString());

        //var credentialStatus = await _novaHealthDbContext.ProviderProfileDetails
        //    .FirstOrDefaultAsync(x => x.UserId == user.Id, cancellationToken);

        return new GoogleSignInResponse
        {
            //UserId = user.Id,
            //FirstName = user.FirstName,
            //LastName = user.LastName,
            //PhoneNumber = user.PhoneNumber,
            //AccountType = user.AccountType,
            //Hash = hash,
            //Email = normalizedEmail,
            //CredentialStatus = credentialStatus?.CredentialStatus ?? CredentialStatusTypeOption.ApprovalPending
        };
    }
}