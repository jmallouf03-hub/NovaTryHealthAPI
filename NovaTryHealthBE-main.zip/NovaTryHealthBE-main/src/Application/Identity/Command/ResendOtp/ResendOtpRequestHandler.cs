﻿using NovaHealth.Application.Common.Interfaces;
using NovaHealth.Application.Common.Mailing;
using NovaHealth.Domain.Entities;
using MediatR;
using Microsoft.EntityFrameworkCore;
using NovaHealth.Application.Common.Sms;
using Microsoft.AspNetCore.Http;

namespace NovaHealth.Application.Identity.Commands.ResendOtp;

public record ResendOtpResponse(bool IsValid, string Message);

public record ResendOtpRequest(long UserId) : IRequest<ResendOtpResponse>;

public class ResendOtpRequestHandler : IRequestHandler<ResendOtpRequest, ResendOtpResponse>
{
    private readonly INovaHealthDbContext _novaHealthDbContext;
    private readonly IMailService _mailService;
    private readonly IEmailTemplateService _emailTemplateService;
    private readonly ISmsService _smsService;
    private readonly ITimelineService _timelineService;
    private readonly IHttpContextAccessor _httpContextAccessor;

    public ResendOtpRequestHandler(INovaHealthDbContext novaHealthDbContext, IMailService mailService, IEmailTemplateService emailTemplateService, ISmsService smsService, ITimelineService timelineService, IHttpContextAccessor httpContextAccessor)
    {
        _novaHealthDbContext = novaHealthDbContext;
        _emailTemplateService = emailTemplateService;
        _mailService = mailService;
        _smsService = smsService;
        _timelineService = timelineService;
        _httpContextAccessor = httpContextAccessor;
    }

    public async Task<ResendOtpResponse> Handle(ResendOtpRequest request, CancellationToken cancellationToken)
    {
        // Retrieve user details
        var user = await _novaHealthDbContext.Users
            .FirstOrDefaultAsync(x => x.Id == request.UserId, cancellationToken);

        if (user == null)
        {
            return new ResendOtpResponse(false, "User not found.");
        }

        // string decryptedEmail = SecurityHelper.Decrypt(user.Email);

        var newOtp = CommonHelper.GenerateOTP();

        var newOtpRecord = new OTP
        {
            UserId = user.Id,
            OtpCode = newOtp,
            ExpiryDate = DateTime.Now.AddMinutes(5),
            CreatedDate = DateTime.Now
        };

        _novaHealthDbContext.OTPs.Add(newOtpRecord);
        await _novaHealthDbContext.SaveChangesAsync(cancellationToken);

        var logoPath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "images", "logo.png");
        byte[]? logoBytes = null;

        if (File.Exists(logoPath))
        {
            logoBytes = File.ReadAllBytes(logoPath);
        }

        //var notificationPreference = await _novaHealthDbContext.NotificationPreferences.FirstOrDefaultAsync(x => x.UserId == user.Id, cancellationToken);

        //if (notificationPreference != null)
        //{
        //    if (notificationPreference.Preference == NotificationPreferenceOption.Phone || notificationPreference.Preference == NotificationPreferenceOption.Both)
        //    {
        //        if (!string.IsNullOrEmpty(notificationPreference.PhoneNumber))
        //        {
        //            string message = $"Hi {user.FirstName},\n" +
        //                $"Your OTP code is {newOtp}. Use this to complete your login.\n" +
        //                "This OTP is valid for 5 minutes.\n" +
        //                "Chalice Health";

        //            var smsRequest = new SmsRequest
        //            {
        //                PhoneNumber = notificationPreference.PhoneNumber,
        //                Message = message
        //            };

        //            var smsResponse = await _smsService.SendAsync(smsRequest);
        //        }
        //    }
        //}


        var otpMailRequest = new MailRequest(new List<string> { user.Email },
                       "Your Nova Health OTP",
                       _emailTemplateService.GenerateEmailTemplate("sign-in-otp", new
                       {
                           FirstName = user.FirstName,
                           OtpCode = newOtp
                       }),
                       attachmentData: logoBytes != null ? new Dictionary<string, byte[]> { { "NovaHealthLogo", logoBytes } } : null);

        await _mailService.SendAsync(otpMailRequest, cancellationToken);


        var ipAddress = _httpContextAccessor.HttpContext?.Connection?.RemoteIpAddress?.ToString();

        if (_httpContextAccessor.HttpContext.Request.Headers.ContainsKey("X-Forwarded-For"))
        {
            ipAddress = _httpContextAccessor.HttpContext.Request.Headers["X-Forwarded-For"].FirstOrDefault();
        }
        await _timelineService.LogTimelineEventAsync(
                            user.Id,
                            TimelineEventType.OtpResend,   // 👈 You should define this enum value
                            "OTP Resent",
                            "A new OTP was generated and sent to the user.",
                            new { ipAddress = ipAddress }
                        );

        return new ResendOtpResponse(true, "New OTP generated and sent successfully.");
    }
}