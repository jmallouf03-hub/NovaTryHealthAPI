﻿using FluentValidation;
using NovaHealth.Application.Common.Validations;


namespace NovaHealth.Application.Identity.Command.ResetPassword;

public class ResetPasswordValidator : AbstractValidator<ResetPasswordRequest>
{
    public ResetPasswordValidator()
    {
        RuleFor(x => x.NewPassword).ValidatePassword();

        RuleFor(x => x.ConfirmPassword).Equal(x => x.NewPassword).WithMessage("Passwords do not match.");

        RuleFor(x => x.Hash).Cascade(CascadeMode.Stop).NotEmpty().WithMessage("Invalid password reset token");
    }
}