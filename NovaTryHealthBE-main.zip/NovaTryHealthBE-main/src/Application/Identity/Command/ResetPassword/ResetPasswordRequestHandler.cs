﻿using NovaHealth.Application.Common.Interfaces;
using NovaHealth.Application.Common.Mailing;
using NovaHealth.Domain.Entities;
using MediatR;
using Microsoft.EntityFrameworkCore;
using NovaHealth.Application.Common.Sms;
using Microsoft.AspNetCore.Http;

namespace NovaHealth.Application.Identity.Command.ResetPassword;

public record ResetPasswordRequest(string NewPassword, string ConfirmPassword, string Hash) : IRequest<bool>;

public class ResetPasswordRequestHandler : IRequestHandler<ResetPasswordRequest, bool>
{
    private readonly INovaHealthDbContext _novaHealthDbContext;
    private readonly IEmailTemplateService _emailTemplateService;
    private readonly IMailService _mailService;
    private readonly IIdentityService _identityService;
    private readonly ISmsService _smsService;
    private readonly ITimelineService _timelineService;
    private readonly IHttpContextAccessor _httpContextAccessor;
    public ResetPasswordRequestHandler(INovaHealthDbContext novaHealthDbContext, IEmailTemplateService emailTemplateService, IMailService mailService, IIdentityService identityService, ISmsService smsService, ITimelineService timelineService, IHttpContextAccessor httpContextAccessor)
    {
        _novaHealthDbContext = novaHealthDbContext;
        _emailTemplateService = emailTemplateService;
        _mailService = mailService;
        _identityService = identityService;
        _smsService = smsService;
        _timelineService = timelineService;
        _httpContextAccessor = httpContextAccessor;
    }

    public async Task<bool> Handle(ResetPasswordRequest request, CancellationToken cancellationToken)
    {
        if (request.NewPassword != request.ConfirmPassword)
        {
            throw new InvalidOperationException("New password and confirm password do not match.");
        }

        var user = await _identityService.CheckUser(request.Hash);

        if (user == null)
        {
            throw new Exception("User not found.");
        }

        string decryptedEmail = SecurityHelper.Decrypt(user.Email);

        var hashedNewPassword = SecurityHelper.HashPassword(request.NewPassword);

        var passwordHistory = await _novaHealthDbContext.PasswordHistories
            .Where(ph => ph.UserId == user.Id)
            .OrderByDescending(ph => ph.LastPasswordCreatedDate)
            .Take(3)
            .ToListAsync();

        if (user.Password == hashedNewPassword)
        {
            throw new InvalidOperationException("New password cannot be the same as your current password. Please enter a new password.");
        }

        if (passwordHistory.Any(ph => ph.HashedPassword == hashedNewPassword))
        {
            throw new Exception("New password cannot be the same as the last 3 passwords.");
        }

        user.Password = hashedNewPassword;
        user.CreatedDate = DateTime.UtcNow;

        var newPasswordHistory = new PasswordHistory
        {
            UserId = user.Id,
            HashedPassword = hashedNewPassword,
            LastPasswordCreatedDate = user.CreatedDate,
            CreatedDate = user.CreatedDate,
            IsActive = true,
        };

        _novaHealthDbContext.PasswordHistories.Add(newPasswordHistory);
        await _novaHealthDbContext.SaveChangesAsync(cancellationToken);

        var oldPasswords = await _novaHealthDbContext.PasswordHistories
                .Where(ph => ph.UserId == user.Id)
                .OrderByDescending(ph => ph.LastPasswordCreatedDate)
                .Skip(3)
                .ToListAsync();

        if (oldPasswords.Any())
        {
            _novaHealthDbContext.PasswordHistories.RemoveRange(oldPasswords);
        }

        await _novaHealthDbContext.SaveChangesAsync(cancellationToken);

        var logoPath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "images", "logo.png");

        byte[]? logoBytes = null;

        if (File.Exists(logoPath))
        {
            logoBytes = File.ReadAllBytes(logoPath);
        }

        //var notificationPreference = await _novaHealthDbContext.NotificationPreferences.FirstOrDefaultAsync(x => x.UserId == user.Id, cancellationToken);

        //if (notificationPreference != null)
        //{
        //    if (notificationPreference.Preference == NotificationPreferenceOption.Phone || notificationPreference.Preference == NotificationPreferenceOption.Both)
        //    {
        //        if (!string.IsNullOrEmpty(notificationPreference.PhoneNumber))
        //        {
        //            string message = $"Hi {user.FirstName},\n" +
        //                    $"This is to confirm that the password for your account has been successfully reset.\n" +
        //                    $"Chalice Health";

        //            var smsRequest = new SmsRequest
        //            {
        //                PhoneNumber = notificationPreference.PhoneNumber,
        //                Message = message
        //            };

        //            var smsResponse = await _smsService.SendAsync(smsRequest);
        //        }
        //    }
        //}

        //if (notificationPreference == null || notificationPreference.Preference == NotificationPreferenceOption.Email || notificationPreference.Preference == NotificationPreferenceOption.Both)
        //{
        //    var mailRequest = new MailRequest(
        //    new List<string> { decryptedEmail }, "Your Account Password Has Been Reset", _emailTemplateService.GenerateEmailTemplate("password-reset", new
        //    {
        //        FirstName = user.FirstName
        //    }),
        //    attachmentData: logoBytes != null ? new Dictionary<string, byte[]>
        //    { { "ChaliceHealthLogo", logoBytes } } : null);

        //    await _mailService.SendAsync(mailRequest, cancellationToken);
        //}



        var ipAddress = _httpContextAccessor.HttpContext?.Connection?.RemoteIpAddress?.ToString();

        if (_httpContextAccessor.HttpContext.Request.Headers.ContainsKey("X-Forwarded-For"))
        {
            ipAddress = _httpContextAccessor.HttpContext.Request.Headers["X-Forwarded-For"].FirstOrDefault();
        }
        await _timelineService.LogTimelineEventAsync(
                          user.Id,
                          TimelineEventType.PasswordReset,   // 👈 use the proper event type
                          "Password Reset",
                          "User has successfully reset their password.",
                          new { ipAddress = ipAddress }
                      );
        return true;
    }
}