﻿using NovaHealth.Application.Common.Interfaces;
using NovaHealth.Domain.Entities;

namespace NovaHealth.Application.Identity;

public interface IIdentityService : ITransientService
{
    Task<string> GetUserEmailAsync(long userId);

    Task<User> CheckUser(string hashValue);

    Task<User> ValidatePassword(long userId, string oldPassword);

    Task<User> CheckUserIsValid(string email, string userPassword);
}