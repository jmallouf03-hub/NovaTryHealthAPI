﻿namespace NovaHealth.Application.Identity;

public interface IOtpService
{
    Task StoreOtpAsync(long userId, string otp);
    Task<bool> ValidateOtpAsync(long userId, string otp);
}
