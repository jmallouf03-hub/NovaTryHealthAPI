﻿namespace NovaHealth.Application.Identity;

public class OtpService : IOtpService
{
    private readonly Dictionary<long, (string Otp, DateTime Expiry)> _otpStore = new();

    public Task StoreOtpAsync(long userId, string otp)
    {
        _otpStore[userId] = (otp, DateTime.Now.AddMinutes(5)); // Store OTP with expiry time
        Console.WriteLine($"Stored OTP for user {userId}: OTP={otp}, Expiry={_otpStore[userId].Expiry}");
        return Task.CompletedTask;
    }

    public Task<bool> ValidateOtpAsync(long userId, string otp)
    {
        if (_otpStore.TryGetValue(userId, out var storedOtp))
        {
            var isValid = storedOtp.Otp == otp && storedOtp.Expiry > DateTime.UtcNow;
            return Task.FromResult(isValid);
        }
        return Task.FromResult(false);
    }
}
