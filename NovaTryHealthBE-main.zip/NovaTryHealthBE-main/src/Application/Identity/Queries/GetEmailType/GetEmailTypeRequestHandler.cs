﻿using NovaHealth.Application.Common.Interfaces;
using MediatR;
using Microsoft.EntityFrameworkCore;

namespace NovaHealth.Application.Identity.Queries.GetEmailType;

public record GetEmailTypeRequest(string Email) : IRequest<bool>;

public class GetEmailTypeRequestHandler : IRequestHandler<GetEmailTypeRequest, bool>
{
    private readonly INovaHealthDbContext _novaHealthDbContext;

    public GetEmailTypeRequestHandler(INovaHealthDbContext novaHealthDbContext)
    {
        _novaHealthDbContext = novaHealthDbContext;
    }

    public async Task<bool> Handle(GetEmailTypeRequest request, CancellationToken cancellationToken)
    {
        string normalizedEmail = request.Email.ToLower(); // Normalize case
        string encryptedEmail = SecurityHelper.Encrypt(normalizedEmail);

        var emailCount = await _novaHealthDbContext.Users
                           .Where(x => x.Email == encryptedEmail)
                           .CountAsync(cancellationToken);

        return emailCount > 1;
    }
}
