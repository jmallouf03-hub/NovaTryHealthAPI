﻿using FluentValidation;

namespace NovaHealth.Application.Identity.Queries.GetIdentity;

public class GetIdentityValidator : AbstractValidator<GetIdentityRequest>
{
    public GetIdentityValidator()
    {
        RuleFor(p => p.Email)
            .Cascade(CascadeMode.Stop)
            .NotEmpty()
            .EmailAddress()
            .WithMessage("Invalid Email Address.");

        RuleFor(p => p.Password).Cascade(CascadeMode.Stop).NotEmpty().WithMessage("Password required");
    }
}