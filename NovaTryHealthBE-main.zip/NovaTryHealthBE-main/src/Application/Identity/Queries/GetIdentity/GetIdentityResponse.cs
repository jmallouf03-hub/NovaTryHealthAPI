﻿namespace NovaHealth.Application.Identity.Queries.GetIdentity;

public record GetIdentityResponse
{
    public long UserId { get; set; }

    //public string FirstName { get; set; } = null!;    

    //public string LastName { get; set; } = null!;

    //public string? PhoneNumber { get; set; }

    //public ProfileType AccountType { get; set; }

    public string? Email { get; set; }

    public string? Hash { get; set; }

    //public CredentialStatusTypeOption CredentialStatus { get; set; }

    //public AdminUserTypeOption? Type { get; set; }

    //public List<string>? Roles { get; set; }

    //public List<long>? PermissionIds { get; set; }

    //public AdminUserTypeOption? ClinicType { get; set; }

    //public string? ErrorMessage { get; set; }
}