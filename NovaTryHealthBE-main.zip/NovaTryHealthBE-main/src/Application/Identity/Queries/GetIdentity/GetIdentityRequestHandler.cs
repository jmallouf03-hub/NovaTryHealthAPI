﻿using NovaHealth.Application.Common.Interfaces;
using NovaHealth.Application.Common.Mailing;
using NovaHealth.Domain.Entities;
using MediatR;
using NovaHealth.Application.Common.Sms;
using Microsoft.AspNetCore.Http;

namespace NovaHealth.Application.Identity.Queries.GetIdentity;
public record GetIdentityRequest(string Email, string Password) : IRequest<GetIdentityResponse>;
public class GetIdentityRequestHandler : IRequestHandler<GetIdentityRequest, GetIdentityResponse>
{
    private readonly INovaHealthDbContext _novaHealthDbContext;
    private readonly IIdentityService _identityService;
    private readonly IEmailTemplateService _emailTemplateService;
    private readonly IMailService _mailService;
    private readonly ISmsService _smsService;
    private readonly ITimelineService _timelineService;
    private readonly IHttpContextAccessor _httpContextAccessor;


    public GetIdentityRequestHandler(INovaHealthDbContext novaHealthDbContext,
        IIdentityService identityService, IMailService mailService,
        IEmailTemplateService emailTemplateService, ISmsService smsService,
        ITimelineService timelineService, IHttpContextAccessor httpContextAccessor)
    {
        _novaHealthDbContext = novaHealthDbContext;
        _identityService = identityService;
        _emailTemplateService = emailTemplateService;
        _mailService = mailService;
        _smsService = smsService;
        _timelineService = timelineService;
        _httpContextAccessor = httpContextAccessor;
    }

    public async Task<GetIdentityResponse> Handle(GetIdentityRequest request, CancellationToken cancellationToken)
    {



        string normalizedEmail = request.Email.ToLower(); // Normalize case

        var user = await _identityService.CheckUserIsValid(normalizedEmail, request.Password);

        if (!user.IsDisabledByAdmin)
        {
            throw new Exception("This user has been disabled by the admin.");
        }

        if (!user.IsActive)
        {
            throw new UnauthorizedAccessException("Your account is inactive. You cannot log in.");
        }


        //if (user.CreatedDate.AddMonths(3) <= DateTime.UtcNow)
        //{
        //    var errorMessage = ("Your password has expired. Please reset your password.");

        //    return new GetIdentityResponse
        //    {
        //        ErrorMessage = errorMessage,
        //        Hash = encodedHash
        //    };
        //}

        //var existingOtp = await _novaHealthDbContext.OTPs.FirstOrDefaultAsync(o => o.UserId == user.Id, cancellationToken);

        string otp = CommonHelper.GenerateOTP();

        var otpStore = new OTP
        {
            UserId = user.Id,
            OtpCode = otp,
            ExpiryDate = DateTime.Now.AddMinutes(5),
            CreatedDate = DateTime.Now,
        };

        _novaHealthDbContext.OTPs.Add(otpStore);
        await _novaHealthDbContext.SaveChangesAsync(cancellationToken);

        var logoPath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "Image", "logo.png");
        byte[]? logoBytes = null;

        if (File.Exists(logoPath))
        {
            logoBytes = File.ReadAllBytes(logoPath);
        }

        string loginEmailNormalized = normalizedEmail.Trim().ToLower();

        var inlineAttachments = logoBytes != null
            ? new Dictionary<string, byte[]> { { "NovaHealthLogo", logoBytes } }
            : null;

        string emailBody = _emailTemplateService.GenerateEmailTemplate("sign-in-otp", new
        {
            FirstName = user.FirstName,
            OtpCode = otp,
            LogoCid = "cid:NovaHealthLogo"
        });

        var otpMailRequest = new MailRequest(
            to: new List<string> { user.Email },
            subject: "OTP for Your Account",
            body: emailBody,
            inlineAttachments: inlineAttachments,
            isHtmlBody: true
        );

        await _mailService.SendAsync(otpMailRequest, cancellationToken);

        var ipAddress = _httpContextAccessor.HttpContext?.Connection?.RemoteIpAddress?.ToString();

        if (_httpContextAccessor.HttpContext.Request.Headers.ContainsKey("X-Forwarded-For"))
        {
            ipAddress = _httpContextAccessor.HttpContext.Request.Headers["X-Forwarded-For"].FirstOrDefault();
        }

        await _timelineService.LogTimelineEventAsync(
                      user.Id,
                      TimelineEventType.OTP,
                      "OTP Sent",
                      "OTP has been sent to the user for login verification.",
                      new { ipAddress }
                      );

        return new GetIdentityResponse
        {
            UserId = user.Id,
            //FirstName = user.FirstName,
            //LastName = user.LastName,
            Email = normalizedEmail,
            //PhoneNumber = user.PhoneNumber,
            //AccountType = user.AccountType,
            //Type = adminUserType,
            Hash = SecurityHelper.Hash(user.Id.ToString()),
            //CredentialStatus = credentialStatus?.CredentialStatus ?? CredentialStatusTypeOption.ApprovalPending,
            //Roles = roleNames,
            //PermissionIds = rolePermissions,
            //ClinicType = clinicType
        };
    }
}