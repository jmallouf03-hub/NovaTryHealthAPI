﻿using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using NovaHealth.Application.Common.Exceptions;
using NovaHealth.Application.Common.Interfaces;
using NovaHealth.Domain.Entities;

namespace NovaHealth.Application.Identity;

public class IdentityService : IIdentityService
{
    private readonly INovaHealthDbContext _novaHealthDbContext;

    public IdentityService(INovaHealthDbContext novaHealthDbContext)
    {
        _novaHealthDbContext = novaHealthDbContext;
    }

    public Task<string> GetUserEmailAsync(long userId)
    {
        var user = _novaHealthDbContext.Users.FirstOrDefault(u => u.Id == userId);

        return Task.FromResult(user?.Email ?? $"Unknown User {userId}");
    }

    public async Task<User> CheckUser(string hashValue)
    {
        var hash = Base64UrlEncoder.Decode(hashValue);
        var decoded = SecurityHelper.Decrypt(hash);
        var separatedParams = decoded.Split(new[] { "$$$" }, StringSplitOptions.None);
        var unHashedEmail = separatedParams[0];

        string normalizedEmail = unHashedEmail.ToLower(); // Normalize case
       // string encryptedEmail = SecurityHelper.Encrypt(normalizedEmail);

        var user = await _novaHealthDbContext.Users
                 .FirstOrDefaultAsync(x => x.Email == normalizedEmail);

        if (user is null)
        {
            throw new BadException("Cannot find this user.");
        }

        return user;
    }


    public async Task<User> ValidatePassword(long userId, string oldPassword)
    {
        var user = await _novaHealthDbContext.Users
            .FirstOrDefaultAsync(x => x.Id == userId);
        if (user is null)
        {
            throw new BadException("Cannot find this user");
        }

        var hashedInputPassword = SecurityHelper.HashPassword(oldPassword);

        if (hashedInputPassword != user.Password)
        {
            throw new NotFoundException("Invalid User old password.");
        }

        return user;
    }

    public async Task<User> CheckUserIsValid(string email, string userPassword)
    {
        string normalizedEmail = email.ToLower(); // Normalize case
       // string encryptedEmail = SecurityHelper.Encrypt(normalizedEmail);

        var users = await _novaHealthDbContext.Users
            .Where(x => x.Email == normalizedEmail && !x.IsDeleted)
            .ToListAsync();

        if (!users.Any())
        {
            throw new NotFoundException("User not found.");
        }

        foreach (var user in users)
        {
            var hashedInputPassword = SecurityHelper.HashPassword(userPassword);
            if (hashedInputPassword == user.Password)
            {
                return user;
            }
        }

        throw new NotFoundException("Invalid User password.");
    }
}