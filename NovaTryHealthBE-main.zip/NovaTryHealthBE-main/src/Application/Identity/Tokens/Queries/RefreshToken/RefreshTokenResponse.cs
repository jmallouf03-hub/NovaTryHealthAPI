﻿namespace NovaHealth.Application.Identity.Tokens.Queries.RefreshToken;

public record RefreshTokenResponse(string Token, string RefreshToken, DateTime RefreshTokenExpiryTime);