﻿using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using NovaHealth.Application.Auth.Jwt;
using NovaHealth.Application.Common.Exceptions;
using NovaHealth.Application.Common.Interfaces;
using NovaHealth.Application.Identity.Tokens.Services;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace NovaHealth.Application.Identity.Tokens.Queries.RefreshToken;

public record RefreshTokenRequest(string Token) : IRequest<RefreshTokenResponse>;

public class RefreshTokenRequestHandler : IRequestHandler<RefreshTokenRequest, RefreshTokenResponse>
{
    private readonly ITokenService _tokenService;
    private readonly INovaHealthDbContext _novaHealthDbContext;
    private readonly IHttpContextAccessor _httpContextAccessor;
    private readonly JwtSettings _jwtSettings;

    public RefreshTokenRequestHandler(ITokenService tokenService, INovaHealthDbContext novaHealthDbContext, IHttpContextAccessor httpContextAccessor, IOptions<JwtSettings> jwtSettings)
    {
        _tokenService = tokenService;
        _novaHealthDbContext = novaHealthDbContext;
        _httpContextAccessor = httpContextAccessor;
        _jwtSettings = jwtSettings.Value;
    }

    public async Task<RefreshTokenResponse> Handle(RefreshTokenRequest request, CancellationToken cancellationToken)
    {
        var userPrincipal = GetPrincipalFromExpiredToken(request.Token);
        var userEmail = userPrincipal.FindFirstValue(ClaimTypes.Email);

        var user = await _novaHealthDbContext.Users.FirstOrDefaultAsync(x => x.Email == userEmail, cancellationToken);

        if (user is null)
        {
            throw new UnauthorizedException("Authentication Failed.");
        }

        var tokenResponse = _tokenService.GenerateToken(_httpContextAccessor.GetIpAddress(), user);

        return new RefreshTokenResponse(tokenResponse.Token, tokenResponse.RefreshToken, tokenResponse.RefreshTokenExpiryTime);
    }

    private ClaimsPrincipal GetPrincipalFromExpiredToken(string token)
    {
        var tokenValidationParameters = new TokenValidationParameters
        {
            ValidateIssuerSigningKey = true,
            IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_jwtSettings.Key)),
            ValidateIssuer = false,
            ValidateAudience = false,
            RoleClaimType = ClaimTypes.Role,
            ClockSkew = TimeSpan.Zero,
            ValidateLifetime = false
        };

        var tokenHandler = new JwtSecurityTokenHandler();
        var principal = tokenHandler.ValidateToken(token, tokenValidationParameters, out var securityToken);
        if (securityToken is not JwtSecurityToken jwtSecurityToken ||
            !jwtSecurityToken.Header.Alg.Equals(
                SecurityAlgorithms.HmacSha256,
                StringComparison.InvariantCultureIgnoreCase))
        {
            throw new UnauthorizedException("Invalid Token.");
        }

        return principal;
    }
}