﻿using FluentValidation;

namespace NovaHealth.Application.Identity.Tokens.Queries.RefreshToken;

public class RefreshTokenRequestValidator : AbstractValidator<RefreshTokenRequest>
{
    public RefreshTokenRequestValidator()
    {
        RuleFor(p => p.Token)
            .Cascade(CascadeMode.Stop)
            .NotEmpty()
            .WithMessage("Token is required");
    }
}