﻿namespace NovaHealth.Application.Identity.Tokens.Queries.GetToken;

public record GetTokenResponse
{
    public string Token { get; set; } = null!;

    public string RefreshToken { get; set; } = null!;

    public DateTime RefreshTokenExpiryTime { get; set; }
}