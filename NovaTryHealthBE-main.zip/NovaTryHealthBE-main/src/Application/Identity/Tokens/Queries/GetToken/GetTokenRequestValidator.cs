﻿using FluentValidation;

namespace NovaHealth.Application.Identity.Tokens.Queries.GetToken;

public class GetTokenRequestValidator : AbstractValidator<GetTokenRequest>
{
    public GetTokenRequestValidator()
    {
        RuleFor(p => p.UserId).NotEmpty().GreaterThan(0);
        RuleFor(p => p.Hash).NotEmpty();
    }
}