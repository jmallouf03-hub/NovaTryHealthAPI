﻿using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using NovaHealth.Application.Common.Exceptions;
using NovaHealth.Application.Common.Interfaces;
using NovaHealth.Application.Identity.Tokens.Services;

namespace NovaHealth.Application.Identity.Tokens.Queries.GetToken;
public record GetTokenRequest(long UserId, string Hash) : IRequest<GetTokenResponse>;
public class GetTokenRequestHandler : IRequestHandler<GetTokenRequest, GetTokenResponse>
{
    private readonly ITokenService _tokenService;
    private readonly INovaHealthDbContext _novaHealthDbContext;
    private readonly IHttpContextAccessor _httpContextAccessor;
    private readonly IMediator _mediator;
    public GetTokenRequestHandler(ITokenService tokenService, INovaHealthDbContext novaHealthDbContext, IHttpContextAccessor httpContextAccessor, IMediator mediator)
    {
        _tokenService = tokenService;
        _novaHealthDbContext = novaHealthDbContext;
        _httpContextAccessor = httpContextAccessor;
        _mediator = mediator;
    }
    public async Task<GetTokenResponse> Handle(GetTokenRequest request, CancellationToken cancellationToken)
    {
        if (SecurityHelper.Hash($"{request.UserId}") != request.Hash)
        {
            throw new BadException("Wrong user on verification");
        }

        var user = await _novaHealthDbContext.Users
            .FirstOrDefaultAsync(x => x.Id == request.UserId, cancellationToken);

        if (user is null)
        {
            throw new NotFoundException("Cannot find this user");
        }

        var tokenResponse = _tokenService.GenerateToken(_httpContextAccessor.GetIpAddress(), user);

        return new GetTokenResponse
        {
            Token = tokenResponse.Token,
            RefreshToken = tokenResponse.RefreshToken,
            RefreshTokenExpiryTime = tokenResponse.RefreshTokenExpiryTime,
        };
    }
}