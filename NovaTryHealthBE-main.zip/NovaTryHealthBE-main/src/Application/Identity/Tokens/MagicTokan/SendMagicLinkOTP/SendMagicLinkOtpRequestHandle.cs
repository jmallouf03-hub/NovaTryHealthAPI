﻿using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using NovaHealth.Application.Common.Interfaces;
using NovaHealth.Application.Common.Mailing;
using NovaHealth.Application.Common.Sms;
using NovaHealth.Domain.Entities;

namespace NovaHealth.Application.Identity.Tokens.MagicTokan.SendMagicLinkOTP;
public record SendMagicLinkOtpResponse(long UserId, string Email);
public record SendMagicLinkOtpRequest(string Hash) : IRequest<SendMagicLinkOtpResponse>;

public class SendMagicLinkOtpRequestHandle : IRequestHandler<SendMagicLinkOtpRequest, SendMagicLinkOtpResponse>
{
    private readonly INovaHealthDbContext _novaHealthDbContext;
    private readonly IIdentityService _identityService;
    private readonly IEmailTemplateService _emailTemplateService;
    private readonly IMailService _mailService;
    private readonly ISmsService _smsService;
    public SendMagicLinkOtpRequestHandle(INovaHealthDbContext novaHealthDbContext, IIdentityService identityService, IMailService mailService, IEmailTemplateService emailTemplateService, ISmsService smsService)
    {
        _novaHealthDbContext = novaHealthDbContext;
        _identityService = identityService;
        _emailTemplateService = emailTemplateService;
        _mailService = mailService;
        _smsService = smsService;
    }
    public async Task<SendMagicLinkOtpResponse> Handle(SendMagicLinkOtpRequest request, CancellationToken cancellationToken)
    {
        var user = await _identityService.CheckUser(request.Hash);
        var hash = Base64UrlEncoder.Decode(request.Hash);
        var decoded = SecurityHelper.Decrypt(hash);
        var separatedParams = decoded.Split(new[] { "$$$" }, StringSplitOptions.None);

        // Check for valid token format
        if (separatedParams.Length < 4)
            throw new Exception("Invalid token");

        var actionType = separatedParams[2];
        var token = separatedParams[3];

        // Check if user already has a password
        if (actionType != "login")
            throw new Exception("Invalid token");


        if (!Guid.TryParse(token, out var tokenGuid))
            throw new Exception("Invalid token format.");

        var tokenEntry = await _novaHealthDbContext.MagicTokens
            .FirstOrDefaultAsync(x => x.Token == tokenGuid && x.UserId == user.Id, cancellationToken);

        if (tokenEntry == null)
            throw new Exception("Invalid or expired token.");

        if (tokenEntry.IsUsed)
            throw new Exception("Token already used.");

        if (tokenEntry.Expiry < DateTime.UtcNow)
            throw new Exception("Token has expired. Please request a new one.");


        string otp = CommonHelper.GenerateOTP();

        var otpStore = new OTP
        {
            UserId = user.Id,
            OtpCode = otp,
            ExpiryDate = DateTime.Now.AddMinutes(5),
            CreatedDate = DateTime.Now,
        };
        tokenEntry.IsUsed = true;
        tokenEntry.IsActive = false;

        _novaHealthDbContext.OTPs.Add(otpStore);
        await _novaHealthDbContext.SaveChangesAsync(cancellationToken);

        var logoPath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "images", "logo.png");
        byte[]? logoBytes = null;

        if (File.Exists(logoPath))
        {
            logoBytes = File.ReadAllBytes(logoPath);
        }

        string loginEmailNormalized = user.Email.Trim().ToLower();

        var inlineAttachments = logoBytes != null
            ? new Dictionary<string, byte[]> { { "NovaHealthLogo", logoBytes } }
            : null;

        string emailBody = _emailTemplateService.GenerateEmailTemplate("sign-in-otp", new
        {
            FirstName = user.FirstName,
            OtpCode = otp,
            LogoCid = "cid:NovaHealthLogo"
        });

        var otpMailRequest = new MailRequest(
            to: new List<string> { user.Email },
            subject: "OTP for Your Account",
            body: emailBody,
            inlineAttachments: inlineAttachments,
            isHtmlBody: true
        );

        await _mailService.SendAsync(otpMailRequest, cancellationToken);

        return new SendMagicLinkOtpResponse(
            UserId: user.Id,
            Email: user.Email
        );
 
    }
}