﻿using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using NovaHealth.Application.Auth.Jwt;
using NovaHealth.Application.Common.Exceptions;
using NovaHealth.Application.Common.Interfaces;
using NovaHealth.Application.Identity.Tokens.Services;
using NovaHealth.Domain.Entities;
using NovaHealth.Shared.Authorization;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;


namespace NovaHealth.Application.Identity.Tokens.MagicTokan.GenerateMagicLinkToken;

public record GenerateMagicLinkTokenRequest(long UserId, string Hash) : IRequest<TokenResponse>;

public class GenerateMagicLinkTokenHandler : IRequestHandler<GenerateMagicLinkTokenRequest, TokenResponse>
{
    private readonly ITokenService _tokenService;
    private readonly INovaHealthDbContext _novaHealthDbContext;
    private readonly JwtSettings _jwtSettings;
    private readonly IHttpContextAccessor _httpContextAccessor;


    public GenerateMagicLinkTokenHandler(ITokenService tokenService, INovaHealthDbContext novaHealthDbContext, IOptions<JwtSettings> jwtSettings, IHttpContextAccessor httpContextAccessor)
    {
        _tokenService = tokenService;
        _novaHealthDbContext = novaHealthDbContext;
        _jwtSettings = jwtSettings.Value;
        _httpContextAccessor = httpContextAccessor;
    }

    public async Task<TokenResponse> Handle(GenerateMagicLinkTokenRequest request, CancellationToken cancellationToken)
    {

        if (SecurityHelper.Hash($"{request.UserId}") != request.Hash)
        {
            throw new BadException("Wrong user on verification");
        }

        var user = await _novaHealthDbContext.Users
            .FirstOrDefaultAsync(x => x.Id == request.UserId, cancellationToken);

        if (user is null)
        {
            throw new NotFoundException("Cannot find this user");
        }

        var magicLinkToken = GenerateMagicLinkToken(_httpContextAccessor.GetIpAddress(), user);

        return new TokenResponse(
        Token: magicLinkToken,
        RefreshToken: "",
        RefreshTokenExpiryTime: DateTime.MinValue // No refresh token needed for magic link login
        );
    }

    private string GenerateMagicLinkToken(string ipAddress, User user)
    {
        var claims = new List<Claim>
        {
            new(ClaimTypes.NameIdentifier, user.Id.ToString()),
            new(ClaimTypes.Email, user.Email!),
             new(NovaHealthClaims.IpAddress, ipAddress),
        };
        var secret = Encoding.UTF8.GetBytes(_jwtSettings.Key);
        var signingCredentials = new SigningCredentials(new SymmetricSecurityKey(secret), SecurityAlgorithms.HmacSha256);

        var token = new JwtSecurityToken(
            claims: claims,
            expires: DateTime.UtcNow.AddMinutes(15),
            signingCredentials: signingCredentials
        );

        return new JwtSecurityTokenHandler().WriteToken(token);

    }
}
