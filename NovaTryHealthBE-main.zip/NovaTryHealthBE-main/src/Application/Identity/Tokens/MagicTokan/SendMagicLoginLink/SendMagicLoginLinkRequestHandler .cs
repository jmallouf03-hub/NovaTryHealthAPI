﻿using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using NovaHealth.Application.Auth.Jwt;
using NovaHealth.Application.Common.Interfaces;
using NovaHealth.Application.Common.Mailing;
using NovaHealth.Application.Identity.Tokens.Services;
using NovaHealth.Domain.Entities;
using System.Text;


namespace NovaHealth.Application.Identity.Tokens.MagicTokan.SendMagicLoginLink;
public record SendMagicLoginLinkRequest(string Email) : IRequest<bool>;
public class SendMagicLoginLinkRequestHandler : IRequestHandler<SendMagicLoginLinkRequest, bool>
{
    private readonly INovaHealthDbContext _novaHealthDbContext;
    private readonly ITokenService _tokenService;
    private readonly IMailService _mailService;
    private readonly JwtSettings _jwtSettings;
    private readonly AppSettings _appSettings;

    public SendMagicLoginLinkRequestHandler(INovaHealthDbContext novaHealthDbContext, ITokenService tokenService, IMailService mailService, IOptions<JwtSettings> jwtSettings, IOptions<AppSettings> appSettings)
    {
        _novaHealthDbContext = novaHealthDbContext;
        _tokenService = tokenService;
        _mailService = mailService;
        _jwtSettings = jwtSettings.Value;
        _appSettings = appSettings.Value;
    }

    public async Task<bool> Handle(SendMagicLoginLinkRequest request, CancellationToken cancellationToken)
    {
        //string? decryptedEmail = !string.IsNullOrEmpty(notificationPreference?.Email)
        //            ? SecurityHelper.Decrypt(notificationPreference.Email)
        //            : null;

        //string decryptedEmailNormalized = decryptedEmail?.Trim().ToLower();
        //string loginEmailNormalized = normalizedEmail.Trim().ToLower();

        var user = await _novaHealthDbContext.Users
            .FirstOrDefaultAsync(u => u.Email.ToLower() == request.Email.ToLower(), cancellationToken);

        if (user == null || !user.IsActive)
            throw new Exception("Invalid UserId");

        if (string.IsNullOrWhiteSpace(user.Password))
            throw new Exception("Password is not set. Please create a password first.");

        if (!user.IsActive)
            throw new Exception("Your account is inactive.");

        var magicToken = new MagicToken
        {
            UserId = user.Id,
            Email = user.Email,
            Expiry = DateTime.UtcNow.AddMinutes(15),
            IsUsed = false,
            CreatedDate = DateTime.UtcNow
        };
        _novaHealthDbContext.MagicTokens.Add(magicToken);
        await _novaHealthDbContext.SaveChangesAsync(cancellationToken);

        string data = $"{user.Email}$$${user.Id}$$${"login"}$$${magicToken.Token}";
        string encryptedData = SecurityHelper.Encrypt(data);
        string hash = Base64UrlEncoder.Encode(Encoding.UTF8.GetBytes(encryptedData));
        string magicLink = $"{_appSettings.NovaHealthUrl}/otp?token={hash}";

        var emailBody = $"Hi {user.FirstName},<br/><br/>" +
                        $"Click <a href='{magicLink}'>here</a> to login. This link will expire in 15 minutes.<br/><br/>" +
                        $"Nova Health Team";

        var mailRequest = new MailRequest(
            new List<string> { user.Email },
            "Your Magic Login Link",
            emailBody
        );

        await _mailService.SendAsync(mailRequest, cancellationToken);

        return true;
    }

}

