﻿using NovaHealth.Application.Common.Interfaces;
using NovaHealth.Domain.Common;
using NovaHealth.Domain.Entities;
using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;

namespace NovaHealth.Application.Identity.Tokens.EventHandlers;

public class LoginSuccessEvent : BaseEvent
{
    public LoginSuccessEvent(User user)
    {
        User = user;
    }

    public User User { get; set; }
}

public class LoginSuccessEventHandler : INotificationHandler<LoginSuccessEvent>
{
    private readonly ILogger<LoginSuccessEventHandler> _logger;
    private readonly INovaHealthDbContext _novaHealthDbContext;
    private readonly IHttpContextAccessor _httpContextAccessor;

    public LoginSuccessEventHandler(INovaHealthDbContext novaHealthDbContext, IHttpContextAccessor httpContextAccessor, ILogger<LoginSuccessEventHandler> logger)
    {
        _logger = logger;
        _novaHealthDbContext = novaHealthDbContext;
        _httpContextAccessor = httpContextAccessor;
    }

    public Task Handle(LoginSuccessEvent notification, CancellationToken cancellationToken)
    {
        string decryptedEmail = SecurityHelper.Decrypt(notification.User.Email);

        _logger.LogInformation($"Login success: {notification.User.Id} - {decryptedEmail}");

        var httpContext = _httpContextAccessor.HttpContext;

        if (httpContext?.Request.Headers.ContainsKey("User-Agent") ?? false)
        {
            var userAgentInfo = HttpHelper.ParseUserAgent(httpContext?.Request.Headers["User-Agent"].ToString());

            _novaHealthDbContext.Add(new LoginLog
            {
                UserId = notification.User.Id,
                UserAgent = userAgentInfo.UserAgent,
                Browser = userAgentInfo.Name,
                Version = userAgentInfo.Version,
                IpAddress = _httpContextAccessor.GetIpAddress(),
                Platform = userAgentInfo.Platform?.Name,
                MobileDeviceType = userAgentInfo.MobileDeviceType,
                RequestFrom = userAgentInfo.Type.ToString(),
                CreatedDate = DateTime.Now
            });

            _novaHealthDbContext.SaveChangesAsync(cancellationToken);
        }

        else
        {
            _logger.LogInformation($"Login success - cannot get UserAgent: {notification.User.Id} - {decryptedEmail}");
        }

        return Task.CompletedTask;
    }
}