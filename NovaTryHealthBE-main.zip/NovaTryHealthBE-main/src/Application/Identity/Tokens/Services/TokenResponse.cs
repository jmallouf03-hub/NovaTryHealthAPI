﻿namespace NovaHealth.Application.Identity.Tokens.Services;

public record TokenResponse(string Token, string RefreshToken, DateTime RefreshTokenExpiryTime);