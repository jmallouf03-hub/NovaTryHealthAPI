﻿using NovaHealth.Application.Common.Interfaces;
using NovaHealth.Domain.Entities;

namespace NovaHealth.Application.Identity.Tokens.Services;

public interface ITokenService : ITransientService
{
    TokenResponse GenerateToken(string ipAddress, User user);

    Task<GoogleUserInfo> DecodeGoogleTokenAsync(string googleToken);
}