﻿using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using NovaHealth.Application.Auth.Jwt;
using NovaHealth.Domain.Entities;
using NovaHealth.Shared.Authorization;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;
using Google.Apis.Auth;

namespace NovaHealth.Application.Identity.Tokens.Services;

public class TokenService : ITokenService
{
    private readonly JwtSettings _jwtSettings;

    public TokenService(IOptions<JwtSettings> jwtSettings)
    {
        _jwtSettings = jwtSettings.Value;
    }

    public TokenResponse GenerateToken(string ipAddress, User user)
    {
        var claims = GetClaims(user, ipAddress);

        var accessToken = GenerateEncryptedToken(GetSigningCredentials(), claims);
        var refreshToken = GenerateRefreshToken();
        var refreshTokenExpiryTime = DateTime.UtcNow.AddDays(_jwtSettings.RefreshTokenExpirationInDays);

        return new TokenResponse(accessToken, refreshToken, refreshTokenExpiryTime);
    }

    private IEnumerable<Claim> GetClaims(User user, string ipAddress) =>
        new List<Claim>
        {
            new(ClaimTypes.NameIdentifier, user.Id.ToString()),
            new(ClaimTypes.Email, user.Email!),
            new(NovaHealthClaims.IpAddress, ipAddress)
        };

    private SigningCredentials GetSigningCredentials()
    {
        var secret = Encoding.UTF8.GetBytes(_jwtSettings.Key);

        return new SigningCredentials(new SymmetricSecurityKey(secret), SecurityAlgorithms.HmacSha256);
    }

    private string GenerateEncryptedToken(SigningCredentials signingCredentials, IEnumerable<Claim> claims)
    {
        var token = new JwtSecurityToken(
            claims: claims,
            expires: DateTime.UtcNow.AddMinutes(_jwtSettings.TokenExpirationInMinutes),
            signingCredentials: signingCredentials
        );

        var tokenHandler = new JwtSecurityTokenHandler();

        return tokenHandler.WriteToken(token);
    }

    private static string GenerateRefreshToken()
    {
        var randomNumber = new byte[32];
        using var rng = RandomNumberGenerator.Create();
        rng.GetBytes(randomNumber);

        return Convert.ToBase64String(randomNumber);
    }

    public async Task<GoogleUserInfo> DecodeGoogleTokenAsync(string googleToken)
    {
        var payload = await GoogleJsonWebSignature.ValidateAsync(googleToken);

        // Extract user information from the token payload
        return new GoogleUserInfo
        {
            Name = payload.Name,
            Email = payload.Email,
            Picture = payload.Picture,

            // Add more fields if needed (e.g., FamilyName, GivenName)
        };
    }
}
public class GoogleUserInfo
{
    public string? Name { get; set; }

    public string? Email { get; set; }

    public string? Picture { get; set; }
}