﻿using MediatR;
using Microsoft.EntityFrameworkCore;
using NovaHealth.Application.Common.Interfaces;
using NovaHealth.Domain.Entities;

namespace NovaHealth.Application.Questions.Command.AddUpdateAnswerQuestion;

public class AddUpdateAnswerQuestionRequestHandler : IRequestHandler<AddUpdateAnswerQuestionRequest, bool>
{
    private readonly INovaHealthDbContext _novaHealthDbContext;

    public AddUpdateAnswerQuestionRequestHandler(INovaHealthDbContext novaHealthDbContext)
    {
        _novaHealthDbContext = novaHealthDbContext;
    }

    public async Task<bool> Handle(AddUpdateAnswerQuestionRequest request, CancellationToken cancellationToken)
    {
        // ✅ Fetch question using QuestionId
        var question = await _novaHealthDbContext.Questions
            .Include(q => q.Answers)
            .FirstOrDefaultAsync(q => q.Id == request.QuestionId, cancellationToken);

        if (question == null)
        {
            throw new Exception($"Question with Id {request.QuestionId} not found.");
        }

        if (request.AnswerOptions != null && request.AnswerOptions.Any())
        {
            var incomingIds = request.AnswerOptions.Where(x => x.Id > 0).Select(x => x.Id).ToList();

            // ❌ Remove answers not in request
            var toRemove = question.Answers.Where(a => !incomingIds.Contains(a.Id)).ToList();
            _novaHealthDbContext.AnswerOptions.RemoveRange(toRemove);

            // 🔄 Update or Add answers
            foreach (var option in request.AnswerOptions)
            {
                var existing = question.Answers.FirstOrDefault(a => a.Id == option.Id);

                if (existing != null)
                {
                    // Update existing answer
                    existing.Text = option.Text;
                    existing.Priority = option.Priority;
                    existing.NextQuestionId = option.NextQuestionId;
                    existing.Flag = option.Flag;
                }

                else
                {
                    // Add new answer
                    question.Answers.Add(new AnswerOption
                    {
                        Text = option.Text,
                        Priority = option.Priority,
                        NextQuestionId = option.NextQuestionId,
                        Flag = option.Flag,
                        CreatedDate = DateTime.UtcNow,
                        IsActive  =true,
                        IsDeleted = false
                    });
                }
                await _novaHealthDbContext.SaveChangesAsync(cancellationToken);

            }
        }
        else
        {
            // ⚠ If no answers given, remove all existing
            question.Answers.Clear();
        }

        await _novaHealthDbContext.SaveChangesAsync(cancellationToken);
        return true;
    }
}
