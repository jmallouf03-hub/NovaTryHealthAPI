﻿using MediatR;

namespace NovaHealth.Application.Questions.Command.AddUpdateAnswerQuestion;

public class AddUpdateAnswerQuestionRequest : IRequest<bool>
{
    public long Id { get; set; }
    public long QuestionId { get; set; }
    public long? NextQuestionId { get; set; }
    public List<AddUpdateAnswerQuestionOptionRequest>? AnswerOptions { get; set; } = new List<AddUpdateAnswerQuestionOptionRequest>();

}
public class AddUpdateAnswerQuestionOptionRequest
{
    public long Id { get; set; }
    public string? Text { get; set; }
    public int Priority { get; set; }

    public long? NextQuestionId { get; set; }

    public long? ProductId { get; set; }

    public string? Flag { get; set; }
}
