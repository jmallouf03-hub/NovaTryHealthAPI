﻿using MediatR;
using NovaHealth.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NovaHealth.Application.Questions.Command.AddUpdateQuestion;

public class AddUpdateQuestionRequest : IRequest<bool>  
{
    public long Id { get; set; }
    public long QuestionnaireId { get; set; }
    public string Title { get; set; } = null!;
    public long QuestionTypeId { get; set; }
    public long? NextQuestionId { get; set; } = null;
    public int? QuestionNumber { get; set; } = null;
    public long? QuestionSpecialVisitId { get; set; }
    public List<AddUpdateAnswerOptionRequest>? AnswerOptions { get; set; } = new List<AddUpdateAnswerOptionRequest>();

    public List<long>? ProductIds { get; set; } = new List<long>(); 

}

public class AddUpdateAnswerOptionRequest
{
    public long Id { get; set; }
    public string? Text { get; set; } 
    public int Priority { get; set; }

    public long? NextQuestionId { get; set; } 

   // public long? ProductId { get; set; } // Optional, if the answer option is linked to a product

    public string? Flag { get; set; } // e.g., "Disqualification", "Consent", "Details"
}

