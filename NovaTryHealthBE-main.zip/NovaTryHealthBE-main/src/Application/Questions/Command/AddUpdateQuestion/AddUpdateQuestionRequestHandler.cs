﻿using MediatR;
using Microsoft.EntityFrameworkCore;
using NovaHealth.Application.Common.Interfaces;
using NovaHealth.Domain.Entities;

namespace NovaHealth.Application.Questions.Command.AddUpdateQuestion;

public class AddUpdateQuestionRequestHandler : IRequestHandler<AddUpdateQuestionRequest, bool>
{
    private readonly INovaHealthDbContext _novaHealthDbContext;

    public AddUpdateQuestionRequestHandler(INovaHealthDbContext novaHealthDbContext)
    {
        _novaHealthDbContext = novaHealthDbContext;
    }

    public async Task<bool> Handle(AddUpdateQuestionRequest request, CancellationToken cancellationToken)
    {
        var question = await _novaHealthDbContext.Questions
            .Include(q => q.Answers)
            .Include(q => q.QuestionProducts) // ✅ Include QuestionProducts
            .FirstOrDefaultAsync(q => q.Id == request.Id, cancellationToken);

        if (question != null)
        {
            // 🔄 Update existing
            question.Title = request.Title;
            question.Name = request.Title;
            question.QuestionTypeId = request.QuestionTypeId;
            question.NextQuestionId= request.NextQuestionId;

            // 🔄 Update answers
            if (request.AnswerOptions != null && request.AnswerOptions.Any())
            {
                var incomingIds = request.AnswerOptions.Where(x => x.Id > 0).Select(x => x.Id).ToList();

                // Remove deleted answers
                var toRemove = question.Answers.Where(a => !incomingIds.Contains(a.Id)).ToList();
                _novaHealthDbContext.AnswerOptions.RemoveRange(toRemove);

                foreach (var option in request.AnswerOptions)
                {
                    var existing = question.Answers.FirstOrDefault(a => a.Id == option.Id);
                    if (existing != null && existing.Id > 0)
                    {
                        // Update existing
                        existing.Text = option.Text;
                        existing.Priority = option.Priority;
                        existing.NextQuestionId = option.NextQuestionId;
                        existing.Flag = option.Flag;
                    }
                    else
                    {
                        // Add new
                        question.Answers.Add(new AnswerOption
                        {
                            Text = option.Text,
                            Priority = option.Priority,
                            NextQuestionId = option.NextQuestionId,
                            Flag = option.Flag,
                            CreatedDate = DateTime.UtcNow
                        });
                    }
                }
            }
            else
            {
                // No answers provided, clear all
                question.Answers?.Clear();
            }

            // ✅ Update QuestionProducts
            if (request.ProductIds != null)
            {
                var existingProducts = question.QuestionProducts.Select(qp => qp.ProductId).ToList();
                var toRemoveProducts = question.QuestionProducts.Where(qp => !request.ProductIds.Contains(qp.ProductId.Value)).ToList();

                // Remove old mappings
                _novaHealthDbContext.QuestionProducts.RemoveRange(toRemoveProducts);

                // Add new mappings
                var newProductIds = request.ProductIds.Except(existingProducts.Cast<long>()).ToList();
                foreach (var productId in newProductIds)
                {
                    question.QuestionProducts.Add(new QuestionProduct
                    {
                        ProductId = productId,
                        QuestionId = question.Id
                    });
                }
            }
        }
        else
        {
            int seqNo;
            var questionSeq = await _novaHealthDbContext.Questions
              .Where(q => q.QuestionnaireId == request.QuestionnaireId) .MaxAsync(q => (int?)q.QuestionNumber, cancellationToken) ?? 0;
            if (questionSeq <= 0)
            {
                seqNo = 1;
            }
            else
                seqNo = questionSeq + 1;

            // ➕ Insert new
            question = new Domain.Entities.Question
            {
                QuestionnaireId = request.QuestionnaireId,
                Title = request.Title,
                Name = request.Title,
                QuestionTypeId = request.QuestionTypeId,
                QuestionSpecialVisitId = request.QuestionSpecialVisitId,
                NextQuestionId = request.NextQuestionId,
                IsDeleted = false,
                IsActive = true,
                QuestionNumber = seqNo,
                CreatedDate = DateTime.UtcNow,
                Answers = new List<AnswerOption>(),
                QuestionProducts = new List<QuestionProduct>() // ✅ Initialize
            };

            if (request.AnswerOptions != null && request.AnswerOptions.Any())
            {
                foreach (var option in request.AnswerOptions)
                {
                    question.Answers.Add(new AnswerOption
                    {
                        Text = option.Text,
                        Priority = option.Priority,
                        NextQuestionId = option.NextQuestionId,
                        Flag = option.Flag,
                        CreatedDate = DateTime.UtcNow
                    });
                }
            }

            // ✅ Add QuestionProduct mappings
            if (request.ProductIds != null && request.ProductIds.Any())
            {
                foreach (var productId in request.ProductIds)
                {
                    question.QuestionProducts.Add(new QuestionProduct
                    {
                        ProductId = productId
                    });
                }
            }

            await _novaHealthDbContext.Questions.AddAsync(question, cancellationToken);
        }

        await _novaHealthDbContext.SaveChangesAsync(cancellationToken);
        return true;
    }
}
