﻿using MediatR;
using Microsoft.EntityFrameworkCore;
using NovaHealth.Application.Common.Exceptions;
using NovaHealth.Application.Common.Interfaces;
using System.Text.Json.Serialization;


namespace NovaHealth.Application.Question.Command.DeleteQuestion;

public class QuestionDeleteByIdRequest : IRequest<bool>
{
    [JsonIgnore] public long QuestionId { get; set; }

    [JsonIgnore] public bool IsDeleted { get; set; }   
}


public class QuestionDeleteByIdRequestHandler : IRequestHandler<QuestionDeleteByIdRequest, bool>
{
    private readonly INovaHealthDbContext _novaHealthDbContext;
    public QuestionDeleteByIdRequestHandler(INovaHealthDbContext novaHealthDbContext)
    {
        _novaHealthDbContext = novaHealthDbContext;
    }

    public async Task<bool> Handle(QuestionDeleteByIdRequest request, CancellationToken cancellationToken)
    {
        var Question = await _novaHealthDbContext.Questions
            .FirstOrDefaultAsync(q => q.Id == request.QuestionId, cancellationToken);

        if (Question == null)
            throw new NotFoundException("QuestionnaireId not found.");

        Question.IsDeleted = request.IsDeleted;

      await  _novaHealthDbContext.SaveChangesAsync(cancellationToken);

        return true;
    }
}

