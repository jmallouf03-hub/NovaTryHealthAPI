﻿using MediatR;
using System.Text.Json.Serialization;
using NovaHealth.Application.Common.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace NovaHealth.Application.Questions.Command.AddUpdateDuplicateQuestion;

public class AddUpdateDuplicateQuestionRequest : IRequest<bool>
{
    [JsonIgnore] public long Id { get; set; }

}
public class AddUpdateDuplicateQuestionRequestHandler : IRequestHandler<AddUpdateDuplicateQuestionRequest, bool>
{
    private readonly INovaHealthDbContext _novaHealthDbContext;

    public AddUpdateDuplicateQuestionRequestHandler(INovaHealthDbContext novaHealthDbContext)
    {
        _novaHealthDbContext = novaHealthDbContext;
    }

    public async Task<bool> Handle(AddUpdateDuplicateQuestionRequest request, CancellationToken cancellationToken)
    {
        // Load original question with answers
        var source = await _novaHealthDbContext.Questions
            .Include(q => q.Answers)
            .FirstOrDefaultAsync(q => q.Id == request.Id, cancellationToken);

        if (source == null)
            throw new Exception($"Question with ID {request.Id} not found.");

        // Create duplicate
        var duplicate = new Domain.Entities.Question
        {
            Title = $"{source.Title} (copy)",
            QuestionnaireId = source.QuestionnaireId,
            QuestionTypeId = source.QuestionTypeId,
            QuestionSpecialVisitId = source.QuestionSpecialVisitId,
            CreatedDate = DateTime.UtcNow,
            IsActive = true,
            IsDeleted = false,
            Answers = new List<Domain.Entities.AnswerOption>()
        };

        // Copy answers
        foreach (var ans in source.Answers.Where(a => !a.IsDeleted))
        {
            duplicate.Answers.Add(new Domain.Entities.AnswerOption
            {
                Text = ans.Text,
                Priority = ans.Priority,
                NextQuestionId = ans.NextQuestionId,
                Flag = ans.Flag,
                CreatedDate = DateTime.UtcNow,
                IsActive = true,
                IsDeleted = false
            });
        }
        await _novaHealthDbContext.Questions.AddAsync(duplicate, cancellationToken);
        await _novaHealthDbContext.SaveChangesAsync(cancellationToken);

        return true;
    }
}