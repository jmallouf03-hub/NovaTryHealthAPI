﻿using MediatR;
using Microsoft.EntityFrameworkCore;
using NovaHealth.Application.Common.Interfaces;

namespace NovaHealth.Application.Questions.Command.UpdateQuestionNumber;

public class UpdateQuestionNumberRequestHandler : IRequestHandler<ListUpdateQuestionNumberRequest, bool>
{
    private readonly INovaHealthDbContext _novaHealthDbContext;

    public UpdateQuestionNumberRequestHandler(INovaHealthDbContext novaHealthDbContext)
    {
        _novaHealthDbContext = novaHealthDbContext;
    }

    public async Task<bool> Handle(ListUpdateQuestionNumberRequest request, CancellationToken cancellationToken)
    {
        // 1. Question find karo

        foreach (var item in request.Questions)
        {
            var question = await _novaHealthDbContext.Questions
                .FirstOrDefaultAsync(x => x.Id == item.QuestionId, cancellationToken);
            if (question == null)
            {
                continue;
            }

            question.QuestionNumber = item.QuestionSeqNo;

        }

        await _novaHealthDbContext.SaveChangesAsync(cancellationToken);

        return true;
    }
}
