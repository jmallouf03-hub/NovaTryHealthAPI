﻿using MediatR;

namespace NovaHealth.Application.Questions.Command.UpdateQuestionNumber;


public  class ListUpdateQuestionNumberRequest : IRequest<bool>
{
    public List<UpdateQuestionNumberRequest> Questions { get; set; } = new();
}
public class UpdateQuestionNumberRequest 
{
    public long QuestionId { get; set; }

    public int QuestionSeqNo { get; set; }

}
