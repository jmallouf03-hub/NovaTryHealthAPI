﻿using AutoMapper;
using AutoMapper.QueryableExtensions;
using MediatR;
using Microsoft.EntityFrameworkCore;
using NovaHealth.Application.Common.Interfaces;
using NovaHealth.Application.Common.Mappings;
using NovaHealth.Application.Common.Models;
using System.Linq.Dynamic.Core;

namespace NovaHealth.Application.Questions.Queries.GetQuestionTypeList;

public class GetQuestionTypeListRequest : PaginationFilter, IRequest<PaginationResponse<GetQuestionTypeListResponse>> { }

public class GetQuestionTypeListRequestHandler : IRequestHandler<GetQuestionTypeListRequest, PaginationResponse<GetQuestionTypeListResponse>>
{
    private readonly INovaHealthDbContext _novaHealthDbContext;
    private readonly IMapper _mapper;

    public GetQuestionTypeListRequestHandler(INovaHealthDbContext novaHealthDbContext, IMapper mapper)
    {
        _novaHealthDbContext = novaHealthDbContext;
        _mapper = mapper;
    }

    public async Task<PaginationResponse<GetQuestionTypeListResponse>> Handle(GetQuestionTypeListRequest request, CancellationToken cancellationToken)
    {

        var query = _novaHealthDbContext.QuestionTypes
          .AsNoTracking()
          .Select(x => new GetQuestionTypeListResponse
          {
              Id = x.Id,
              Type = x.Type,
          });

        // Apply filter if provided
        if (!string.IsNullOrEmpty(request.Filter))
        {
            query = query.Where(request.Filter);
        }

        // Apply order
        if (!string.IsNullOrEmpty(request.OrderBy))
        {
            query = query.OrderBy(request.OrderBy);
        }
        else
        {
            query = query.OrderBy(x => x.Id);
        }


        return await query.ProjectTo<GetQuestionTypeListResponse>(_mapper.ConfigurationProvider)
                 .PaginatedListAsync(request.PageNumber, request.PageSize);
    }
}