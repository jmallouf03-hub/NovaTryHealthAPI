﻿using AutoMapper;

namespace NovaHealth.Application.Questions.Queries.GetQuestionTypeList;
public class GetQuestionTypeListResponse
{
    public long Id { get; set; }
    public string Type { get; set; } = null!;

    public class Mapping : Profile
    {
        public Mapping()
        {
            CreateMap<GetQuestionTypeListResponse, GetQuestionTypeListResponse>();
        }
    }
}
