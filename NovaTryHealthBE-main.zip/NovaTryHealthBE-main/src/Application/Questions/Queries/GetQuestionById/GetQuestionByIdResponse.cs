﻿namespace NovaHealth.Application.Questions.Queries.GetQuestionById;
public class GetQuestionByIdResponse
{
    public long Id { get; set; }
    public long QuestionnaireId { get; set; }
    public string Title { get; set; } = null!;
    public string? Name { get; set; }
    public long? NextQuestionId { get; set; } = null;
    public long QuestionTypeId { get; set; }
    public long? questionSpecialVisitId { get; set; }
    public List<GetAnswerOptionResponse>? AnswerOptions { get; set; } = new List<GetAnswerOptionResponse>();
    public List<long>? ProductIds { get; set; } = new List<long>();
}

public class GetAnswerOptionResponse
{
    public long Id { get; set; }
    public string? Text { get; set; }
    public int Priority { get; set; }

    public long? NextQuestionId { get; set; }

    public string? Flag { get; set; } // e.g., "Disqualification", "Consent", "Details"
}