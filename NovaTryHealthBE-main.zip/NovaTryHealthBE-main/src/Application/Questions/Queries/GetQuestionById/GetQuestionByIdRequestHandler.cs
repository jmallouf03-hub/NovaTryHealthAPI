﻿using MediatR;
using Microsoft.EntityFrameworkCore;
using NovaHealth.Application.Common.Exceptions;
using NovaHealth.Application.Common.Interfaces;
using NovaHealth.Domain.Entities;
using System.Text.Json.Serialization;

namespace NovaHealth.Application.Questions.Queries.GetQuestionById;

public class GetQuestionByIdRequest : IRequest<GetQuestionByIdResponse>
{
    [JsonIgnore] public long QuestionId { get; set; }
}   
public class GetQuestionByIdRequestHandler : IRequestHandler<GetQuestionByIdRequest, GetQuestionByIdResponse>
{
    private readonly INovaHealthDbContext _novaHealthDbContext;
    public GetQuestionByIdRequestHandler(INovaHealthDbContext novaHealthDbContext)
    {
     _novaHealthDbContext = novaHealthDbContext;
    }

    public async Task<GetQuestionByIdResponse> Handle(GetQuestionByIdRequest request, CancellationToken cancellationToken)
    {
        var question = await _novaHealthDbContext.Questions.Include(q=>q.QuestionProducts)
            .Include(q => q.Answers)
            .FirstOrDefaultAsync(q => q.Id == request.QuestionId  &&!q.IsDeleted, cancellationToken);

        if (question == null)
            throw new NotFoundException("Question not found."); 

        return new GetQuestionByIdResponse
        {
            Id = question.Id,
            QuestionnaireId = question.QuestionnaireId,
            Title = question.Title,
            Name = question.Name,
            NextQuestionId = question.NextQuestionId,
            questionSpecialVisitId = question.QuestionSpecialVisitId,
            QuestionTypeId = question.QuestionTypeId,
            AnswerOptions = question.Answers?.Select(a => new GetAnswerOptionResponse
            {
                Id = a.Id,
                Text = a.Text,
                Priority = a.Priority,
                NextQuestionId = a.NextQuestionId,
                Flag = a.Flag
            }).ToList(),
            ProductIds = question.QuestionProducts?.Where(a => a.ProductId.HasValue).Select(a => a.ProductId.Value).ToList()

        };
    }
}

