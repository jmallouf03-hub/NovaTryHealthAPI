﻿using MediatR;
using Microsoft.EntityFrameworkCore;
using NovaHealth.Application.Common.Exceptions;
using NovaHealth.Application.Common.Interfaces;
using NovaHealth.Domain.Entities;

namespace NovaHealth.Application.Questions.Queries.GetNextQuestionByProduct;


public class GetNextQuestionByProductIdRequest : IRequest<GetNextQuestionByProductIdResponse>
{
    public long ProductId { get; set; }

    public long? PatientId { get; set; }

}

public class GetNextQuestionByProductIdHandler : IRequestHandler<GetNextQuestionByProductIdRequest, GetNextQuestionByProductIdResponse>
{
    private readonly INovaHealthDbContext _novaHealthDbContext;
    public GetNextQuestionByProductIdHandler(INovaHealthDbContext novaHealthDbContext)
    {
        _novaHealthDbContext = novaHealthDbContext;
    }
    public async Task<GetNextQuestionByProductIdResponse> Handle(GetNextQuestionByProductIdRequest request, CancellationToken cancellationToken)
    {
        long? nextQuestionId = null;
        long? layoutId = null;


        var questionnaireId = await _novaHealthDbContext.QuestionnaireProducts
             .Where(p => p.ProductId == request.ProductId && !p.IsDeleted)
             .Select(p => p.QuestionnaireId)
             .FirstOrDefaultAsync(cancellationToken);
        if (request.PatientId == null || request.PatientId <= 0)
        {
            // New patient (no PatientId) → Start with AUTH type question
            var firstQuestion = await _novaHealthDbContext.Questions
                .Include(x => x.QuestionType)
                .Include(q => q.Questionnaire)
                .FirstOrDefaultAsync(q => q.QuestionnaireId == questionnaireId
                                       && q.QuestionType.Type.ToLower() == "auth"
                                       && !q.IsDeleted,
                                       cancellationToken);

            if (firstQuestion != null)
            {
                nextQuestionId = firstQuestion.Id;
                layoutId = firstQuestion.Questionnaire?.QuestionnaireGlobalLayoutId;
            }
        }
        else
        {
            // Existing patient (PatientId is present) → Skip AUTH, pick by QuestionNumber
            var questionSeqNo = await _novaHealthDbContext.Questions
                .Include(q => q.Questionnaire)
                .Where(q => q.QuestionnaireId == questionnaireId
                         && !q.IsDeleted
                         && q.QuestionType.Type.ToLower() != "auth") // skip auth
                .OrderBy(q => q.QuestionNumber)
                .FirstOrDefaultAsync(cancellationToken);

            if (questionSeqNo != null)
            {
                nextQuestionId = questionSeqNo.Id;
                layoutId = questionSeqNo.Questionnaire?.QuestionnaireTypeId;
            }
        }


        //if (request.PatientId > 0&& request.PatientId==null)
        //{
        //    var firstQuestion = await _novaHealthDbContext.Questions
        //        .Include(x => x.QuestionType)
        //        .Include(q => q.Questionnaire)
        //        .FirstOrDefaultAsync(q => q.QuestionnaireId == questionnaireId
        //                               && q.QuestionType.Type.ToLower() == "auth",
        //                               cancellationToken);

        //    if (firstQuestion != null)
        //    {
        //        nextQuestionId = firstQuestion.Id;
        //        layoutId = firstQuestion.Questionnaire?.QuestionnaireGlobalLayoutId;
        //    }
        //}
        //else
        //{
        //    var questionSeqNo = await _novaHealthDbContext.Questions
        //        .Include(q => q.Questionnaire)
        //        .Where(q => q.QuestionnaireId == questionnaireId && !q.IsDeleted)
        //        .OrderBy(q => q.QuestionNumber)
        //        .FirstOrDefaultAsync(cancellationToken);

        //    if (questionSeqNo != null)
        //    {
        //        nextQuestionId = questionSeqNo.Id;
        //        layoutId = questionSeqNo.Questionnaire?.QuestionnaireTypeId;
        //    }
        //}
        //if (request.PatientId > 0)
        //{
        //    var firstQuestion = await _novaHealthDbContext.Questions.Include(x => x.QuestionType)
        //                       .Include(q => q.Questionnaire)
        //                       .FirstOrDefaultAsync(q => q.QuestionnaireId == questionnaireId && q.QuestionType.Type.ToLower() == "auth", cancellationToken);
        //    if (firstQuestion != null)
        //    {
        //        nextQuestionId = firstQuestion.Id;
        //        layoutId = firstQuestion.Questionnaire.QuestionnaireGlobalLayoutId;
        //    }
        //}
        //else
        //{
        //    var QuestionSeqNo = await _novaHealthDbContext.Questions.Include(q => q.Questionnaire)
        //                    .Where(q => q.QuestionnaireId == questionnaireId && !q.IsDeleted)
        //                    .OrderBy(q => q.QuestionNumber)
        //                   // .Select(q => q.Id)
        //                   .FirstOrDefaultAsync(cancellationToken);
        //    nextQuestionId = QuestionSeqNo.Id;
        //    layoutId = QuestionSeqNo.Questionnaire.QuestionnaireTypeId;

        //}




        var question = await _novaHealthDbContext.Questions.Include(x => x.QuestionType)
            .Include(q => q.Answers).Include(q => q.QuestionProducts)
            .FirstOrDefaultAsync(q => q.Id == nextQuestionId && !q.IsDeleted, cancellationToken)
            ?? throw new NotFoundException("Question not found.");

        // fetch all layout settings
        var header = await _novaHealthDbContext.LayoutHeaderSettings.AsNoTracking().FirstOrDefaultAsync(x => x.LayoutId == layoutId, cancellationToken);
        var footer = await _novaHealthDbContext.LayoutFooterSettings.AsNoTracking().FirstOrDefaultAsync(x => x.LayoutId == layoutId, cancellationToken);
        var answerSettings = await _novaHealthDbContext.LayoutAnswerSettings.AsNoTracking().FirstOrDefaultAsync(x => x.LayoutId == layoutId, cancellationToken);
        var title = await _novaHealthDbContext.LayoutTitleSettings.AsNoTracking().FirstOrDefaultAsync(x => x.LayoutId == layoutId, cancellationToken);

        if (header == null && footer == null && answerSettings == null && title == null)
            throw new Exception($"No layout settings found for LayoutId {layoutId}");

        return new GetNextQuestionByProductIdResponse
        {
            QuestionOptionResponse = MapQuestion(question),
            LayoutHeaderSetting = MapHeader(header),
            LayoutFooterSetting = MapFooter(footer),
            LayoutAnswerSetting = MapAnswer(answerSettings),
            LayoutTitleSetting = MapTitle(title)
        };
    }

    private static GetQuestionByIdResponse MapQuestion(NovaHealth.Domain.Entities.Question question) =>
        new GetQuestionByIdResponse
        {
            Id = question.Id,
            QuestionnaireId = question.QuestionnaireId,
            Title = question.Title,
            Name = question.Name,
            QuestionType = question.QuestionType.Type,
            NextQuestionId = question.NextQuestionId,
            QuestionSpecialVisitId = question.QuestionSpecialVisitId,
            QuestionTypeId = question.QuestionTypeId,
            AnswerOptions = question.Answers?.Select(a => new GetAnswerOptionResponse
            {
                Id = a.Id,
                Text = a.Text,
                Priority = a.Priority,
                NextQuestionId = a.NextQuestionId,
                Flag = a.Flag
            }).ToList(),
            ProductIds = question.QuestionProducts?.Select(qp => qp.ProductId).Where(id => id.HasValue)       // null check
                  .Select(id => id.Value).ToList()
        };

    private static LayoutHeaderSettingResponse MapHeader(LayoutHeaderSetting? header) =>
        header == null ? new LayoutHeaderSettingResponse() : new LayoutHeaderSettingResponse
        {
            NavbarLeftRadius = header.NavbarLeftRadius,
            HeaderBackgroundColor = header.HeaderBackgroundColor,
            HeaderLogo = header.HeaderLogo,
            CustomProgressBarSegments = header.CustomProgressBarSegments,
            BackButtonGlobal = header.BackButtonGlobal,
            BackButtonOnlyCurrent = header.BackButtonOnlyCurrent,
            ProgressBarColor = header.ProgressBarColor,
            ProgressBarBackgroundColor = header.ProgressBarBackgroundColor,
            BackButtonColor = header.BackButtonColor,
            HeaderTextColor = header.HeaderTextColor,
            ShowHelpButton = header.ShowHelpButton,
            HelpButtonSupportHours = header.HelpButtonSupportHours,
            HelpButtonColor = header.HelpButtonColor,
            HelpButtonTextColor = header.HelpButtonTextColor
        };

    private static LayoutFooterSettingResponse MapFooter(LayoutFooterSetting? footer) =>
        footer == null ? new LayoutFooterSettingResponse() : new LayoutFooterSettingResponse
        {
            LayoutId = footer.LayoutId,
            ShowFooter = footer.ShowFooter,
            PrimaryTextColor = footer.PrimaryTextColor,
            SecondaryTextColor = footer.SecondaryTextColor,
            DividerColor = footer.DividerColor,
            BackgroundColor = footer.BackgroundColor,
            FooterLogo = footer.FooterLogo,
            CompanyName = footer.CompanyName,
            PhoneNumber = footer.PhoneNumber,
            EmailAddress = footer.EmailAddress,
            HelpCenterURL = footer.HelpCenterURL,
            CopyrightText = footer.CopyrightText,
            ShowFooterSocialIcons = footer.ShowFooterSocialIcons,
            FacebookURL = footer.FacebookURL,
            InstagramURL = footer.InstagramURL,
            TwitterURL = footer.TwitterURL,
            LinkedInURL = footer.LinkedInURL
        };

    private static LayoutAnswerSettingResponse MapAnswer(LayoutAnswerSetting? answer) =>
        answer == null ? new LayoutAnswerSettingResponse() : new LayoutAnswerSettingResponse
        {
            AnswerBackgroundColor = answer.AnswerBackgroundColor,
            AnswerTextColor = answer.AnswerTextColor,
            AnswerHighlightColor = answer.AnswerHighlightColor,
            AnswerOutlineColor = answer.AnswerOutlineColor
        };

    private static LayoutTitleSettingResponse MapTitle(LayoutTitleSetting? title) =>
        title == null ? new LayoutTitleSettingResponse() : new LayoutTitleSettingResponse
        {
            LayoutId = title.LayoutId,
            PreHeader = title.PreHeader,
            ShowPreHeader = title.ShowPreHeader,
            PreHeaderColor = title.PreHeaderColor,
            MainHeader = title.MainHeader,
            ShowMainHeader = title.ShowMainHeader,
            MainHeaderColor = title.MainHeaderColor,
            SubHeader = title.SubHeader,
            ShowSubHeader = title.ShowSubHeader,
            SubHeaderColor = title.SubHeaderColor,
            Banner = title.Banner,
            ShowBanner = title.ShowBanner,
            BannerTextColor = title.BannerTextColor,
            BannerBGColor = title.BannerBGColor,
            ShowBannerIcon = title.ShowBannerIcon,
            BannerIconColor = title.BannerIconColor
        };
}