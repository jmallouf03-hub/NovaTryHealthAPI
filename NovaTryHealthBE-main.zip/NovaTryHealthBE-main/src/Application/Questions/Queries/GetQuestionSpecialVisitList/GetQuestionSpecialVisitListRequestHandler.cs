﻿using AutoMapper;
using AutoMapper.QueryableExtensions;
using MediatR;
using Microsoft.EntityFrameworkCore;
using NovaHealth.Application.Common.Interfaces;
using NovaHealth.Application.Common.Mappings;
using NovaHealth.Application.Common.Models;
using System.Linq.Dynamic.Core;


namespace NovaHealth.Application.Questions.Queries.GetQuestionSpecialVisitList;
public class GetQuestionSpecialVisitListRequest : PaginationFilter, IRequest<PaginationResponse<GetQuestionSpecialVisitResponse>> { }

public class GetQuestionSpecialVisitListRequestHandler : IRequestHandler<GetQuestionSpecialVisitListRequest, PaginationResponse<GetQuestionSpecialVisitResponse>>
{
    private readonly INovaHealthDbContext _novaHealthDbContext;
    private readonly IMapper _mapper;

    public GetQuestionSpecialVisitListRequestHandler(INovaHealthDbContext novaHealthDbContext, IMapper mapper)
    {
        _novaHealthDbContext = novaHealthDbContext;
        _mapper = mapper;
    }

    public async Task<PaginationResponse<GetQuestionSpecialVisitResponse>> Handle(GetQuestionSpecialVisitListRequest request, CancellationToken cancellationToken)
    {

        var query = _novaHealthDbContext.QuestionSpecialVisits
        .AsNoTracking()
        .Select(x => new GetQuestionSpecialVisitResponse
        {
            Id = x.Id,
            SpecialVisitName = x.SpecialVisitName
        });

        // Apply filter if provided
        if (!string.IsNullOrEmpty(request.Filter))
        {
            query = query.Where(request.Filter);
        }

        // Apply order
        if (!string.IsNullOrEmpty(request.OrderBy))
        {
            query = query.OrderBy(request.OrderBy);
        }
        else
        {
            query = query.OrderBy(x => x.Id);
        }


        return await query.ProjectTo<GetQuestionSpecialVisitResponse>(_mapper.ConfigurationProvider)
                 .PaginatedListAsync(request.PageNumber, request.PageSize);
    }
}