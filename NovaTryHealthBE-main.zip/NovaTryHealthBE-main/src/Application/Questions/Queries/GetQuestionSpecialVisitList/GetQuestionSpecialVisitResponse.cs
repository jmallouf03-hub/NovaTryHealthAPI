﻿using AutoMapper;

namespace NovaHealth.Application.Questions.Queries.GetQuestionSpecialVisitList;

public class GetQuestionSpecialVisitResponse
{
    public long Id { get; set; }
    public string SpecialVisitName { get; set; } = null!;

    public class Mapping : Profile
    {
        public Mapping()
        {
            CreateMap<GetQuestionSpecialVisitResponse, GetQuestionSpecialVisitResponse>();
        }
    }
}
