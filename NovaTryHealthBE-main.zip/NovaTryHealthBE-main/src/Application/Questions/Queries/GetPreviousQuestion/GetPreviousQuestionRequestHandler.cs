﻿//using MediatR;
//using Microsoft.AspNetCore.Http;
//using Microsoft.EntityFrameworkCore;
//using Microsoft.Extensions.Options;
//using NovaHealth.Application.Common.Exceptions;
//using NovaHealth.Application.Common.FileStorage;
//using NovaHealth.Application.Common.Interfaces;
//using NovaHealth.Application.Questions.Queries.GetNextQuestion;
//using NovaHealth.Domain.Entities;
//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace NovaHealth.Application.Questions.Queries.GetPreviousQuestion;


//public class GetPreviousQuestionRequest : IRequest<GetPreviousQuestionResponse>
//{
//    public long? PatientId { get; set; } = null;
//    public long? QuestionId { get; set; } = null;




//}

//public class GetPreviousQuestionRequestHandler : IRequestHandler<GetPreviousQuestionRequest, GetPreviousQuestionResponse>
//{
//    private readonly INovaHealthDbContext _novaHealthDbContext;

//    private readonly IHttpContextAccessor _httpContextAccessor;

//    private readonly Func<FileStorageOption?, IFileStorageService> _fileStorageFunc;
//    private readonly AppSettings _appSettings;
//    public GetPreviousQuestionRequestHandler(INovaHealthDbContext novaHealthDbContext, IHttpContextAccessor httpContextAccessor, Func<FileStorageOption?, IFileStorageService> fileStorageFunc, IOptions<AppSettings> appSettings)
//    {
//        _novaHealthDbContext = novaHealthDbContext;
//        _httpContextAccessor = httpContextAccessor;
//        _fileStorageFunc = fileStorageFunc;
//        _appSettings = appSettings.Value;
//    }
//    public async Task<GetPreviousQuestionResponse> Handle(GetPreviousQuestionRequest request, CancellationToken cancellationToken)
//    {


//        string sessionId = _httpContextAccessor.HttpContext?.Request.Headers.TryGetValue("ClientId", out var values)
//         == true ? values.ToString() : null;


//            long nextQuestionId;
//            long layoutId;



//        var currentAnswer = await _novaHealthDbContext.PatientQuestionAnswers
//                    .Where(pqa => pqa.SessionId == sessionId && pqa.QuestionId == request.QuestionId)
//                    .Include(pqa => pqa.PatientAnswers) 
//                    .FirstOrDefaultAsync(cancellationToken);

//        layoutId = await _novaHealthDbContext.Questions.Where(q => q.Id == currentAnswer.QuestionId)
//                    .Select(q => q.Questionnaire.QuestionnaireGlobalLayoutId)
//                     .FirstOrDefaultAsync(cancellationToken);

//        //if (currentAnswer != null)
//        //{
//        //    // Remove related PatientAnswers
//        //    if (currentAnswer.PatientAnswers != null && currentAnswer.PatientAnswers.Any())
//        //    {
//        //        _novaHealthDbContext.PatientAnswers.RemoveRange(currentAnswer.PatientAnswers);
//        //    }

//        //    // Remove PatientQuestionAnswer itself
//        //    _novaHealthDbContext.PatientQuestionAnswers.Remove(currentAnswer);

//        //    await _novaHealthDbContext.SaveChangesAsync(cancellationToken);
//        //}




//        var question = await _novaHealthDbContext.Questions.Include(x => x.QuestionType)
//            .Include(q => q.Answers).Include(q => q.QuestionProducts)
//            .FirstOrDefaultAsync(q => q.Id == currentAnswer.QuestionId && !q.IsDeleted, cancellationToken)
//            ?? throw new NotFoundException("Question not found.");

//        // fetch all layout settings
//        var header = await _novaHealthDbContext.LayoutHeaderSettings.AsNoTracking().FirstOrDefaultAsync(x => x.LayoutId == layoutId, cancellationToken);
//        var footer = await _novaHealthDbContext.LayoutFooterSettings.AsNoTracking().FirstOrDefaultAsync(x => x.LayoutId == layoutId, cancellationToken);
//        var answerSettings = await _novaHealthDbContext.LayoutAnswerSettings.AsNoTracking().FirstOrDefaultAsync(x => x.LayoutId == layoutId, cancellationToken);
//        var title = await _novaHealthDbContext.LayoutTitleSettings.AsNoTracking().FirstOrDefaultAsync(x => x.LayoutId == layoutId, cancellationToken);

//        if (header == null && footer == null && answerSettings == null && title == null)
//            throw new Exception($"No layout settings found for LayoutId {layoutId}");

//        return new GetPreviousQuestionResponse
//        {
//            QuestionOptionResponse = MapQuestion(question),
//            LayoutHeaderSetting = MapHeader(header),
//            LayoutFooterSetting = MapFooter(footer),
//            LayoutAnswerSetting = MapAnswer(answerSettings),
//            LayoutTitleSetting = MapTitle(title)
//        };
//    }

//    private static GetQuestionByIdResponse MapQuestion(NovaHealth.Domain.Entities.Question question) =>
//        new GetQuestionByIdResponse
//        {
//            Id = question.Id,
//            QuestionnaireId = question.QuestionnaireId,
//            Title = question.Title,
//            Name = question.Name,
//            QuestionType = question.QuestionType.Type,
//            NextQuestionId = question.NextQuestionId,
//            QuestionSpecialVisitId = question.QuestionSpecialVisitId,
//            QuestionTypeId = question.QuestionTypeId,
//            AnswerOptions = question.Answers?.Select(a => new GetAnswerOptionResponse
//            {
//                Id = a.Id,
//                Text = a.Text,
//                Priority = a.Priority,
//                NextQuestionId = a.NextQuestionId,
//                Flag = a.Flag
//            }).ToList(),
//            ProductIds = question.QuestionProducts?.Select(qp => qp.ProductId).Where(id => id.HasValue)       // null check
//                  .Select(id => id.Value).ToList()
//        };

//    private static LayoutHeaderSettingResponse MapHeader(LayoutHeaderSetting? header) =>
//        header == null ? new LayoutHeaderSettingResponse() : new LayoutHeaderSettingResponse
//        {
//            NavbarLeftRadius = header.NavbarLeftRadius,
//            HeaderBackgroundColor = header.HeaderBackgroundColor,
//            HeaderLogo = header.HeaderLogo,
//            CustomProgressBarSegments = header.CustomProgressBarSegments,
//            BackButtonGlobal = header.BackButtonGlobal,
//            BackButtonOnlyCurrent = header.BackButtonOnlyCurrent,
//            ProgressBarColor = header.ProgressBarColor,
//            ProgressBarBackgroundColor = header.ProgressBarBackgroundColor,
//            BackButtonColor = header.BackButtonColor,
//            HeaderTextColor = header.HeaderTextColor,
//            ShowHelpButton = header.ShowHelpButton,
//            HelpButtonSupportHours = header.HelpButtonSupportHours,
//            HelpButtonColor = header.HelpButtonColor,
//            HelpButtonTextColor = header.HelpButtonTextColor
//        };

//    private static LayoutFooterSettingResponse MapFooter(LayoutFooterSetting? footer) =>
//        footer == null ? new LayoutFooterSettingResponse() : new LayoutFooterSettingResponse
//        {
//            LayoutId = footer.LayoutId,
//            ShowFooter = footer.ShowFooter,
//            PrimaryTextColor = footer.PrimaryTextColor,
//            SecondaryTextColor = footer.SecondaryTextColor,
//            DividerColor = footer.DividerColor,
//            BackgroundColor = footer.BackgroundColor,
//            FooterLogo = footer.FooterLogo,
//            CompanyName = footer.CompanyName,
//            PhoneNumber = footer.PhoneNumber,
//            EmailAddress = footer.EmailAddress,
//            HelpCenterURL = footer.HelpCenterURL,
//            CopyrightText = footer.CopyrightText,
//            ShowFooterSocialIcons = footer.ShowFooterSocialIcons,
//            FacebookURL = footer.FacebookURL,
//            InstagramURL = footer.InstagramURL,
//            TwitterURL = footer.TwitterURL,
//            LinkedInURL = footer.LinkedInURL
//        };

//    private static LayoutAnswerSettingResponse MapAnswer(LayoutAnswerSetting? answer) =>
//        answer == null ? new LayoutAnswerSettingResponse() : new LayoutAnswerSettingResponse
//        {
//            AnswerBackgroundColor = answer.AnswerBackgroundColor,
//            AnswerTextColor = answer.AnswerTextColor,
//            AnswerHighlightColor = answer.AnswerHighlightColor,
//            AnswerOutlineColor = answer.AnswerOutlineColor
//        };

//    private static LayoutTitleSettingResponse MapTitle(LayoutTitleSetting? title) =>
//        title == null ? new LayoutTitleSettingResponse() : new LayoutTitleSettingResponse
//        {
//            LayoutId = title.LayoutId,
//            PreHeader = title.PreHeader,
//            ShowPreHeader = title.ShowPreHeader,
//            PreHeaderColor = title.PreHeaderColor,
//            MainHeader = title.MainHeader,
//            ShowMainHeader = title.ShowMainHeader,
//            MainHeaderColor = title.MainHeaderColor,
//            SubHeader = title.SubHeader,
//            ShowSubHeader = title.ShowSubHeader,
//            SubHeaderColor = title.SubHeaderColor,
//            Banner = title.Banner,
//            ShowBanner = title.ShowBanner,
//            BannerTextColor = title.BannerTextColor,
//            BannerBGColor = title.BannerBGColor,
//            ShowBannerIcon = title.ShowBannerIcon,
//            BannerIconColor = title.BannerIconColor
//        };
//}


using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using NovaHealth.Application.Common.Exceptions;
using NovaHealth.Application.Common.Interfaces;
using NovaHealth.Domain.Entities;
using System.Text.Json.Serialization;

namespace NovaHealth.Application.Questions.Queries.GetPreviousQuestion;

public class GetPreviousQuestionRequest : IRequest<GetPreviousQuestionResponse>
{
    [JsonIgnore]
    public long QuestionId { get; set; }
  //  public bool IsReverseFlow { get; set; } // add this if you want reverse cleanup
}

public class GetPreviousQuestionHandler : IRequestHandler<GetPreviousQuestionRequest, GetPreviousQuestionResponse>
{
    private readonly INovaHealthDbContext _novaHealthDbContext;
    private readonly IHttpContextAccessor _httpContextAccessor;

    public GetPreviousQuestionHandler(INovaHealthDbContext novaHealthDbContext, IHttpContextAccessor httpContextAccessor)
    {
        _novaHealthDbContext = novaHealthDbContext;
        _httpContextAccessor = httpContextAccessor;
    }

    public async Task<GetPreviousQuestionResponse> Handle(GetPreviousQuestionRequest request, CancellationToken cancellationToken)
    {
        // fetch session from header
        string sessionId = _httpContextAccessor.HttpContext?.Request.Headers.TryGetValue("ClientId", out var values)
            == true ? values.ToString() : null;

        if (string.IsNullOrEmpty(sessionId))
            throw new Exception("SessionId (ClientId) is required.");
        

        // get patient’s current answer
        var currentAnswer = await _novaHealthDbContext.PatientQuestionAnswers.Include(a => a.PatientAnswers)
            .Where(pqa => pqa.SessionId == sessionId && pqa.IsDeleted==false )
            .OrderByDescending(x=>x.CreatedDate) 
            .FirstOrDefaultAsync(cancellationToken);

        if (currentAnswer == null)
            throw new NotFoundException("Patient answer not found.");


        // Mark current answer deleted
        currentAnswer.IsDeleted = true;

        // Mark all child answers deleted
        foreach (var patientAnswer in currentAnswer.PatientAnswers)
        {
            patientAnswer.IsDeleted = true;
        }

        // Save changes
        await _novaHealthDbContext.SaveChangesAsync(cancellationToken);

        var previousQuestion = await _novaHealthDbContext.PatientQuestionAnswers
         .Where(pqa => pqa.SessionId == sessionId && pqa.Id < currentAnswer.Id)
         .OrderByDescending(pqa => pqa.Id) 
         .FirstOrDefaultAsync(cancellationToken);

        if (currentAnswer == null)
            throw new NotFoundException("Patient answer not found.");

        if(previousQuestion==null)
            throw new NotFoundException("Previous Question not found.");



        var layoutId = await _novaHealthDbContext.Questions
            .Where(q => q.Id == currentAnswer.QuestionId)
            .Select(q => q.Questionnaire.QuestionnaireGlobalLayoutId)
            .FirstOrDefaultAsync(cancellationToken);

        // fetch question
        var question = await _novaHealthDbContext.Questions
            .Include(x => x.QuestionType)
            .Include(q => q.Answers)
            .Include(q => q.QuestionProducts)
            .FirstOrDefaultAsync(q => q.Id == currentAnswer.QuestionId && !q.IsDeleted, cancellationToken)
            ?? throw new NotFoundException("Question not found.");

        if(question.QuestionType.Type.ToLower()=="auth")
            throw new NotFoundException("Previous Question not found.");

        // fetch layout settings
        var header = await _novaHealthDbContext.LayoutHeaderSettings.AsNoTracking()
            .FirstOrDefaultAsync(x => x.LayoutId== layoutId, cancellationToken);
        var footer = await _novaHealthDbContext.LayoutFooterSettings.AsNoTracking()
            .FirstOrDefaultAsync(x => x.LayoutId == layoutId, cancellationToken);
        var answerSettings = await _novaHealthDbContext.LayoutAnswerSettings.AsNoTracking()
            .FirstOrDefaultAsync(x => x.LayoutId == layoutId, cancellationToken);
        var title = await _novaHealthDbContext.LayoutTitleSettings.AsNoTracking()
            .FirstOrDefaultAsync(x => x.LayoutId == layoutId, cancellationToken);

        if (header == null && footer == null && answerSettings == null && title == null)
            throw new Exception($"No layout settings found for LayoutId {layoutId}");

        return new GetPreviousQuestionResponse
        {
            QuestionOptionResponse = MapQuestion(question, currentAnswer , previousQuestion.QuestionId),
            LayoutHeaderSetting = MapHeader(header),
            LayoutFooterSetting = MapFooter(footer),
            LayoutAnswerSetting = MapAnswer(answerSettings),
            LayoutTitleSetting = MapTitle(title)
        };
    }

    private static GetQuestionByIdResponse MapQuestion(Domain.Entities.Question question, PatientQuestionAnswer? currentAnswer, long? id)
    {
        var selectedAnswerIds = currentAnswer?.PatientAnswers.Select(pa => pa.AnswerOptionId).ToHashSet() ?? new HashSet<long>();
        return new GetQuestionByIdResponse
        {
            Id = question.Id,
            QuestionnaireId = question.QuestionnaireId,
            Title = question.Title,
            Name = question.Name,
            QuestionType = question.QuestionType.Type,
            NextQuestionId = question.NextQuestionId,
            QuestionSpecialVisitId = question.QuestionSpecialVisitId,
            QuestionTypeId = question.QuestionTypeId,
            PreviousQuestionId=id,
            AnswerText = currentAnswer?.AnswerText,

            AnswerOptions = question.Answers?.Select(a => new GetAnswerOptionResponse
            {
                Id = a.Id,
                Text = a.Text,
                Priority = a.Priority,
                NextQuestionId = a.NextQuestionId,
                Flag = a.Flag,

                // patient’s selection info
                Selected = selectedAnswerIds.Contains(a.Id),
                FileUrl = currentAnswer?.FileUrl,
            
            }).ToList(),
            ProductIds = question.QuestionProducts?
                .Select(qp => qp.ProductId)
                .Where(id => id.HasValue)
                .Select(id => id.Value)
                .ToList()
        };
    }

    private static LayoutHeaderSettingResponse MapHeader(LayoutHeaderSetting? header) =>
        header == null ? new LayoutHeaderSettingResponse() : new LayoutHeaderSettingResponse
        {
            NavbarLeftRadius = header.NavbarLeftRadius,
            HeaderBackgroundColor = header.HeaderBackgroundColor,
            HeaderLogo = header.HeaderLogo,
            CustomProgressBarSegments = header.CustomProgressBarSegments,
            BackButtonGlobal = header.BackButtonGlobal,
            BackButtonOnlyCurrent = header.BackButtonOnlyCurrent,
            ProgressBarColor = header.ProgressBarColor,
            ProgressBarBackgroundColor = header.ProgressBarBackgroundColor,
            BackButtonColor = header.BackButtonColor,
            HeaderTextColor = header.HeaderTextColor,
            ShowHelpButton = header.ShowHelpButton,
            HelpButtonSupportHours = header.HelpButtonSupportHours,
            HelpButtonColor = header.HelpButtonColor,
            HelpButtonTextColor = header.HelpButtonTextColor
        };

    private static LayoutFooterSettingResponse MapFooter(LayoutFooterSetting? footer) =>
        footer == null ? new LayoutFooterSettingResponse() : new LayoutFooterSettingResponse
        {
            LayoutId = footer.LayoutId,
            ShowFooter = footer.ShowFooter,
            PrimaryTextColor = footer.PrimaryTextColor,
            SecondaryTextColor = footer.SecondaryTextColor,
            DividerColor = footer.DividerColor,
            BackgroundColor = footer.BackgroundColor,
            FooterLogo = footer.FooterLogo,
            CompanyName = footer.CompanyName,
            PhoneNumber = footer.PhoneNumber,
            EmailAddress = footer.EmailAddress,
            HelpCenterURL = footer.HelpCenterURL,
            CopyrightText = footer.CopyrightText,
            ShowFooterSocialIcons = footer.ShowFooterSocialIcons,
            FacebookURL = footer.FacebookURL,
            InstagramURL = footer.InstagramURL,
            TwitterURL = footer.TwitterURL,
            LinkedInURL = footer.LinkedInURL
        };

    private static LayoutAnswerSettingResponse MapAnswer(LayoutAnswerSetting? answer) =>
        answer == null ? new LayoutAnswerSettingResponse() : new LayoutAnswerSettingResponse
        {
            AnswerBackgroundColor = answer.AnswerBackgroundColor,
            AnswerTextColor = answer.AnswerTextColor,
            AnswerHighlightColor = answer.AnswerHighlightColor,
            AnswerOutlineColor = answer.AnswerOutlineColor
        };

    private static LayoutTitleSettingResponse MapTitle(LayoutTitleSetting? title) =>
        title == null ? new LayoutTitleSettingResponse() : new LayoutTitleSettingResponse
        {
            LayoutId = title.LayoutId,
            PreHeader = title.PreHeader,
            ShowPreHeader = title.ShowPreHeader,
            PreHeaderColor = title.PreHeaderColor,
            MainHeader = title.MainHeader,
            ShowMainHeader = title.ShowMainHeader,
            MainHeaderColor = title.MainHeaderColor,
            SubHeader = title.SubHeader,
            ShowSubHeader = title.ShowSubHeader,
            SubHeaderColor = title.SubHeaderColor,
            Banner = title.Banner,
            ShowBanner = title.ShowBanner,
            BannerTextColor = title.BannerTextColor,
            BannerBGColor = title.BannerBGColor,
            ShowBannerIcon = title.ShowBannerIcon,
            BannerIconColor = title.BannerIconColor
        };
}
