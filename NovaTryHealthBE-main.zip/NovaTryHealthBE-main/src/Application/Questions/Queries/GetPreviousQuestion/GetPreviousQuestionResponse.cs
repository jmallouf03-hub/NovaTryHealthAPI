﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NovaHealth.Application.Questions.Queries.GetPreviousQuestion
{
    public class GetPreviousQuestionResponse
    {

        public GetQuestionByIdResponse QuestionOptionResponse { get; set; } = new();
        public LayoutHeaderSettingResponse LayoutHeaderSetting { get; set; } = new();

        public LayoutFooterSettingResponse LayoutFooterSetting { get; set; } = new();

        public LayoutAnswerSettingResponse LayoutAnswerSetting { get; set; } = new();

        public LayoutTitleSettingResponse LayoutTitleSetting { get; set; } = new();
    }


    public class LayoutHeaderSettingResponse
    {
        public string? NavbarLeftRadius { get; set; }
        public string? HeaderBackgroundColor { get; set; }
        public string? HeaderLogo { get; set; }
        public string? CustomProgressBarSegments { get; set; }
        public bool BackButtonGlobal { get; set; }
        public bool BackButtonOnlyCurrent { get; set; }
        public string? ProgressBarColor { get; set; }
        public string? ProgressBarBackgroundColor { get; set; }
        public string? BackButtonColor { get; set; }
        public string? HeaderTextColor { get; set; }
        public bool ShowHelpButton { get; set; }
        public string? HelpButtonSupportHours { get; set; }
        public string? HelpButtonColor { get; set; }
        public string? HelpButtonTextColor { get; set; }
    }


    public class LayoutFooterSettingResponse
    {
        public long LayoutId { get; set; }
        public bool ShowFooter { get; set; }
        public string? PrimaryTextColor { get; set; }
        public string? SecondaryTextColor { get; set; }
        public string? DividerColor { get; set; }
        public string? BackgroundColor { get; set; }
        public string? FooterLogo { get; set; }
        public string? CompanyName { get; set; }
        public string? PhoneNumber { get; set; }
        public string? EmailAddress { get; set; }
        public string? HelpCenterURL { get; set; }
        public string? CopyrightText { get; set; }
        public bool ShowFooterSocialIcons { get; set; }
        public string? FacebookURL { get; set; }
        public string? InstagramURL { get; set; }
        public string? TwitterURL { get; set; }
        public string? LinkedInURL { get; set; }
    }
    public class LayoutAnswerSettingResponse
    {
        //  public int? QuestionId { get; set; }
        public string? AnswerBackgroundColor { get; set; }
        public string? AnswerTextColor { get; set; }
        public string? AnswerHighlightColor { get; set; }
        public string? AnswerOutlineColor { get; set; }
    }
    public class LayoutTitleSettingResponse
    {
        public long LayoutId { get; set; }
        public string? PreHeader { get; set; }
        public bool ShowPreHeader { get; set; } = false;
        public string? PreHeaderColor { get; set; }

        public string? MainHeader { get; set; }
        public string? ShowMainHeader { get; set; }
        public string? MainHeaderColor { get; set; }

        public string? SubHeader { get; set; }
        public bool ShowSubHeader { get; set; }
        public string? SubHeaderColor { get; set; }

        public string? Banner { get; set; }
        public bool ShowBanner { get; set; }
        public string? BannerTextColor { get; set; }

        public string? BannerBGColor { get; set; }

        public bool ShowBannerIcon { get; set; }
        public string? BannerIconColor { get; set; }

    }



    public class GetQuestionByIdResponse
    {
        public long Id { get; set; }
        public long QuestionnaireId { get; set; }
        public string Title { get; set; } = null!;
        public string Name { get; set; } = null!;
        public long QuestionTypeId { get; set; }
        public long? NextQuestionId { get; set; }
        public string? QuestionType { get; set; }
        public long? QuestionSpecialVisitId { get; set; }
        public List<GetAnswerOptionResponse>? AnswerOptions { get; set; } = new List<GetAnswerOptionResponse>();
        public List<long>? ProductIds { get; set; } = new List<long>();
        public long? PreviousQuestionId { get; set; }
        public string? AnswerText { get; set; }

    }

    public class GetAnswerOptionResponse
    {
        public long Id { get; set; }
        public string? Text { get; set; } 
        public int Priority { get; set; }
        public long? NextQuestionId { get; set; }
        public string? Flag { get; set; } // e.g., "Disqualification", "Consent", "Details"

        public bool Selected { get; set; }
        public string? FileUrl { get; set; }
   
    }
}