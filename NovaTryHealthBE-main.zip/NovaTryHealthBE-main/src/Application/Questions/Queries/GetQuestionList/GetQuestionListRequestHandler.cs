﻿//using AutoMapper;
//using MediatR;
//using Microsoft.EntityFrameworkCore;
//using NovaHealth.Application.Common.Exceptions;
//using NovaHealth.Application.Common.Interfaces;
//using NovaHealth.Application.Common.Models;
//using AutoMapper.QueryableExtensions;
//using NovaHealth.Application.Common.Mappings;
//using System.Linq.Dynamic.Core;


//namespace NovaHealth.Application.Questions.Queries.GetQuestionList;

//public class GetQuestionListRequest : PaginationFilter, IRequest<PaginationResponse<GetQuestionListResponse>>
//{
//    public long QuestionnaireId { get; set; }

//}

//public class GetQuestionListRequestHandler : IRequestHandler<GetQuestionListRequest, PaginationResponse<GetQuestionListResponse>>
//{
//    private readonly INovaHealthDbContext _novaHealthDbContext;
//    private readonly IMapper _mapper;

//    public GetQuestionListRequestHandler(INovaHealthDbContext novaHealthDbContext, IMapper mapper)
//    {
//        _novaHealthDbContext = novaHealthDbContext;
//        _mapper = mapper;
//    }

//    public async Task<PaginationResponse<GetQuestionListResponse>> Handle(GetQuestionListRequest request, CancellationToken cancellationToken)
//    {
//        var question = _novaHealthDbContext.Questions
//                              .Include(q => q.Answers)
//                              .Include(q => q.Questionnaire)
//                              .Include(q => q.QuestionType)
//                              .AsNoTracking()
//              .Where(q => !q.IsDeleted && q.QuestionnaireId == request.QuestionnaireId)
//              .Select(q => new GetQuestionListResponse
//              {

//                  Id = q.Id,
//                  QuestionnaireId = q.QuestionnaireId,
//                  QuestionnaireTitle = q.Questionnaire.Title,
//                  QuestionTypeId = q.QuestionTypeId,
//                  QuestionType = q.QuestionType != null ? q.QuestionType.Type : null,
//                  TotalAnswer = q.Answers != null ? q.Answers.Count : 0,
//                  CreatedDate = q.CreatedDate,
//                  TotalProducts = q.Questionnaire != null ? q.Questionnaire.QuestionnaireProducts.Count : 0,

//              });
//        if (!question.Any())
//            throw new NotFoundException("Question not found.");

//        if (!string.IsNullOrEmpty(request.Filter))
//        {
//            question = question.Where(request.Filter);
//        }

//        if (!string.IsNullOrEmpty(request.OrderBy))
//        {
//            question = question.OrderBy(request.OrderBy);
//        }
//        else
//        {
//            question = question.OrderByDescending(x => x.Id);
//        }

//        return await question.ProjectTo<GetQuestionListResponse>(_mapper.ConfigurationProvider)
//                    .PaginatedListAsync(request.PageNumber, request.PageSize);
//    }
//}


using AutoMapper;
using MediatR;
using Microsoft.EntityFrameworkCore;
using NovaHealth.Application.Common.Exceptions;
using NovaHealth.Application.Common.Interfaces;
using NovaHealth.Application.Common.Models;
using AutoMapper.QueryableExtensions;
using NovaHealth.Application.Common.Mappings;
using System.Linq.Dynamic.Core;
using NovaHealth.Domain.Entities;

namespace NovaHealth.Application.Questions.Queries.GetQuestionList;

public class GetQuestionListRequest : PaginationFilter, IRequest<QuestionListWithTitleResponse>
{
    public long QuestionnaireId { get; set; }
}

public class GetQuestionListRequestHandler : IRequestHandler<GetQuestionListRequest, QuestionListWithTitleResponse>
{
    private readonly INovaHealthDbContext _novaHealthDbContext;
    private readonly IMapper _mapper;

    public GetQuestionListRequestHandler(INovaHealthDbContext novaHealthDbContext, IMapper mapper)
    {
        _novaHealthDbContext = novaHealthDbContext;
        _mapper = mapper;
    }

    public async Task<QuestionListWithTitleResponse> Handle(GetQuestionListRequest request, CancellationToken cancellationToken)
    {
        var baseQuery = _novaHealthDbContext.Questions
            .AsNoTracking()
            .Include(q => q.Answers)
            .Include(q => q.Questionnaire)
            .Include(q => q.QuestionType)
            .Where(q => !q.IsDeleted && q.QuestionnaireId == request.QuestionnaireId);

        if (!await baseQuery.AnyAsync(cancellationToken))
            throw new NotFoundException("Questions not found.");

        if (!string.IsNullOrEmpty(request.Filter))
        {
            baseQuery = baseQuery.Where(request.Filter);
        }

        if (!string.IsNullOrEmpty(request.OrderBy))
        {
            baseQuery = baseQuery.OrderBy(request.OrderBy);
        }
        else
        {
            baseQuery = baseQuery.OrderByDescending(q => q.Id);
        }

        var totalCount = await baseQuery.CountAsync(cancellationToken);

        var paginatedQuestions = await baseQuery
            .Skip((request.PageNumber - 1) * request.PageSize)
            .Take(request.PageSize)
            .Select(q => new GetQuestionListResponse
            {
                Id = q.Id,
                QuestionnaireId = q.QuestionnaireId,
                Name = q.Name,
                Title = q.Title, 
                QuestionSqNo = q.QuestionNumber ,

                QuestionTypeId = q.QuestionTypeId,
                QuestionType = q.QuestionType != null ? q.QuestionType.Type : null,
                questionSpecialVisitId =q.QuestionSpecialVisitId,
                CreatedDate = q.CreatedDate,
                TotalAnswer = q.Answers != null ? q.Answers.Count : 0,
                TotalProducts = q.QuestionProducts != null ? q.QuestionProducts.Count : 0
            })
            .ToListAsync(cancellationToken);

        var questionnaireTitle = baseQuery.FirstOrDefault()?.Questionnaire.Title ?? string.Empty;

        return new QuestionListWithTitleResponse
        {
            QuestionnaireTitle = questionnaireTitle,
            Questions = paginatedQuestions,
            TotalCount= totalCount,
            PageNumber = request.PageNumber,
            PageSize = request.PageSize

        };
    }
}
