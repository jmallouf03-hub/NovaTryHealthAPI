﻿using AutoMapper;

namespace NovaHealth.Application.Questions.Queries.GetQuestionList;

public class QuestionListWithTitleResponse
{
    public string QuestionnaireTitle { get; set; } = null!;

    public List<GetQuestionListResponse> Questions { get; set; } = new();
    public int PageNumber { get; set; }
    public int PageSize { get; set; }
    public int TotalCount { get; set; }
}

public class GetQuestionListResponse
{
    public long Id { get; set; }
    public long QuestionnaireId { get; set; }
    public string QuestionnaireTitle { get; set; } = null!;
    public string? Name { get; set; }
    public string Title { get; set; } = null!; 
    public long? questionSpecialVisitId { get; set; }    
    public long QuestionTypeId { get; set; }
    public string? QuestionType { get; set; }
    public DateTime CreatedDate { get; set; }
    public int TotalProducts { get; set; }
    public int? QuestionSqNo { get; set; }
    public int TotalAnswer { get; set; }


    public class Mapping : Profile
    {
        public Mapping()
        {
            CreateMap<GetQuestionListResponse, GetQuestionListResponse>();
        }
    }
}
