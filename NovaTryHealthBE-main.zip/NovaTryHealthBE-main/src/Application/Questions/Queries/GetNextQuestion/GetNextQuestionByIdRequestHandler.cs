﻿using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using NovaHealth.Application.Common.Exceptions;
using NovaHealth.Application.Common.FileStorage;
using NovaHealth.Application.Common.Interfaces;
using NovaHealth.Domain.Entities;
namespace NovaHealth.Application.Questions.Queries.GetNextQuestion;
public class GetNextQuestionByIdRequest : IRequest<GetNextQuestionResponse>
{
    public long? PatientId { get; set; } = null;
    public long? QuestionId { get; set; } = null;
    public string? AnswerText { get; set; } = null;
    public IFormFile? File { get; set; } = null;
    public List<long>? AnswerId { get; set; } = new List<long>();
    public long? QuestionnaireId { get; set; } = null;
    public long? NextQuestionId { get; set; } = null;

}

public class GetNextQuestionByIdRequestHandler : IRequestHandler<GetNextQuestionByIdRequest, GetNextQuestionResponse>
{
    private readonly INovaHealthDbContext _novaHealthDbContext;
    private readonly IHttpContextAccessor _httpContextAccessor;
    private readonly Func<FileStorageOption?, IFileStorageService> _fileStorageFunc;
    private readonly AppSettings _appSettings;
    public GetNextQuestionByIdRequestHandler(INovaHealthDbContext novaHealthDbContext, IHttpContextAccessor httpContextAccessor, Func<FileStorageOption?, IFileStorageService> fileStorageFunc, IOptions<AppSettings> appSettings)
    {
        _novaHealthDbContext = novaHealthDbContext;
        _httpContextAccessor = httpContextAccessor;
        _fileStorageFunc = fileStorageFunc;
        _appSettings = appSettings.Value;
    }
    public async Task<GetNextQuestionResponse> Handle(GetNextQuestionByIdRequest request, CancellationToken cancellationToken)
    {
        var fileStorageService = _fileStorageFunc(_appSettings.DefaultFileStorage);

        string sessionId = _httpContextAccessor.HttpContext?.Request.Headers.TryGetValue("ClientId", out var values) == true ? values.ToString() : null;

        if (request.QuestionId.HasValue)
        {
            var patientQuestionAnswer = new PatientQuestionAnswer
            {
                SessionId = sessionId,
                PatientId = request.PatientId,
                QuestionId = request.QuestionId.Value,
                AnswerText = request.AnswerText,
                CreatedDate = DateTime.Now
            };
            await _novaHealthDbContext.PatientQuestionAnswers.AddAsync(patientQuestionAnswer, cancellationToken);
            await _novaHealthDbContext.SaveChangesAsync(cancellationToken);

            if (request.File != null)
            {
                var fileUploadResponse = await fileStorageService.UploadAsync(new FileUploadRequest
                {
                    File = request.File,
                    FileTypeOption = FileTypeOption.ProfilePicture,
                    UserId = patientQuestionAnswer.Id,
                }, cancellationToken);

                patientQuestionAnswer.FileUrl = fileUploadResponse.SavedTo;

            }

            await _novaHealthDbContext.SaveChangesAsync(cancellationToken);

            if (request.AnswerId != null && request.AnswerId.Any())
            {
                foreach (var aid in request.AnswerId)
                {
                    var patientAnswer = new PatientAnswer
                    {
                        AnswerOptionId = aid,
                        PatientQuesionAnswerId = patientQuestionAnswer.Id,
                        CreatedDate = DateTime.Now
                    };

                    await _novaHealthDbContext.PatientAnswers.AddAsync(patientAnswer, cancellationToken);
                }

                await _novaHealthDbContext.SaveChangesAsync(cancellationToken);
            }

            if (request.PatientId.HasValue)
            {
                var patientQuestion = await _novaHealthDbContext.PatientQuestionAnswers
                                  .Where(pqa => pqa.SessionId == sessionId)
                                  .ToListAsync(cancellationToken);
                // update patient id in all related records
                foreach (var pq in patientQuestion)
                {
                    pq.PatientId = request.PatientId;
                }
                await _novaHealthDbContext.SaveChangesAsync(cancellationToken);

            }
        }
            // Get the question with its related products and variants
            var products = await _novaHealthDbContext.Questions.Include(x=>x.QuestionType)
                .Include(x => x.QuestionProducts)
                    .ThenInclude(qp => qp.Product)
                        .ThenInclude(p => p.Variants)
                .Where(x => x.Id == request.QuestionId)
                .FirstOrDefaultAsync(cancellationToken);


            if (request.PatientId != null && products != null && products.QuestionType.Type.ToLower()=="checkout")
            {
                var bookOrder = new BookOrder
                {
                    Guid = Guid.NewGuid(),
                    UserId = request.PatientId.Value,
                    Amount = 0,
                    PaymentStatus = PaymentStatusType.Completed,
                    CreatedDate = DateTime.Now,
                    SessionId = sessionId,
                    IsActive = true,
                    IsDeleted = false,
                    ProductOrders = new List<ProductOrder>()
                };

                decimal totalAmount = 0;

                // Get unique products that have at least one variant
                var uniqueProducts = products.QuestionProducts
                    .Select(qp => qp.Product)
                    .Where(p => p != null && p.Variants.Any())
                    .GroupBy(p => p.Id) // ensure uniqueness
                    .Select(g => g.First())
                    .ToList();

                foreach (var product in uniqueProducts)
                {
                    var variant = product.Variants.FirstOrDefault();
                    if (variant == null)
                        continue; // skip if no variant

                    var productOrder = new ProductOrder
                    {
                        ProductId = product.Id, // ✅ Use Product.Id here
                        Quantity = 1,
                        Amount = variant.Price,
                        BookOrder = bookOrder
                    };

                    totalAmount += productOrder.Amount;

                    bookOrder.ProductOrders.Add(productOrder);
                }

                // Set total amount
                bookOrder.Amount = totalAmount;

                await _novaHealthDbContext.BookOrders.AddAsync(bookOrder, cancellationToken);
                await _novaHealthDbContext.SaveChangesAsync(cancellationToken);
            }

        

        long nextQuestionId;
        long layoutId;

        if (request.NextQuestionId > 0)
        {
            nextQuestionId = request.NextQuestionId.Value;

            layoutId = await _novaHealthDbContext.Questions
                     .Where(q => q.Id == nextQuestionId)
                     .Select(q => q.Questionnaire.QuestionnaireGlobalLayoutId)
                     .FirstOrDefaultAsync(cancellationToken);
        }
        else
        {
            var currentQuestion = await _novaHealthDbContext.Questions
                                .FirstOrDefaultAsync(q => q.Id == request.QuestionId, cancellationToken);

            var answeredQuestionIds = await _novaHealthDbContext.PatientQuestionAnswers
                              .Where(pqa => pqa.SessionId == sessionId && pqa.IsDeleted==false)
                              .Select(pqa => pqa.QuestionId).ToListAsync(cancellationToken);

            var nextQuetionSeq = await _novaHealthDbContext.Questions
                             .Where(q => q.QuestionnaireId == request.QuestionnaireId &&
                              q.QuestionNumber > currentQuestion.QuestionNumber &&
                             !answeredQuestionIds.Contains(q.Id))
                             .OrderBy(q => q.QuestionNumber)
                             .FirstOrDefaultAsync(cancellationToken);

            if (nextQuetionSeq == null)
            {
                var checkout = await _novaHealthDbContext.Questions.Include(x => x.QuestionType).Include(q => q.Questionnaire).FirstOrDefaultAsync(x => x.QuestionType.Type.ToLower() == "finalcheckout");
                nextQuestionId = checkout.Id;
                layoutId = checkout.Questionnaire.QuestionnaireGlobalLayoutId;
            }
            else
            {
                var firstQuestion = await _novaHealthDbContext.Questions.Include(x => x.QuestionType)
                            .Include(q => q.Questionnaire)
                            .FirstOrDefaultAsync(q => q.QuestionnaireId == request.QuestionnaireId && q.QuestionNumber == nextQuetionSeq.QuestionNumber, cancellationToken);


                nextQuestionId = firstQuestion.Id;
                layoutId = firstQuestion.Questionnaire.QuestionnaireGlobalLayoutId;
            }
        }

        var question = await _novaHealthDbContext.Questions.Include(x => x.QuestionType)
                   .Include(q => q.Answers).Include(q => q.QuestionProducts)
                   .FirstOrDefaultAsync(q => q.Id == nextQuestionId && !q.IsDeleted, cancellationToken)
                   ?? throw new NotFoundException("Question not found.");

        // fetch all layout settings
        var header = await _novaHealthDbContext.LayoutHeaderSettings.AsNoTracking().FirstOrDefaultAsync(x => x.LayoutId == layoutId, cancellationToken);
        var footer = await _novaHealthDbContext.LayoutFooterSettings.AsNoTracking().FirstOrDefaultAsync(x => x.LayoutId == layoutId, cancellationToken);
        var answerSettings = await _novaHealthDbContext.LayoutAnswerSettings.AsNoTracking().FirstOrDefaultAsync(x => x.LayoutId == layoutId, cancellationToken);
        var title = await _novaHealthDbContext.LayoutTitleSettings.AsNoTracking().FirstOrDefaultAsync(x => x.LayoutId == layoutId, cancellationToken);

        if (header == null && footer == null && answerSettings == null && title == null)
            throw new Exception($"No layout settings found for LayoutId {layoutId}");

        return new GetNextQuestionResponse
        {
            QuestionOptionResponse = MapQuestion(question),
            LayoutHeaderSetting = MapHeader(header),
            LayoutFooterSetting = MapFooter(footer),
            LayoutAnswerSetting = MapAnswer(answerSettings),
            LayoutTitleSetting = MapTitle(title)
        };
    }

    private static GetQuestionByIdResponse MapQuestion(NovaHealth.Domain.Entities.Question question) =>
        new GetQuestionByIdResponse
        {
            Id = question.Id,
            QuestionnaireId = question.QuestionnaireId,
            Title = question.Title,
            Name = question.Name,
            QuestionType = question.QuestionType.Type,
            NextQuestionId = question.NextQuestionId,
            QuestionSpecialVisitId = question.QuestionSpecialVisitId,
            QuestionTypeId = question.QuestionTypeId,
            AnswerOptions = question.Answers?.Select(a => new GetAnswerOptionResponse
            {
                Id = a.Id,
                Text = a.Text,
                Priority = a.Priority,
                NextQuestionId = a.NextQuestionId,
                Flag = a.Flag
            }).ToList(),
            ProductIds = question.QuestionProducts?.Select(qp => qp.ProductId).Where(id => id.HasValue)       // null check
                  .Select(id => id.Value).ToList(),

            Products = question.QuestionProducts?
                .Where(qp => qp.Product != null && !qp.Product.IsDeleted)
                .Select(qp => new GetProductsByIdsResponse
                {
                    Id = qp.Product.Id,
                    DrugName = qp.Product.DrugName,
                    BrandName = qp.Product.BrandName,
                    ShortName = qp.Product.ShortName,
                    LabelerName = qp.Product.LabelerName,
                    GenericName = qp.Product.GenericName,
                    DosageForm = qp.Product.DosageForm,
                    ConsultOnlyPrice = qp.Product.ConsultOnlyPrice,
                    ProductType = qp.Product.ProductType,
                    RegularImageUrlFileName = qp.Product.Variants.Select(x => x.RegularImageUrlFileName).FirstOrDefault(),
                    RegularImageUrlFilePath = qp.Product.Variants.Select(x => x.RegularImageUrlFilePath).FirstOrDefault(),
                    TransparentImageUrlFileName = qp.Product.Variants.Select(x => x.TransparentImageUrlFileName).FirstOrDefault(),
                    TransparentImageUrlFilePath = qp.Product.Variants.Select(x => x.TransparentImageUrlFilePath).FirstOrDefault(),
                }).ToList(),

        };

    private static LayoutHeaderSettingResponse MapHeader(LayoutHeaderSetting? header) =>
        header == null ? new LayoutHeaderSettingResponse() : new LayoutHeaderSettingResponse
        {
            NavbarLeftRadius = header.NavbarLeftRadius,
            HeaderBackgroundColor = header.HeaderBackgroundColor,
            HeaderLogo = header.HeaderLogo,
            CustomProgressBarSegments = header.CustomProgressBarSegments,
            BackButtonGlobal = header.BackButtonGlobal,
            BackButtonOnlyCurrent = header.BackButtonOnlyCurrent,
            ProgressBarColor = header.ProgressBarColor,
            ProgressBarBackgroundColor = header.ProgressBarBackgroundColor,
            BackButtonColor = header.BackButtonColor,
            HeaderTextColor = header.HeaderTextColor,
            ShowHelpButton = header.ShowHelpButton,
            HelpButtonSupportHours = header.HelpButtonSupportHours,
            HelpButtonColor = header.HelpButtonColor,
            HelpButtonTextColor = header.HelpButtonTextColor
        };

    private static LayoutFooterSettingResponse MapFooter(LayoutFooterSetting? footer) =>
        footer == null ? new LayoutFooterSettingResponse() : new LayoutFooterSettingResponse
        {
            LayoutId = footer.LayoutId,
            ShowFooter = footer.ShowFooter,
            PrimaryTextColor = footer.PrimaryTextColor,
            SecondaryTextColor = footer.SecondaryTextColor,
            DividerColor = footer.DividerColor,
            BackgroundColor = footer.BackgroundColor,
            FooterLogo = footer.FooterLogo,
            CompanyName = footer.CompanyName,
            PhoneNumber = footer.PhoneNumber,
            EmailAddress = footer.EmailAddress,
            HelpCenterURL = footer.HelpCenterURL,
            CopyrightText = footer.CopyrightText,
            ShowFooterSocialIcons = footer.ShowFooterSocialIcons,
            FacebookURL = footer.FacebookURL,
            InstagramURL = footer.InstagramURL,
            TwitterURL = footer.TwitterURL,
            LinkedInURL = footer.LinkedInURL
        };

    private static LayoutAnswerSettingResponse MapAnswer(LayoutAnswerSetting? answer) =>
        answer == null ? new LayoutAnswerSettingResponse() : new LayoutAnswerSettingResponse
        {
            AnswerBackgroundColor = answer.AnswerBackgroundColor,
            AnswerTextColor = answer.AnswerTextColor,
            AnswerHighlightColor = answer.AnswerHighlightColor,
            AnswerOutlineColor = answer.AnswerOutlineColor
        };

    private static LayoutTitleSettingResponse MapTitle(LayoutTitleSetting? title) =>
        title == null ? new LayoutTitleSettingResponse() : new LayoutTitleSettingResponse
        {
            LayoutId = title.LayoutId,
            PreHeader = title.PreHeader,
            ShowPreHeader = title.ShowPreHeader,
            PreHeaderColor = title.PreHeaderColor,
            MainHeader = title.MainHeader,
            ShowMainHeader = title.ShowMainHeader,
            MainHeaderColor = title.MainHeaderColor,
            SubHeader = title.SubHeader,
            ShowSubHeader = title.ShowSubHeader,
            SubHeaderColor = title.SubHeaderColor,
            Banner = title.Banner,
            ShowBanner = title.ShowBanner,
            BannerTextColor = title.BannerTextColor,
            BannerBGColor = title.BannerBGColor,
            ShowBannerIcon = title.ShowBannerIcon,
            BannerIconColor = title.BannerIconColor
        };
}
