﻿using MediatR;
using Microsoft.AspNetCore.Http;

namespace NovaHealth.Application.Messaging.Commands.SendMessage;

public class SendMessageRequest : IRequest<SendMessageResponse>
{
    public long? MessageId { get; set; }

    public long SenderId { get; set; }

    public long ReceiverId { get; set; }

    public string? MessageContent { get; set; }

    public IFormFile? FileName { get; set; }

    public DateTimeOffset DateTime { get; set; }

    public bool SupportMessage { get; set; }

}
