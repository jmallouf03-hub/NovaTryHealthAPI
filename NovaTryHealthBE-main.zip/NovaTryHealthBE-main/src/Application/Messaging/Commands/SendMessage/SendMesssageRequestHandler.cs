﻿using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.SignalR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using NovaHealth.Application.Common.FileStorage;
using NovaHealth.Application.Common.Interfaces;
using NovaHealth.Application.SignalR.Interface;
using NovaHealth.Application.SignalR.Queries;
using NovaHealth.Domain.Entities;

namespace NovaHealth.Application.Messaging.Commands.SendMessage;

public class SendMessageRequestHandler : IRequestHandler<SendMessageRequest, SendMessageResponse>
{
    private readonly INovaHealthDbContext _novaHealthDbContext;
    private readonly IHubContext<NotificationHub> _hubContext;
    private readonly IUserConnectionManager _userConnectionManager;
    private readonly ILogger<SendMessageRequestHandler> _logger;
    private readonly Func<FileStorageOption?, IFileStorageService> _fileStorageFunc;
    private readonly AppSettings _appSettings;
    private readonly IHttpContextAccessor _httpContextAccessor;
    private readonly ITimelineService _timelineService;

    public SendMessageRequestHandler(
       INovaHealthDbContext novaHealthDbContext,
        Func<FileStorageOption?, IFileStorageService> fileStorageFunc,
        IOptions<AppSettings> appSettings,
        IHubContext<NotificationHub> hubContext,
        IUserConnectionManager userConnectionManager,
        ILogger<SendMessageRequestHandler> logger, IHttpContextAccessor httpContextAccessor, ITimelineService timelineService)
    {
        _novaHealthDbContext = novaHealthDbContext;
        _hubContext = hubContext;
        _userConnectionManager = userConnectionManager;
        _logger = logger;
        _fileStorageFunc = fileStorageFunc;
        _appSettings = appSettings.Value;
        _httpContextAccessor = httpContextAccessor;
        _timelineService = timelineService;
    }

    public async Task<SendMessageResponse> Handle(SendMessageRequest request, CancellationToken cancellationToken)

    {
        try
        {

            if (string.IsNullOrWhiteSpace(request.MessageContent) && request.FileName == null)
            {
                throw new ArgumentException("Please send a message or a file.");
            }

            var fileStorage = _fileStorageFunc(_appSettings.DefaultFileStorage);

            var sender = await _novaHealthDbContext.Users
                         .Include(u => u.UserRoles).ThenInclude(ur => ur.Role)
                         .Where(u => u.Id == request.SenderId)
                         .Select(u => new
                         {
                             u.FirstName,
                             u.LastName,
                             RoleType = u.UserRoles.Select(r => r.Role.RoleType).FirstOrDefault()
                         }).FirstOrDefaultAsync(cancellationToken);

            var senderFullName = $"{sender?.FirstName} {sender?.LastName}";
            // Create new message
            var message = new Message
            {
                MessageContent = request.MessageContent,
                CreatedBy = request.SenderId,
                CreatedDate = request.DateTime.UtcDateTime,
                SupportMessage = request.SupportMessage,
                IsActive = true,
                IsDeleted = false
            };

            _novaHealthDbContext.Messages.Add(message);
            await _novaHealthDbContext.SaveChangesAsync(cancellationToken);

            // Handle file upload
            if (request.FileName != null)
            {
                var fileResponse = await fileStorage.UploadAsync(new FileUploadRequest
                {
                    File = request.FileName,
                    FileTypeOption = FileTypeOption.Documents,
                    UserId = request.SenderId
                }, cancellationToken);

                message.FileName = fileResponse.OriginalName;
                message.FilePath = fileResponse.SavedTo;
                await _novaHealthDbContext.SaveChangesAsync(cancellationToken);
            }

            // Step 1: Determine parent and super parent
            long? parentId = request.MessageId;
            long superParentId = 0;

            if (request.MessageId.HasValue)
            {
                var threadInfo = await _novaHealthDbContext.MessageSenders
                                    .Where(x => x.MessageId == request.MessageId.Value)
                                    .Select(x => new { x.MessageId, x.SuperParentMessageId })
                                    .FirstOrDefaultAsync(cancellationToken);

                if (threadInfo != null)
                {
                    parentId = threadInfo.MessageId;
                    superParentId = threadInfo.SuperParentMessageId;
                }
            }

            // If new thread, assign current message as super parent
            if (superParentId == 0)
            {
                superParentId = message.Id;
            }

            // RoleType? receiverRoleType = null;

            // Step 2: Save sender entry
            _novaHealthDbContext.MessageSenders.Add(new MessageSender
            {
                SenderId = request.SenderId,
                MessageId = message.Id,
                ParentMessageId = parentId,
                SuperParentMessageId = superParentId,
                CreatedDate = request.DateTime.UtcDateTime,

                IsActive = true,
                IsDeleted = false
            });

            // Step 3: Get all participants from thread
            var threadParticipantIds = await _novaHealthDbContext.MessageRecipients
                                        .Where(x => x.SuperParentMessageId == superParentId)
                                        .Select(x => x.ReceiverId)
                                        .Union(_novaHealthDbContext.MessageSenders
                                          .Where(x => x.SuperParentMessageId == superParentId)
                                           .Select(x => x.SenderId)
                                        ).Distinct()
                .ToListAsync(cancellationToken);

            // Step 4: If this is a new message (no MessageId), fallback to ReceiverId
            var allReceiverIds = new List<long>();
            if (request.ReceiverId > 0 && request.ReceiverId != request.SenderId)
            {
                allReceiverIds.Add(request.ReceiverId);
            }

            // Add other participants
            allReceiverIds.AddRange(
                threadParticipantIds.Where(id => id != request.SenderId && id != request.ReceiverId)
            );

            // Step 5: Admin always last (if not sender and not already added)
            var adminId = await _novaHealthDbContext.Users
                        .Where(u => u.UserRoles.Any(ur => ur.Role.RoleType == RoleType.Admin))
                        .Select(u => u.Id)
                        .FirstOrDefaultAsync(cancellationToken);

            if (adminId > 0 && !allReceiverIds.Contains(adminId) && adminId != request.SenderId)
            {
                allReceiverIds.Add(adminId);
            }


            // Step 6: Save each recipient
            foreach (var receiverId in allReceiverIds)
            {
                _novaHealthDbContext.MessageRecipients.Add(new MessageRecipient
                {
                    ReceiverId = receiverId,
                    MessageId = message.Id,
                    ParentMessageId = parentId,
                    SuperParentMessageId = superParentId,
                    CreatedDate = request.DateTime.UtcDateTime,
                    IsRead = false,
                    IsActive = true,
                    IsDeleted = false
                });
            }

            await _novaHealthDbContext.SaveChangesAsync(cancellationToken);


            var firstReceiverId = allReceiverIds.FirstOrDefault();
            string receiverDisplay = string.Empty;
            string receiverName = string.Empty;
            if (firstReceiverId > 0)
            {
                var receiver = await _novaHealthDbContext.Users
                                 .Include(u => u.UserRoles).ThenInclude(ur => ur.Role)
                                 .Where(u => u.Id == firstReceiverId)
                                 .Select(u => new
                                 {
                                     u.FirstName,
                                     u.LastName,
                                     RoleType = u.UserRoles.Select(r => r.Role.RoleType).FirstOrDefault()
                                 }).FirstOrDefaultAsync(cancellationToken);


                if (receiver != null)
                {
                    receiverName = $"{receiver.FirstName} {receiver.LastName}";
                    receiverDisplay = $"{receiver.RoleType}-{receiver.FirstName} {receiver.LastName}";
                }
            }

            // -- Then your SignalR push logic for “ReceiveNotification” to connected users etc. --

            Notification? notification = null;
            var now = DateTime.UtcNow;
            long threadId = superParentId;

            // Get default admin ID
            var defaultAdminId = await _novaHealthDbContext.Users
                .Where(u => u.UserRoles.Any(ur => ur.Role.RoleType == RoleType.Admin))
                .Select(u => u.Id)
                .FirstOrDefaultAsync(cancellationToken);

            // Combine all participants (including admin if eligible)
            var notifiedUserIds = new HashSet<long>(allReceiverIds);
            bool adminShouldBeNotified = defaultAdminId > 0 &&
                                         defaultAdminId != request.SenderId &&
                                         (notifiedUserIds.Contains(defaultAdminId) || request.ReceiverId == defaultAdminId);

            if (adminShouldBeNotified)
            {
                notifiedUserIds.Add(defaultAdminId);
            }

            // Track users who still need notifications
            var usersToNotify = new List<long>();

            foreach (var userId in notifiedUserIds)
            {
                bool alreadyNotified = await _novaHealthDbContext.UserNotificationReferences
                    .AnyAsync(unr =>
                        unr.UserId == userId &&
                        unr.Notification.CreatedBy == request.SenderId &&
                        unr.Notification.NotificationType == NotificationType.Message &&
                        unr.NotificationTypeId == threadId,
                        cancellationToken);

                if (!alreadyNotified)
                {
                    usersToNotify.Add(userId);
                }
            }

            // Create notification only if needed
            if (usersToNotify.Any())
            {
                notification = new Notification
                {
                    NotificationType = NotificationType.Message,
                    Title = "New Message Received",
                    Message = $"{senderFullName} sent a message to {receiverName}",
                    CreatedBy = request.SenderId,
                    CreatedDate = now,
                    IsActive = true
                };

                await _novaHealthDbContext.Notifications.AddAsync(notification, cancellationToken);
                await _novaHealthDbContext.SaveChangesAsync(cancellationToken); // Get notification.Id
            }

            // Create notification references
            foreach (var userId in usersToNotify)
            {
                await _novaHealthDbContext.UserNotificationReferences.AddAsync(new UserNotificationReference
                {
                    UserId = userId,
                    NotificationId = notification!.Id, // safe because we just created it
                    NotificationTypeId = threadId,
                    CreatedDate = now,
                    IsActive = true,
                    IsRead = false,
                    IsDeleted = false
                }, cancellationToken);
            }

            // Final save
            if (usersToNotify.Any())
            {
                await _novaHealthDbContext.SaveChangesAsync(cancellationToken);
            }


            string senderDisplay = $"{sender.RoleType}-{sender.FirstName} {sender.LastName}";
            string senderType = $"{sender.RoleType}";
            // Step 7: Send SignalR notifications



            foreach (var receiverId in allReceiverIds)
            {
                var connectionIds = _userConnectionManager.GetUserConnections(receiverId.ToString());

                var unreadCount = await _novaHealthDbContext.MessageRecipients
                                    .Where(x => x.ReceiverId == receiverId && !x.IsRead)
                                    .CountAsync(cancellationToken);

                foreach (var connectionId in connectionIds)
                {
                    await _hubContext.Clients.Client(connectionId).SendAsync("ReceiveMessage", new
                    {
                        MessageContent = request.MessageContent,
                        MessageId = message.Id,
                        SenderName = senderFullName,
                        CreatedDate = message.CreatedDate,
                        UnreadCount = unreadCount,
                        SuperParentMessageId = superParentId,
                        FileName = message.FileName,
                        FilePath = message.FilePath,
                        SenderType = senderType,
                        SupportMessage = message.SupportMessage


                    });

                    if (notification != null)
                    {
                        await _hubContext.Clients.Client(connectionId).SendAsync("ReceiveNotification", new
                        {
                            NotificationId = notification.Id,
                            Title = notification.Title,
                            Message = notification.Message,
                            CreatedDate = notification.CreatedDate,
                            NotificationType = notification.NotificationType.ToString()
                        });
                    }
                }
            }

            var ipAddress = _httpContextAccessor.HttpContext?.Connection?.RemoteIpAddress?.ToString();

            if (_httpContextAccessor.HttpContext.Request.Headers.ContainsKey("X-Forwarded-For"))
            {
                ipAddress = _httpContextAccessor.HttpContext.Request.Headers["X-Forwarded-For"].FirstOrDefault();
            }




            //var firstReceiverId = allReceiverIds.FirstOrDefault();
            //string receiverDisplay = string.Empty;

            //if (firstReceiverId > 0)
            //{
            //    var receiver = await _novaHealthDbContext.Users
            //        .Include(u => u.UserRoles)
            //            .ThenInclude(ur => ur.Role)
            //        .Where(u => u.Id == firstReceiverId)
            //        .Select(u => new
            //        {
            //            u.FirstName,
            //            u.LastName,
            //            RoleType = u.UserRoles.Select(r => r.Role.RoleType).FirstOrDefault()
            //        })
            //        .FirstOrDefaultAsync(cancellationToken);

            //    if (receiver != null)
            //    {
            //        receiverDisplay = $"{receiver.RoleType}";
            //    }
            //}



            // Check if the same sender has already messaged this same receiver today
            var hasSenderAlreadyMessagedReceiverToday = await _novaHealthDbContext.TimelineEvents
                                                    .Where(x => x.UserId == request.SenderId &&
                                                                x.EventType == TimelineEventType.Message.ToString() &&
                                                                x.EventDate.Date == request.DateTime.UtcDateTime.Date &&
                                                                x.Metadata != null &&
                                                                x.Metadata.Contains($"\"receiverId\":{request.ReceiverId}"))
                                                    .AnyAsync(cancellationToken);

            // Check if the same receiver has already received message from same sender today
            var hasReceiverAlreadyReceivedFromSenderToday = await _novaHealthDbContext.TimelineEvents
                                                    .Where(x => x.UserId == request.ReceiverId &&
                                                                x.EventType == TimelineEventType.Message.ToString() &&
                                                                x.EventDate.Date == request.DateTime.UtcDateTime.Date &&
                                                                x.Metadata != null &&
                                                                x.Metadata.Contains($"\"senderId\":{request.SenderId}"))
                                                    .AnyAsync(cancellationToken);

            // Log sender's timeline
            if (!hasSenderAlreadyMessagedReceiverToday)
            {
                await _timelineService.LogTimelineEventAsync(
                    request.SenderId,
                    TimelineEventType.Message,
                    "Message Sent",
                    $"{senderDisplay} sent a message to {receiverDisplay}",
                    new { ipAddress, receiverId = request.ReceiverId, messageId = message.Id }
                );
            }

            // Log receiver's timeline
            if (!hasReceiverAlreadyReceivedFromSenderToday)
            {
                await _timelineService.LogTimelineEventAsync(
                    request.ReceiverId,
                    TimelineEventType.Message,
                    "Message Received",
                    $"{receiverDisplay} received a message from {senderDisplay}",
                    new { ipAddress, senderId = request.SenderId, messageId = message.Id }
                );
            }

            return new SendMessageResponse
            {
                MessageId = message.Id,
                SuperParentMessageId = superParentId,
                SenderName = senderFullName,
                SupportMessage = message.SupportMessage

            };
        }
        catch (ArgumentException ex)
        {
            _logger.LogWarning(ex, "Validation failed in SendMessageRequestHandler: {Message}", ex.Message);
            throw; // or return an error response
        }
        catch (DbUpdateException dbEx)
        {
            _logger.LogError(dbEx, "Database update failed in SendMessageRequestHandler");
            throw; // or handle gracefully
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Unexpected error in SendMessageRequestHandler");
            throw; // or handle gracefully
        }
    }
}