﻿namespace NovaHealth.Application.Messaging.Commands.SendMessage;

public class SendMessageResponse
{
    public long MessageId { get; set; }

    public long SuperParentMessageId { get; set; }

    public string? SenderName { get; set; }
    public bool SupportMessage { get; set; }

}
