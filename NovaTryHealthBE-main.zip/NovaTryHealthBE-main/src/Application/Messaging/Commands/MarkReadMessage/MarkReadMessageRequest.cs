﻿using MediatR;

namespace NovaHealth.Application.Messaging.Command.MarkReadMessage;

public class MarkReadMessageRequest : IRequest<bool>
{
    public long SenderId { get; set; }

    public long SuperParentMessageId { get; set; }
}