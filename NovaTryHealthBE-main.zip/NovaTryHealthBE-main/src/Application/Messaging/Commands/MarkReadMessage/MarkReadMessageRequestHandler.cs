﻿using MediatR;
using Microsoft.AspNetCore.SignalR;
using Microsoft.EntityFrameworkCore;
using NovaHealth.Application.Common.Interfaces;
using NovaHealth.Application.Messaging.Command.MarkReadMessage;
using NovaHealth.Application.SignalR.Interface;
using NovaHealth.Application.SignalR.Queries;

namespace NovaHealth.Application.Messaging.Commands.MarkReadMessage;
public class MarkReadMessageRequestHandler : IRequestHandler<MarkReadMessageRequest, bool>
{
    private readonly INovaHealthDbContext _novaHealthDbContext;
    private readonly IUserConnectionManager _userConnectionManager;
    private readonly IHubContext<NotificationHub> _hubContext;

    public MarkReadMessageRequestHandler(INovaHealthDbContext novaHealthDbContext, IHubContext<NotificationHub> hubContext, IUserConnectionManager userConnectionManager)
    {
        _novaHealthDbContext = novaHealthDbContext;
        _hubContext = hubContext;
        _userConnectionManager = userConnectionManager;
    }

    public async Task<bool> Handle(MarkReadMessageRequest request, CancellationToken cancellationToken)
    {
        var messages = await _novaHealthDbContext.MessageRecipients
                        .Include(x => x.Message)
                        .Where(x => x.SuperParentMessageId == request.SuperParentMessageId && x.ReceiverId == request.SenderId && x.IsDeleted == false)
                        .ToListAsync(cancellationToken);

        if (!messages.Any())
        {
            return false;
        }

        foreach (var message in messages)
        {
            message.IsRead = true;
        }

        await _novaHealthDbContext.SaveChangesAsync(cancellationToken);

        var recId = messages.First().ToString();

        if (recId != null)
        {
            var receiverConnectionIds = _userConnectionManager.GetUserConnections(recId);

            if (receiverConnectionIds.Any())
            {
                foreach (var connectionId in receiverConnectionIds)
                {
                    var receiver = _hubContext.Clients.Client(connectionId);

                    if (receiver != null)
                    {
                        await receiver.SendAsync("ReceiveMessageCountUpdate", new
                        {
                            MessageCount = messages.Count
                        });
                    }
                }
            }
        }

        return true;
    }
}