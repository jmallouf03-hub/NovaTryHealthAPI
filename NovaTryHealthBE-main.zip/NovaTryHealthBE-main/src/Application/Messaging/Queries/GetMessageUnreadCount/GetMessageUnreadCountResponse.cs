﻿namespace NovaHealth.Application.Messaging.Queries.GetMessageUnreadCount;

public class GetMessageUnreadCountResponse
{
    public int UnreadMessageCount { get; set; }
}