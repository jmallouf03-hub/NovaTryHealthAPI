﻿using MediatR;
using Microsoft.AspNetCore.SignalR;
using Microsoft.EntityFrameworkCore;
using NovaHealth.Application.Common.Interfaces;
using NovaHealth.Application.Messaging.Queries.GetMessageUnreadCount;
using NovaHealth.Application.SignalR.Queries;
using System.Text.Json.Serialization;

namespace NovaHealth.Application.Messaging.Queries.GetUnreadMessageCount;

public record GetMessageUnreadCountRequest : IRequest<GetMessageUnreadCountResponse>
{
    [JsonIgnore] public long UserId { get; set; }
}

public class GetMessageUnreadCountRequestHandler : IRequestHandler<GetMessageUnreadCountRequest, GetMessageUnreadCountResponse>
{
    private readonly INovaHealthDbContext _novaHealthDbContext;
    private readonly IHubContext<NotificationHub> _hubContext;

    public GetMessageUnreadCountRequestHandler(INovaHealthDbContext novaHealthDbContext, IHubContext<NotificationHub> hubContext)
    {
        _hubContext = hubContext;
        _novaHealthDbContext = novaHealthDbContext;
    }

    public async Task<GetMessageUnreadCountResponse> Handle(GetMessageUnreadCountRequest request, CancellationToken cancellationToken)
    {
        var unreadMessageCount = await _novaHealthDbContext.MessageRecipients
                                .Where(recipient => recipient.ReceiverId == request.UserId && recipient.IsRead == false)
                                .CountAsync(cancellationToken);


        await _hubContext.Clients.User(request.UserId.ToString())
            .SendAsync("ReceiveNotificationCountUpdate", unreadMessageCount);

        return new GetMessageUnreadCountResponse
        {
            UnreadMessageCount = unreadMessageCount
        };
    }
}