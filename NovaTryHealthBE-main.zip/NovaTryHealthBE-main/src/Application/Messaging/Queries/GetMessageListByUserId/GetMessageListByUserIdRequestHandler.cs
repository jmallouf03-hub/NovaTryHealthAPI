﻿using MediatR;
using Newtonsoft.Json;
using AutoMapper;
using System.Linq.Dynamic.Core;
using NovaHealth.Application.Common.Interfaces;
using NovaHealth.Application.Common.Models;
using Microsoft.EntityFrameworkCore;

namespace NovaHealth.Application.Messaging.Queries.GetMessageListByUserId;

public class GetMessageListByUserIdRequest : PaginationFilter, IRequest<List<GetMessageListByUserIdResponse>>
{
    [JsonIgnore] public long UserId { get; set; }
}

public class GetMessageListByUserIdRequestHandler : IRequestHandler<GetMessageListByUserIdRequest, List<GetMessageListByUserIdResponse>>
{
    private readonly INovaHealthDbContext _novaHealthDbContext;
    private readonly IMapper _mapper;

    public GetMessageListByUserIdRequestHandler(INovaHealthDbContext novaHealthDbContext, IMapper mapper)
    {
        _novaHealthDbContext = novaHealthDbContext;
        _mapper = mapper;
    }
    public async Task<List<GetMessageListByUserIdResponse>> Handle(GetMessageListByUserIdRequest request, CancellationToken cancellationToken)
    {
        var recipientMessagesQuery = from recipient in _novaHealthDbContext.MessageRecipients
                                     join message in _novaHealthDbContext.Messages
                                         on recipient.MessageId equals message.Id
                                     join sender in _novaHealthDbContext.MessageSenders
                                         on message.Id equals sender.MessageId
                                     join senderUser in _novaHealthDbContext.Users
                                         on sender.SenderId equals senderUser.Id
                                     join receiverUser in _novaHealthDbContext.Users
                                         on recipient.ReceiverId equals receiverUser.Id

                                     join senderUserRole in _novaHealthDbContext.UserRoles
                                         on senderUser.Id equals senderUserRole.UserId
                                     join senderRole in _novaHealthDbContext.Roles
                                         on senderUserRole.RoleId equals senderRole.Id

                                     join receiverUserRole in _novaHealthDbContext.UserRoles
                                         on receiverUser.Id equals receiverUserRole.UserId
                                     join receiverRole in _novaHealthDbContext.Roles
                                         on receiverUserRole.RoleId equals receiverRole.Id

                                     where
                                     (recipient.ReceiverId == request.UserId || sender.SenderId == request.UserId)
                                     &&
                                       (
                                         (request.UserId == sender.SenderId && !receiverUser.UserRoles.Any(r => r.Role.RoleType == RoleType.Admin)) ||
                                         (request.UserId == recipient.ReceiverId && !senderUser.UserRoles.Any(r => r.Role.RoleType == RoleType.Admin))
                                     )
                                     && (message.SupportMessage == false)
                                     group new
                                     {
                                         message,
                                         recipient,
                                         senderUser,
                                         receiverUser,
                                         sender,
                                         senderRole,
                                         receiverRole,
                                         senderUserRole,
                                         receiverUserRole

                                     }
                                     by recipient.SuperParentMessageId into grouped
                                     select new MessageLists
                                     {
                                         ReceiverIds = _novaHealthDbContext.MessageRecipients
                                                    .Where(r => r.MessageId == grouped.OrderByDescending(g => g.message.CreatedDate).Select(g => g.message.Id).FirstOrDefault())
                                                    .Select(r => r.ReceiverId)
                                                    .ToList(),
                                         SenderId = grouped.OrderByDescending(g => g.message.CreatedDate)
                                                      .Select(g => g.sender.SenderId)
                                                      .FirstOrDefault(),
                                         MessageId = grouped.OrderByDescending(g => g.message.CreatedDate)
                                                               .Select(g => g.message.Id)
                                                               .FirstOrDefault(),
                                         CreatedBy = grouped.OrderByDescending(g => g.message.CreatedDate)
                                                   .Select(g => g.message.CreatedBy)
                                                   .FirstOrDefault(),
                                         MessageContent = grouped.OrderByDescending(g => g.message.Id).Select(g => g.message.MessageContent).FirstOrDefault(),

                                         SenderName = grouped.OrderByDescending(g => g.message.CreatedDate).Select(g =>
                                                request.UserId == g.sender.SenderId
                                                    ? g.receiverUser.FirstName + " " + g.receiverUser.LastName
                                                    : g.senderUser.FirstName + " " + g.senderUser.LastName
                                            ).FirstOrDefault(),

                                         CreatedDate = grouped.OrderByDescending(g => g.message.CreatedDate).Select(g => g.message.CreatedDate).FirstOrDefault(),
                                         SuperParentMessageId = grouped.Key,


                                         SenderProfilePictureName = grouped.OrderByDescending(g => g.message.CreatedDate).Select(g =>
                                                          request.UserId == g.sender.SenderId
                                                              ? g.receiverUser.ProfilePictureName
                                                              : g.senderUser.ProfilePictureName
                                                    ).FirstOrDefault(),

                                         SenderProfilePicturePath = grouped.OrderByDescending(g => g.message.CreatedDate).Select(g =>
                                             request.UserId == g.sender.SenderId
                                                 ? g.receiverUser.ProfilePicturePath
                                                 : g.senderUser.ProfilePicturePath
                                                    ).FirstOrDefault(),

                                         RecieverName = grouped.OrderByDescending(g => g.message.CreatedDate)
                                                        .Select(g =>
                                                            request.UserId == g.sender.SenderId
                                                                ? g.receiverUser.FirstName + " " + g.receiverUser.LastName
                                                                : g.senderUser.FirstName + " " + g.senderUser.LastName
                                                        ).FirstOrDefault(),
                                         FileName = grouped.OrderByDescending(g => g.message.CreatedDate)
                                              .Select(g => g.message.FileName)
                                              .FirstOrDefault(),

                                         FilePath = grouped.OrderByDescending(g => g.message.CreatedDate)
                                              .Select(g => g.message.FilePath)
                                              .FirstOrDefault(),

                                         SenderType = grouped.OrderByDescending(g => g.message.CreatedDate)
                                                .Select(g => g.senderRole.RoleType.ToString())
                                                .FirstOrDefault(),

                                     };
        var messageList = await recipientMessagesQuery.ToListAsync(cancellationToken);

        TimeZoneInfo sourceZone = TimeZoneInfo.FindSystemTimeZoneById("UTC");

        // Destination: Local system timezone
        TimeZoneInfo localZone = TimeZoneInfo.Local;

        foreach (var message in messageList)
        {
            if (message.CreatedDate != null)
            {
                // Convert
                message.CreatedDate = TimeZoneInfo.ConvertTime(message.CreatedDate, sourceZone, localZone);
            }
        }

        var groupedByDate = messageList
                           .GroupBy(m => DateOnly.FromDateTime(m.CreatedDate.Date))
                           .OrderByDescending(g => g.Key)
                           .Select(g => new GetMessageListByUserIdResponse
                           {
                               Date = g.Key,
                               MessageList = g.ToList()
                           })
                             .ToList();

        return groupedByDate;
    }
}