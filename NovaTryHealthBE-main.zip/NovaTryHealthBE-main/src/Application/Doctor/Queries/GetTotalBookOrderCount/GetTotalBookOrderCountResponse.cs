﻿namespace NovaHealth.Application.Doctor.Queries.GetTotalBookOrderCount;

public class GetTotalBookOrderCountResponse
{
    public int TotalBookOrderCount { get; set; }

    public int TotalPendingStatus { get; set; }
    public int TotalCompletedStatus { get; set; }

    public int TotalFailedStatus { get; set; }

    public int TotalCanceledStatus { get; set; }

}
