﻿using MediatR;
using Microsoft.EntityFrameworkCore;
using NovaHealth.Application.Common.Interfaces;

namespace NovaHealth.Application.Doctor.Queries.GetTotalBookOrderCount;
public class GetTotalBookOrderCountRequest : IRequest<GetTotalBookOrderCountResponse> { }

public class GetTotalBookOrderCountRequestHandler : IRequestHandler<GetTotalBookOrderCountRequest, GetTotalBookOrderCountResponse>
{
    private readonly INovaHealthDbContext _novaHealthDbContext;

    public GetTotalBookOrderCountRequestHandler(INovaHealthDbContext novaHealthDbContext)
    {
        _novaHealthDbContext = novaHealthDbContext;

    }
    public async Task<GetTotalBookOrderCountResponse> Handle(GetTotalBookOrderCountRequest request, CancellationToken cancellationToken)
    {

        var query = _novaHealthDbContext.BookOrders
                    .Where(x => !x.IsDeleted && x.IsActive);
        //.CountAsync(cancellationToken);

        var totalCount = await query.CountAsync(cancellationToken);

        var totalPending = await query.CountAsync(x => x.PaymentStatus == PaymentStatusType.Pending, cancellationToken);
        var totalCompleted = await query.CountAsync(x => x.PaymentStatus == PaymentStatusType.Completed, cancellationToken);
        var totalFailed = await query.CountAsync(x => x.PaymentStatus == PaymentStatusType.Failed, cancellationToken);
        var totalCanceled = await query.CountAsync(x => x.PaymentStatus == PaymentStatusType.Canceled, cancellationToken);



        return new GetTotalBookOrderCountResponse
        {
            TotalBookOrderCount = totalCount,
            TotalPendingStatus = totalPending,
            TotalCompletedStatus = totalCompleted,
            TotalFailedStatus = totalFailed,
            TotalCanceledStatus = totalCanceled
        };
    }
}