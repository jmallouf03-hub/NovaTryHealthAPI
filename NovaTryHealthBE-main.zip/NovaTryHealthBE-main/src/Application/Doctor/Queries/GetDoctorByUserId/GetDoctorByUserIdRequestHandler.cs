﻿using MediatR;
using Microsoft.EntityFrameworkCore;
using NovaHealth.Application.Common.Exceptions;
using NovaHealth.Application.Common.Interfaces;
using NovaHealth.Domain.Entities;
using System.Text.Json.Serialization;
using Twilio.Types;

namespace NovaHealth.Application.Doctor.Queries.GetDoctorByUserId;

public record GetDoctorByUserIdRequest : IRequest<GetDoctorByUserIdResponse>
{
    [JsonIgnore] public long UserId { get; set; }
}

public class GetDoctorByUserIdRequestHandler : IRequestHandler<GetDoctorByUserIdRequest, GetDoctorByUserIdResponse>
{
    private readonly INovaHealthDbContext _novaHealthDbContext;

    public GetDoctorByUserIdRequestHandler(INovaHealthDbContext novaHealthDbContext)
    {
        _novaHealthDbContext = novaHealthDbContext;
    }

    public async Task<GetDoctorByUserIdResponse> Handle(GetDoctorByUserIdRequest request, CancellationToken cancellationToken)
    {
        var doctorProfile = await _novaHealthDbContext.Users
                             .Include(u => u.UserAddresses).ThenInclude(a => a.State).Include(u => u.DoctorCategories)
                             .ThenInclude(dc => dc.Category)
                             .FirstOrDefaultAsync(u => u.Id == request.UserId && u.IsActive &&
                             u.UserRoles.Any(ur => ur.Role.RoleType == RoleType.Doctor), cancellationToken);

        if (doctorProfile == null)
        {
            throw new NotFoundException($"Doctor profile with UserId {request.UserId} not found.");
        }

        // Get the single address
        var address = doctorProfile.UserAddresses.FirstOrDefault();

        var response = new GetDoctorByUserIdResponse
        {
            UserId = doctorProfile.Id,
            FirstName = doctorProfile.FirstName,
            LastName = doctorProfile.LastName,
            Email = doctorProfile.Email,
            PhoneNumber = doctorProfile.PhoneNumber,
            DateOfBirth = doctorProfile.DateOfBirth,
            Gender = doctorProfile.Gender,
            Address1 = address?.Address1,
            Address2 = address?.Address2,
            City = address?.City,
            StateId = address?.StateId ?? 0,
            StateName = address?.State?.StateName,
            ZipCode = address?.ZipCode,
            ProfilePictureName = doctorProfile.ProfilePictureName,
            ProfilePicturePath = doctorProfile.ProfilePicturePath,
            Categories = doctorProfile.DoctorCategories
                                .Select(dc => new CategoryDto
                                {
                                    Id = dc.Category.Id,
                                    Name = dc.Category.Name
                                }).ToList()
        };

        return response;
    }
}
