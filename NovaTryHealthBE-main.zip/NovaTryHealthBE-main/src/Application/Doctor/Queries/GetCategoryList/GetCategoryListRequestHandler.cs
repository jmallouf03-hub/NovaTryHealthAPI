﻿using AutoMapper;
using AutoMapper.QueryableExtensions;
using MediatR;
using Microsoft.EntityFrameworkCore;
using NovaHealth.Application.Common.Interfaces;
using NovaHealth.Application.Common.Mappings;
using NovaHealth.Application.Common.Models;
using System.Linq.Dynamic.Core;

namespace NovaHealth.Application.Doctor.Queries.GetCategoryList;

public class GetCategoryListRequest : PaginationFilter, IRequest<PaginationResponse<GetCategoryListResponse>> { }

public class GetCategoryListRequestHandler : IRequestHandler<GetCategoryListRequest, PaginationResponse<GetCategoryListResponse>>
{
    private readonly INovaHealthDbContext _novaHealthDbContext;
    private readonly IMapper _mapper;

    public GetCategoryListRequestHandler(INovaHealthDbContext novaHealthDbContext, IMapper mapper)
    {
        _novaHealthDbContext = novaHealthDbContext;
        _mapper = mapper;
    }

    public async Task<PaginationResponse<GetCategoryListResponse>> Handle(GetCategoryListRequest request, CancellationToken cancellationToken)
    {

        var query = _novaHealthDbContext.Categories
                      .AsNoTracking()
                      .Select(x => new GetCategoryListResponse
                      {
                          Id = x.Id,
                          Name = x.Name,
                      });

        // Apply filter if provided
        if (!string.IsNullOrEmpty(request.Filter))
        {
            query = query.Where(request.Filter);
        }

        // Apply order
        if (!string.IsNullOrEmpty(request.OrderBy))
        {
            query = query.OrderBy(request.OrderBy);
        }
        else
        {
            query = query.OrderBy(x => x.Id);
        }

        return await query.ProjectTo<GetCategoryListResponse>(_mapper.ConfigurationProvider)
                 .PaginatedListAsync(request.PageNumber, request.PageSize);
    }
}