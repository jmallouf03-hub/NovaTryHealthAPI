﻿using AutoMapper;

namespace NovaHealth.Application.Doctor.Queries.GetCategoryList;

public class GetCategoryListResponse
{
    public long Id { get; set; }
    public string Name { get; set; } = null!;

    public class Mapping : Profile
    {
        public Mapping()
        {
            CreateMap<GetCategoryListResponse, GetCategoryListResponse>();
        }
    }
}