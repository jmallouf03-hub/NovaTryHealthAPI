﻿using AutoMapper;

namespace NovaHealth.Application.Doctor.Queries.GetDoctorList;

public class GetDoctorListResponse
{
    public long? UserId { get; set; }
    public string? DoctorName { get; set; }

    public string? Email { get; set; }

    public string? PhoneNumber { get; set; }

    public DateTime? DateOfBirth { get; set; }

    public GenderTypeOption Gender { get; set; }

    public bool IsDisabledByAdmin { get; set; }

    public string? ProfilePictureName { get; set; }

    public string? ProfilePicturePath { get; set; }

    public long SuperParentMessageId { get; set; }

    public long MessageId { get; set; }

    public int UnreadMessageCount { get; set; }


    //public string? Address1 { get; set; } 

    //public string? Address2 { get; set; }

    //public string? City { get; set; } 

    //public int StateId { get; set; }

    //public string? ZipCode { get; set; } 

    public List<CategoryDto> Categories { get; set; } = new();
    public class Mapping : Profile
    {
        public Mapping()
        {
            CreateMap<GetDoctorListResponse, GetDoctorListResponse>();
        }
    }
}
public class CategoryDto
{
    public long Id { get; set; }
    public string Name { get; set; } = string.Empty;
}
