﻿using AutoMapper;
using AutoMapper.QueryableExtensions;
using MediatR;
using Microsoft.EntityFrameworkCore;
using NovaHealth.Application.Common.Interfaces;
using NovaHealth.Application.Common.Mappings;
using NovaHealth.Application.Common.Models;
using System.Linq.Dynamic.Core;

namespace NovaHealth.Application.Doctor.Queries.GetDoctorList;

public class GetDoctorListRequest : PaginationFilter, IRequest<PaginationResponse<GetDoctorListResponse>>
{
    public long UserId { get; set; }
}

public class GetDoctorListRequestHandler : IRequestHandler<GetDoctorListRequest, PaginationResponse<GetDoctorListResponse>>
{
    private readonly INovaHealthDbContext _novaHealthDbContext;
    private readonly IMapper _mapper;

    public GetDoctorListRequestHandler(INovaHealthDbContext novaHealthDbContext, IMapper mapper)
    {
        _novaHealthDbContext = novaHealthDbContext;
        _mapper = mapper;
    }
    public async Task<PaginationResponse<GetDoctorListResponse>> Handle(GetDoctorListRequest request, CancellationToken cancellationToken)
    {
        var isAdmin = await _novaHealthDbContext.Users
            .Where(u => u.Id == request.UserId && u.IsActive && !u.IsDeleted)
            .AnyAsync(u => u.UserRoles.Any(ur => ur.Role.RoleType == RoleType.Admin && ur.IsActive && !ur.IsDeleted), cancellationToken);

        var query = _novaHealthDbContext.Users
            .AsNoTracking()
            .Where(u => u.IsActive && !u.IsDeleted)
            .Where(u => u.UserRoles.Any(ur => ur.Role.RoleType == RoleType.Doctor && ur.IsActive && !ur.IsDeleted))
            .Where(u => isAdmin || u.IsDisabledByAdmin);

        var doctorQuery = query.Select(x => new GetDoctorListResponse
        {
            UserId = x.Id,
            DoctorName = x.FirstName + " " + x.LastName,
            Email = x.Email,
            PhoneNumber = x.PhoneNumber,
            Gender = x.Gender,
            DateOfBirth = x.DateOfBirth,
            IsDisabledByAdmin = x.IsDisabledByAdmin,
            ProfilePictureName = x.ProfilePictureName,
            ProfilePicturePath = x.ProfilePicturePath,
            Categories = x.DoctorCategories
                .Select(dc => new CategoryDto
                {
                    Id = dc.Category.Id,
                    Name = dc.Category.Name
                })
                .ToList(),

           SuperParentMessageId = (from recipient in _novaHealthDbContext.MessageRecipients
                                    join message in _novaHealthDbContext.Messages on recipient.MessageId equals message.Id
                                    join sender in _novaHealthDbContext.MessageSenders on message.Id equals sender.MessageId
                                    where (sender.SenderId == request.UserId && recipient.ReceiverId == x.Id) || (sender.SenderId == x.Id && recipient.ReceiverId == request.UserId) && message.SupportMessage == false
                                    select recipient.SuperParentMessageId
                                ).FirstOrDefault(),

            MessageId = (from recipient in _novaHealthDbContext.MessageRecipients
                         join message in _novaHealthDbContext.Messages on recipient.MessageId equals message.Id
                         join sender in _novaHealthDbContext.MessageSenders on message.Id equals sender.MessageId
                         where (sender.SenderId == request.UserId && recipient.ReceiverId == x.Id) || (sender.SenderId == x.Id && recipient.ReceiverId == request.UserId) && message.SupportMessage == false
                         orderby message.Id descending
                         select message.Id
                                ).FirstOrDefault()
        });

        if (!string.IsNullOrEmpty(request.Filter))
        {
            doctorQuery = doctorQuery.Where(request.Filter);
        }

        if (!string.IsNullOrEmpty(request.OrderBy))
        {
            doctorQuery = doctorQuery.OrderBy(request.OrderBy);
        }
        else
        {
            doctorQuery = doctorQuery.OrderByDescending(x => x.UserId);
        }

        return await doctorQuery.PaginatedListAsync(request.PageNumber, request.PageSize);
    }
}