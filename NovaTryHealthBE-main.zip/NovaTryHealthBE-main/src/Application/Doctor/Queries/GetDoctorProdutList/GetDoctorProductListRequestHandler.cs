﻿using AutoMapper;
using MediatR;
using Microsoft.EntityFrameworkCore;
using NovaHealth.Application.Common.Interfaces;
using NovaHealth.Application.Common.Models;
using NovaHealth.Application.Common.Mappings;
using System.Linq.Dynamic.Core;
using System.Text.Json.Serialization;

namespace NovaHealth.Application.Doctor.Queries.GetDoctorProdutList;
public class GetDoctorProductListRequest : PaginationFilter, IRequest<PaginationResponse<GetDoctorProdcutListResponse>>
{
    [JsonIgnore] public long UserId { get; set; }
}

public class GetDoctorProductListRequestHandler : IRequestHandler<GetDoctorProductListRequest, PaginationResponse<GetDoctorProdcutListResponse>>
{
    private readonly INovaHealthDbContext _novaHealthDbContext;
    private readonly IMapper _mapper;

    public GetDoctorProductListRequestHandler(INovaHealthDbContext novaHealthDbContext, IMapper mapper)
    {
        _novaHealthDbContext = novaHealthDbContext;
        _mapper = mapper;
    }

    public async Task<PaginationResponse<GetDoctorProdcutListResponse>> Handle(GetDoctorProductListRequest request, CancellationToken cancellationToken)
    {
        // Get all doctor categories with their users
        //var doctorCategoryIds = _novaHealthDbContext.DoctorCategories
        //.Where(dc => dc.UserId == request.UserId)
        //.Select(dc => dc.CategoryId);

        var user = await _novaHealthDbContext.Users
                 .Include(u => u.UserRoles).ThenInclude(ur => ur.Role)
                 .FirstOrDefaultAsync(u => u.Id == request.UserId && !u.IsDeleted && u.IsActive, cancellationToken);

        if (user == null || !user.UserRoles.Any(ur => ur.Role.RoleType == RoleType.Doctor))
        {
            throw new Exception("Doctor not found or inactive.");
        }

        //var productsQuery = _novaHealthDbContext.Products
        //            .Where(p => p.CategoryId != null && doctorCategoryIds.Contains(p.CategoryId.Value))
        //            .Include(p => p.Category)   
        //            .Include(p => p.Variants)
        //            .Include(p => p.Ingredients)
        //            .AsNoTracking();

        var productsQuery = _novaHealthDbContext.Products
            .Where(p => !p.IsDeleted)
       .Include(p => p.Category)
       .Include(p => p.Variants)
       .Include(p => p.Ingredients)
       .AsNoTracking();

        // Project to DTO
        var query = productsQuery.Select(p => new GetDoctorProdcutListResponse
        {
            Id = p.Id,
            DrugName = p.DrugName,
            BrandName = p.BrandName,
            ShortName = p.ShortName,
            LabelerName = p.LabelerName,
            GenericName = p.GenericName,
            DosageForm = p.DosageForm,
            ConsultOnlyPrice = p.ConsultOnlyPrice,
            ProductType = p.ProductType,
            CreatedDate = p.CreatedDate,
            IsActive = p.IsActive,

            //CategoryName = p.Category.Name,
            //CategoryName = p.Category != null ? p.Category.Name : string.Empty,

            Variants = p.Variants.Select(v => new ProductVariantDto
            {
                Id = v.Id,
                ProductId = v.ProductId,
                Upc = v.Upc,
                Name = v.Name,
                Price = v.Price,
                ComparePrice = v.ComparePrice,
                Quantity = v.Quantity,
                QuantityUnit = v.QuantityUnit,
                Refills = v.Refills,
                Dose = v.Dose,
                Dosage = v.Dosage,
                Strength = v.Strength,
                Packing = v.Packing,
                Form = v.Form,
                RegularImageUrlFileName = v.RegularImageUrlFileName,
                RegularImageUrlFilePath = v.RegularImageUrlFilePath,
                TransparentImageUrlFileName = v.TransparentImageUrlFileName,
                TransparentImageUrlFilePath = v.TransparentImageUrlFilePath,
                VideoUrl = v.VideoUrl
            }).ToList(),
            Ingredients = p.Ingredients.Select(i => new ProductIngredientDto
            {
                Id = i.Id,
                ProductId = i.ProductId,
                Name = i.Name,
                Strength = i.Strength
            }).ToList()
        });

        // Apply filter if provided
        if (!string.IsNullOrEmpty(request.Filter))
        {
            query = query.Where(request.Filter);
        }

        // Apply ordering if provided
        if (!string.IsNullOrEmpty(request.OrderBy))
        {
            query = query.OrderBy(request.OrderBy);
        }

        // Paginate and return
        return await query.PaginatedListAsync(request.PageNumber, request.PageSize);
    }
}
