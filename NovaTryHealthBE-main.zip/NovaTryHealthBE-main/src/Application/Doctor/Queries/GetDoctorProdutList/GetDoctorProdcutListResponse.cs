﻿using AutoMapper;

namespace NovaHealth.Application.Doctor.Queries.GetDoctorProdutList;

public class GetDoctorProdcutListResponse
{
    public long? Id { get; set; }
    public string DrugName { get; set; } = null!;
    public string? BrandName { get; set; }
    public string? ShortName { get; set; }
    public string? LabelerName { get; set; }
    public string? GenericName { get; set; }
    public string? DosageForm { get; set; }
    public decimal? ConsultOnlyPrice { get; set; }
    public DateTime CreatedDate { get; set; }
    public bool IsActive { get; set; }
    public ProductTypeOption ProductType { get; set; }
   // public string? CategoryName { get; set; }
    public List<ProductVariantDto>? Variants { get; set; } = new();

    // ✅ Ingredients list
    public List<ProductIngredientDto>? Ingredients { get; set; } = new();
    public class Mapping : Profile
    {
        public Mapping()
        {
            CreateMap<GetDoctorProdcutListResponse, GetDoctorProdcutListResponse>();
        }
    }
}

public class ProductIngredientDto
{
    public long? Id { get; set; }
    public long? ProductId { get; set; }

    public string? Name { get; set; }
    public string? Strength { get; set; }
}

// ✅ Renamed "Ingredients" -> "ProductVariantDto"
public class ProductVariantDto
{
    public long? Id { get; set; }
    public long? ProductId { get; set; }
    public string? Upc { get; set; }
    public string Name { get; set; } = null!;
    public decimal Price { get; set; }
    public decimal? ComparePrice { get; set; }
    public int Quantity { get; set; }
    public string QuantityUnit { get; set; } = null!;
    public int? Refills { get; set; }
    public string? Dose { get; set; }
    public string? Dosage { get; set; }
    public string? Strength { get; set; }
    public string? Packing { get; set; }
    public string? Form { get; set; }

    public string? RegularImageUrlFileName { get; set; }
    public string? RegularImageUrlFilePath { get; set; }

    public string? TransparentImageUrlFileName { get; set; }
    public string? TransparentImageUrlFilePath { get; set; }

    public string? VideoUrl { get; set; }
}
