﻿using AutoMapper;

namespace NovaHealth.Application.Doctor.Queries.GetDoctorBookOrderListByUserId;

public class GetDoctorBookOrderListByUserIdResponse
{
    public long Id { get; set; }

    public Guid GuidNumber { get; set; }
    public string Guid { get; set; } = null!;
    public long UserId { get; set; }
    public long ProductId { get; set; }
    public long? ProductVariantId { get; set; } = null;
    public DateTime OrderDate { get; set; }
    public PaymentStatusType Status { get; set; }

    public string? PhoneNumber { get; set; }

    public DateTime CratedDate { get; set; }

    public decimal TotalAmount { get; set; }
    public string? Address1 { get; set; } = null;

    public string? Address2 { get; set; }

    public string? City { get; set; } = null;

    public int? StateId { get; set; } = null;

    public string? ZipCode { get; set; } = null!;

    public string? PatientName { get; set; }
    public string? SessionId { get; set; }

    //internal async Task<PaginationResponse<GetDoctorBookOrderListByUserIdResponse>> PaginatedListAsync(int pageNumber, int pageSize)
    //{
    //    throw new NotImplementedException();
    //}

    public string? ProductName { get; set; }
    public string? Strength { get; set; }
    public string Name { get; set; } = null!;
    public decimal Price { get; set; }
    public int Quantity { get; set; }
    public string? Dose { get; set; }
    public decimal Amount { get; set; }

    public string? RegularImageUrlFilePath { get; set; }

    public string? ProfilePictureName { get; set; }

    public string? ProfilePicturePath { get; set; }

    public class Mapping : Profile
    {
        public Mapping()
        {
            CreateMap<GetDoctorBookOrderListByUserIdResponse, GetDoctorBookOrderListByUserIdResponse>();
        }
    }
}