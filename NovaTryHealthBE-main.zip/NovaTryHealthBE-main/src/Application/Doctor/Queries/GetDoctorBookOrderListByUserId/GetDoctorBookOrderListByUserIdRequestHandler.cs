﻿using AutoMapper;
using MediatR;
using Microsoft.EntityFrameworkCore;
using NovaHealth.Application.Common.Interfaces;
using NovaHealth.Application.Common.Models;
using System.Text.Json.Serialization;
using System.Linq.Dynamic.Core;
using NovaHealth.Application.Common.Mappings;

namespace NovaHealth.Application.Doctor.Queries.GetDoctorBookOrderListByUserId;

public class GetDoctorBookOrderListByUserIdRequest : PaginationFilter, IRequest<PaginationResponse<GetDoctorBookOrderListByUserIdResponse>>
{
    [JsonIgnore] public long UserId { get; set; }
}

public class GetDoctorBookOrderListByUserIdRequestHandler : IRequestHandler<GetDoctorBookOrderListByUserIdRequest, PaginationResponse<GetDoctorBookOrderListByUserIdResponse>>
{
    private readonly INovaHealthDbContext _novaHealthDbContext;
    private readonly IMapper _mapper;

    public GetDoctorBookOrderListByUserIdRequestHandler(INovaHealthDbContext novaHealthDbContext, IMapper mapper)
    {
        _novaHealthDbContext = novaHealthDbContext;
        _mapper = mapper;
    }

    public async Task<PaginationResponse<GetDoctorBookOrderListByUserIdResponse>> Handle(GetDoctorBookOrderListByUserIdRequest request, CancellationToken cancellationToken)
    {
        var user = await _novaHealthDbContext.Users
                  .Include(u => u.UserRoles).ThenInclude(ur => ur.Role)
                  .FirstOrDefaultAsync(u => u.Id == request.UserId && !u.IsDeleted && u.IsActive, cancellationToken);

        if (user == null || !user.UserRoles.Any(ur => ur.Role.RoleType == RoleType.Doctor || ur.Role.RoleType == RoleType.Admin))
        {
            throw new Exception("doctor or admin not found.");
        }

        var doctorOrders = _novaHealthDbContext.BookOrders
                        .Include(x => x.ProductOrders).ThenInclude(po => po.Product).ThenInclude(p => p.Variants)
                        .Where(o => o.IsActive && !o.IsDeleted).Include(o => o.User).ThenInclude(u => u.UserRoles)


                    .Select(o => new GetDoctorBookOrderListByUserIdResponse
                    {
                        Id = o.Id,
                        GuidNumber = o.Guid,
                        Guid = o.Guid.ToString("N").ToLower().Substring(o.Guid.ToString("N").Length - 6),
                        UserId = o.UserId,
                        ProductVariantId = null,
                        OrderDate = o.CreatedDate,
                        Status = o.PaymentStatus,
                        TotalAmount = o.Amount,
                        PhoneNumber = o.User.PhoneNumber,
                        PatientName = o.User.FirstName + " " + o.User.LastName,
                        CratedDate = o.CreatedDate,
                        SessionId = o.SessionId,

                        // Address (single SQL query instead of multiple FirstOrDefault())
                        Address1 = o.User.UserAddresses.OrderBy(a => a.Id).Select(a => a.Address1).FirstOrDefault(),
                        Address2 = o.User.UserAddresses.OrderBy(a => a.Id).Select(a => a.Address2).FirstOrDefault(),
                        City = o.User.UserAddresses.OrderBy(a => a.Id).Select(a => a.City).FirstOrDefault(),
                        StateId = o.User.UserAddresses.OrderBy(a => a.Id).Select(a => a.StateId).FirstOrDefault(),
                        ZipCode = o.User.UserAddresses.OrderBy(a => a.Id).Select(a => a.ZipCode).FirstOrDefault(),

                        // Product info (flattened query)
                        RegularImageUrlFilePath = o.ProductOrders
                            .OrderBy(po => po.Id)
                            .Select(po => po.Product.Variants.OrderBy(v => v.Id).Select(v => v.RegularImageUrlFilePath).FirstOrDefault())
                            .FirstOrDefault(),

                        ProductName = o.ProductOrders
                            .OrderBy(po => po.Id)
                            .Select(po => po.Product.DrugName ?? po.Product.BrandName ?? po.Product.ShortName)
                            .FirstOrDefault(),

                        ProductId = o.ProductOrders
                            .OrderBy(po => po.Id)
                            .Select(po => po.ProductId)
                            .FirstOrDefault(),

                        Quantity = o.ProductOrders
                            .OrderBy(po => po.Id)
                            .Select(po => po.Quantity)
                            .FirstOrDefault(),

                        Amount = o.ProductOrders
                            .OrderBy(po => po.Id)
                            .Select(po => po.Amount)
                            .FirstOrDefault(),

                        Strength = o.ProductOrders
                            .OrderBy(po => po.Id)
                            .Select(po => po.Product.Variants.OrderBy(v => v.Id).Select(v => v.Strength).FirstOrDefault())
                            .FirstOrDefault(),

                        Dose = o.ProductOrders
                            .OrderBy(po => po.Id)
                            .Select(po => po.Product.Variants.OrderBy(v => v.Id).Select(v => v.Dose).FirstOrDefault())
                            .FirstOrDefault(),

                        Price = o.ProductOrders
                            .OrderBy(po => po.Id)
                            .Select(po => po.Product.Variants.OrderBy(v => v.Id).Select(v => v.Price).FirstOrDefault())
                            .FirstOrDefault(),

                        ProfilePictureName = o.User.ProfilePictureName,
                        ProfilePicturePath = o.User.ProfilePicturePath,
                    });

        // Apply filter dynamically if provided
        if (!string.IsNullOrEmpty(request.Filter))
        {
            doctorOrders = doctorOrders.Where(request.Filter);
        }

        // Apply ordering if provided
        if (!string.IsNullOrEmpty(request.OrderBy))
        {
            doctorOrders = doctorOrders.OrderBy(request.OrderBy);
        }
        else
        {
            doctorOrders = doctorOrders.OrderByDescending(o => o.OrderDate);
        }

        // Paginate and return
        return await doctorOrders.PaginatedListAsync(request.PageNumber, request.PageSize);
    }
}
