﻿using MediatR;
using Microsoft.EntityFrameworkCore;
using NovaHealth.Application.Common.Interfaces;

namespace NovaHealth.Application.Doctor.Commands.DeleteDoctorProfilePicture;

public class DeleteDoctorProfilePictureRequest : IRequest<bool>
{
    public long Id { get; set; }
}

public class DeleteDoctorProfilePictureRequestHandler : IRequestHandler<DeleteDoctorProfilePictureRequest, bool>
{
    private readonly INovaHealthDbContext _novaHealthDbContext;

    public DeleteDoctorProfilePictureRequestHandler(INovaHealthDbContext novaHealthDbContext)
    {
        _novaHealthDbContext = novaHealthDbContext;
    }

    public async Task<bool> Handle(DeleteDoctorProfilePictureRequest request, CancellationToken cancellationToken)
    {
        var doctor = await _novaHealthDbContext.Users
                   .FirstOrDefaultAsync(x => x.Id == request.Id && !x.IsDeleted, cancellationToken);

        if (doctor == null)
        {
            throw new NotImplementedException($"Cannot find doctor with id :{request.Id}");
        }


        doctor.ProfilePictureName = null;
        doctor.ProfilePicturePath = null;

        await _novaHealthDbContext.SaveChangesAsync(cancellationToken);

        return true;
    }
}
