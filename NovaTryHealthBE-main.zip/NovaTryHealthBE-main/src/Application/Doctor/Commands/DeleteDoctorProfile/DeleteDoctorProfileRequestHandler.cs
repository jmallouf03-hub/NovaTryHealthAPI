﻿using MediatR;
using Microsoft.EntityFrameworkCore;
using NovaHealth.Application.Common.Interfaces;

namespace NovaHealth.Application.Doctor.Commands.DeleteDoctorProfile;

public class DeleteDoctorProfileRequest : IRequest<bool>
{
    public long Id { get; set; }
}

public class DeleteDoctorProfileRequestHandler : IRequestHandler<DeleteDoctorProfileRequest, bool>
{
    private readonly INovaHealthDbContext _novaHealthDbContext;

    public DeleteDoctorProfileRequestHandler(INovaHealthDbContext novaHealthDbContext)
    {
        _novaHealthDbContext = novaHealthDbContext;
    }

    public async Task<bool> Handle(DeleteDoctorProfileRequest request, CancellationToken cancellationToken)
    {
        var doctor = await _novaHealthDbContext.Users
                    .FirstOrDefaultAsync(x => x.Id == request.Id && !x.IsDeleted, cancellationToken);

        if (doctor == null)
        {
            throw new NotImplementedException($"Cannot find doctor with id :{request.Id}");
        }

        doctor.IsDeleted = true;
        await _novaHealthDbContext.SaveChangesAsync(cancellationToken);

        return true;
    }
}