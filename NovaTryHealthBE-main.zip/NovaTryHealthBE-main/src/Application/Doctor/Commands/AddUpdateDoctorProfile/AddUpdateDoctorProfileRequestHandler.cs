﻿using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using NovaHealth.Application.Common.FileStorage;
using NovaHealth.Application.Common.Interfaces;
using NovaHealth.Domain.Entities;


namespace NovaHealth.Application.Doctor.Commands.AddUpdateDoctorProfile;

public class AddUpdateDoctorProfileRequestHandler : IRequestHandler<AddUpdateDoctorProfileRequest, bool>
{
    private readonly INovaHealthDbContext _novaHealthDbContext;
    private readonly Func<FileStorageOption?, IFileStorageService> _fileStorageFunc;
    private readonly AppSettings _appSettings;

    public AddUpdateDoctorProfileRequestHandler(Func<FileStorageOption?, IFileStorageService> fileStorageFunc,INovaHealthDbContext novaHealthDbContext, IOptions<AppSettings> appSettings)
    {
        _novaHealthDbContext = novaHealthDbContext;
        _fileStorageFunc = fileStorageFunc;
        _appSettings = appSettings.Value;
    }

    public async Task<bool> Handle(AddUpdateDoctorProfileRequest request, CancellationToken cancellationToken)
    {
        var fileStorageService = _fileStorageFunc(_appSettings.DefaultFileStorage);

        // 1. Doctor Role fetch
        var doctorRole = await _novaHealthDbContext.Roles
             .FirstOrDefaultAsync(r => r.RoleType == RoleType.Doctor, cancellationToken);

        if (doctorRole == null)
        {
            throw new Exception("Doctor role not found in Roles table.");
        }

        // 2. Doctor/User find karo with Role check
        var existingDoctor = await _novaHealthDbContext.Users
                        .Include(u => u.DoctorCategories)
                        .Include(u => u.UserRoles) // agar mapping table hai to include karna zaroori hai
                        .FirstOrDefaultAsync(x => x.Id == request.UserId && !x.IsDeleted && x.IsActive
                                               && x.UserRoles.Any(ur => ur.RoleId == doctorRole.Id), cancellationToken);
      
        if (existingDoctor == null)
            throw new Exception("User is not assigned as Doctor or doctor not found.");

        // 3. User info update
        existingDoctor.FirstName = request.FirstName;
        existingDoctor.LastName = request.LastName;
        existingDoctor.PhoneNumber = request.PhoneNumber;
        existingDoctor.Email = request.Email;
        existingDoctor.DateOfBirth = request.DateOfBirth;
        existingDoctor.Gender = request.Gender;


        if (request.ProfilePictureName != null)
        {
            var fileUploadResponse = await fileStorageService.UploadAsync(new FileUploadRequest
            {
                File = request.ProfilePictureName,
                FileTypeOption = FileTypeOption.ProfilePicture,
                UserId = existingDoctor.Id,
            }, cancellationToken);

            existingDoctor.ProfilePictureName = fileUploadResponse.OriginalName;
            existingDoctor.ProfilePicturePath = fileUploadResponse.SavedTo;
        }

        await _novaHealthDbContext.SaveChangesAsync(cancellationToken);


        // 4. Address update or insert
        var existingAddress = await _novaHealthDbContext.UserAddress
            .FirstOrDefaultAsync(a => a.UserId == request.UserId && !a.IsDeleted, cancellationToken);

        if (existingAddress != null)
        {
            existingAddress.Address1 = request.Address1;
            existingAddress.Address2 = request.Address2;
            existingAddress.City = request.City;
            existingAddress.StateId = request.StateId;
            existingAddress.ZipCode = request.ZipCode;
        }

        else
        {
            var newDoctorAddress = new UserAddress
            {
                UserId = request.UserId,
                Address1 = request.Address1,
                Address2 = request.Address2,
                City = request.City,
                StateId = request.StateId,
                ZipCode = request.ZipCode,
                CreatedDate = DateTime.UtcNow,
                IsActive = true,
                IsDeleted = false
            };

            _novaHealthDbContext.UserAddress.Add(newDoctorAddress);
        } 

        // 5. Categories update
        var existingCategoryIds = await _novaHealthDbContext.DoctorCategories
            .Where(dc => dc.UserId == request.UserId)
            .Select(dc => dc.CategoryId)
            .ToListAsync(cancellationToken);

        var newCategoryIds = request.CategoryIds
            .Where(cid => !existingCategoryIds.Contains(cid))
            .ToList();

        foreach (var categoryId in newCategoryIds)
        {
            var doctorCategory = new DoctorCategory
            {
                UserId = request.UserId,
                CategoryId = categoryId
            };
            _novaHealthDbContext.DoctorCategories.Add(doctorCategory);
        }

        // 6. Save changes
        await _novaHealthDbContext.SaveChangesAsync(cancellationToken);

        return true;
    }
}
