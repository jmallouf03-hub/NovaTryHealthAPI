﻿using MediatR;
using Microsoft.AspNetCore.Http;

namespace NovaHealth.Application.Doctor.Commands.AddUpdateDoctorProfile;

public class AddUpdateDoctorProfileRequest : IRequest<bool>
{
    public long UserId { get; set; }

    //public long? Id { get; set; /*}*/
    public string FirstName { get; set; } = null!;

    public string LastName { get; set; } = null!;

    public string Email { get; set; } = null!;

    public string PhoneNumber { get; set; } = null!;

    public DateTime DateOfBirth { get; set; }

    public GenderTypeOption Gender { get; set; } 

    public string Address1 { get; set; } = null!;

    public string? Address2 { get; set; }

    public string City { get; set; } = null!;

    public int StateId { get; set; }

    public string ZipCode { get; set; } = null!;

    public IFormFile? ProfilePictureName { get; set; }

    public List<long> CategoryIds { get; set; } = new List<long>();
}
