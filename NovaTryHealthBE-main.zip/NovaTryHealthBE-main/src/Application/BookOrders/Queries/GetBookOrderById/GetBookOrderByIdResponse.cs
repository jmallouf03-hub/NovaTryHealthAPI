﻿using NovaHealth.Application.BookOrders.Command.AddOrUpdateBookOrder;

namespace NovaHealth.Application.BookOrders.Queries.GetBookOrderById;

public class GetBookOrderByIdResponse
{
    public long Id { get; set; }

    public Guid Guid { get; set; }
    public long UserId { get; set; }
    public long? ProductVariantId { get; set; } = null;
    public DateTime OrderDate { get; set; }
    public PaymentStatusType Status { get; set; }

    public string? PhoneNumber { get; set; } 

    public DateTime CratedDate { get; set; }

    public decimal TotalAmount { get; set; }
    public decimal Price { get; set; }
    public string? Address1 { get; set; } = null;

    public string? Address2 { get; set; }

    public string? City { get; set; } = null;

    public int? StateId { get; set; } = null;

    public string? ZipCode { get; set; } = null!;

    public string? SessionId { get; set; }

    public List<ProductOrderDto> Products { get; set; } = new();
}

public class ProductOrderDto
{
    public long ProductId { get; set; }
    public long? ProductVariantId { get; set; }

    public string? ProductName { get; set; }
    public string? Strength { get; set; }
    public string Name { get; set; } = null!;
    public decimal Price { get; set; }
    public int Quantity { get; set; }
    public string? Dose { get; set; }
    public decimal Amount { get; set; }
    public DateTime CratedDate { get; set; }
    public string? RegularImageUrlFilePath { get; set; }
}