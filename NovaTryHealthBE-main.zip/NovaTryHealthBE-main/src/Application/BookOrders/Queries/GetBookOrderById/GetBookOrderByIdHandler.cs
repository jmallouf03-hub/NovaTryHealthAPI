﻿using MediatR;
using Microsoft.EntityFrameworkCore;
using NovaHealth.Application.Common.Interfaces;

namespace NovaHealth.Application.BookOrders.Queries.GetBookOrderById;

public class GetBookOrderByIdRequest : IRequest<GetBookOrderByIdResponse>
{
    public long Id { get; set; }
}

public class GetBookOrderByIdHandler : IRequestHandler<GetBookOrderByIdRequest, GetBookOrderByIdResponse>
{
    private readonly INovaHealthDbContext _novaHealthDbContext;

    public GetBookOrderByIdHandler(INovaHealthDbContext novaHealthDbContext)
    {
        _novaHealthDbContext = novaHealthDbContext;
    }
    public async Task<GetBookOrderByIdResponse> Handle(GetBookOrderByIdRequest request, CancellationToken cancellationToken)
    {
        var order = await _novaHealthDbContext.BookOrders
                        .Include(x => x.ProductOrders).ThenInclude(x => x.Product).ThenInclude(x => x.Variants)
                        .Where(o => o.Id == request.Id)
                        .Select(o => new GetBookOrderByIdResponse
                        {
                            Id = o.Id,
                            Guid = o.Guid,
                            UserId = o.UserId,
                            ProductVariantId = null,
                            OrderDate = o.CreatedDate,  // agar CreatedDate nullable hai
                            Status = o.PaymentStatus,
                            TotalAmount = o.Amount,
                            Address1 = o.User.UserAddresses.FirstOrDefault() != null
                                     ? o.User.UserAddresses.FirstOrDefault()!.Address1
                                         : null,
                            Address2 = o.User.UserAddresses.FirstOrDefault() != null
                                       ? o.User.UserAddresses.FirstOrDefault()!.Address2
                                      : null,
                            City = o.User.UserAddresses.FirstOrDefault() != null
                                     ? o.User.UserAddresses.FirstOrDefault()!.City
                                    : null,
                            StateId = o.User.UserAddresses.FirstOrDefault()!.StateId,
                            ZipCode = o.User.UserAddresses.FirstOrDefault() != null
                                         ? o.User.UserAddresses.FirstOrDefault()!.ZipCode
                                         : null,
                            PhoneNumber = o.User.PhoneNumber,
                            SessionId = o.SessionId,

                            Products = o.ProductOrders.Select(po => new ProductOrderDto
                            {
                                ProductId = po.ProductId,
                                //ProductVariantId = po.Product.Variants?? null,
                                Quantity = po.Quantity,
                                Amount = po.Amount,
                                CratedDate = po.Product.CreatedDate,
                                ProductName = po.Product.DrugName ?? po.Product.BrandName ?? po.Product.ShortName,
                                Strength = po.Product.Variants != null ? po.Product.Variants.Select(x => x.Strength).FirstOrDefault() : null,
                                Name = po.Product.Variants != null ? po.Product.Variants.Select(x => x.Name).FirstOrDefault() ?? "" : "",
                                Price = po.Product.Variants != null ? po.Product.Variants.Select(x => x.Price).FirstOrDefault() : 0,
                                Dose = po.Product.Variants != null ? po.Product.Variants.Select(x => x.Dose).FirstOrDefault() : null,
                                RegularImageUrlFilePath = po.Product.Variants.Select(x => x.RegularImageUrlFilePath).FirstOrDefault()
                            }).ToList()
                        }).FirstOrDefaultAsync(cancellationToken);

        if (order == null)
            throw new Exception("Order not found.");

        return order;
    }
}
