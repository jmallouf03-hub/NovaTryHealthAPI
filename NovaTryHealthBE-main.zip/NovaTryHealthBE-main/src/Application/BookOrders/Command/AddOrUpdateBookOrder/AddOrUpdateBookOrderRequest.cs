﻿using MediatR;

namespace NovaHealth.Application.BookOrders.Command.AddOrUpdateBookOrder;

public class AddOrUpdateBookOrderRequest : IRequest<long>
{
    public long? Id { get; set; }
    public long UserId { get; set; }

  //  public decimal Amount { get; set; }
    public PaymentStatusType PaymentStatus { get; set; }

    public List<ProductOrderDto> Products { get; set; } = new List<ProductOrderDto>();
}

public class ProductOrderDto
{
    public long ProductId { get; set; }
    public int Quantity { get; set; }
    public decimal Amount { get; set; }
}
