﻿using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.SignalR;
using Microsoft.EntityFrameworkCore;
using NovaHealth.Application.Common.Interfaces;
using NovaHealth.Application.SignalR.Interface;
using NovaHealth.Application.SignalR.Queries;
using NovaHealth.Domain.Entities;

namespace NovaHealth.Application.BookOrders.Command.AddOrUpdateBookOrder;

public class AddOrUpdateBookOrderHandler : IRequestHandler<AddOrUpdateBookOrderRequest, long>
{
    private readonly INovaHealthDbContext _novaHealthDbContext;
    private readonly IHttpContextAccessor _httpContextAccessor;
    private readonly ITimelineService _timelineService;
    private readonly IHubContext<NotificationHub> _hubContext;
    private readonly IUserConnectionManager _userConnectionManager;

    public AddOrUpdateBookOrderHandler(INovaHealthDbContext novaHealthDbContext, IHttpContextAccessor httpContextAccessor, ITimelineService timelineService, IHubContext<NotificationHub> hubContext,
        IUserConnectionManager userConnectionManager)
    {
        _novaHealthDbContext = novaHealthDbContext;
        _httpContextAccessor = httpContextAccessor;
        _timelineService = timelineService;
        _hubContext = hubContext;
        _userConnectionManager = userConnectionManager;
    }
    public async Task<long> Handle(AddOrUpdateBookOrderRequest request, CancellationToken cancellationToken)
    {
        BookOrder bookOrder;

        if (request.Id != null && request.Id > 0) // Update existing order
        {
            bookOrder = await _novaHealthDbContext.BookOrders
                .FirstOrDefaultAsync(o => o.Id == request.Id, cancellationToken);

            if (bookOrder == null)
                throw new Exception("Order not found.");

            _novaHealthDbContext.ProductOrders.RemoveRange(bookOrder.ProductOrders);

            decimal totalAmount = 0;
            // Update fields
            foreach (var productDto in request.Products)
            {
                var productOrder = new ProductOrder
                {
                    BookOrder = bookOrder,
                    ProductId = productDto.ProductId,
                    Quantity = productDto.Quantity,
                    Amount = productDto.Amount
                };
                await _novaHealthDbContext.ProductOrders.AddAsync(productOrder, cancellationToken);
                totalAmount += productDto.Amount;
            }

            // Update main order fields
            bookOrder.UserId = request.UserId;
            bookOrder.Amount = totalAmount;
            bookOrder.PaymentStatus = PaymentStatusType.Completed;
            bookOrder.UpdatedDate = DateTime.Now;
        }
        else // Add new order
        {


            string sessionId = _httpContextAccessor.HttpContext?.Request.Headers.TryGetValue("ClientId", out var values)
       == true ? values.ToString() : null;

            var order = await _novaHealthDbContext.BookOrders
               .FirstOrDefaultAsync(o => o.SessionId == sessionId, cancellationToken);

            if (order != null)
            {
                foreach (var productDto in request.Products)
                {
                    var productOrder = new ProductOrder
                    {
                        ProductId = productDto.ProductId,
                        Quantity = productDto.Quantity,
                        Amount = productDto.Amount,
                        BookOrder = order
                    };
                    order.ProductOrders.Add(productOrder);
                }
                order.Amount = order.Amount + request.Products.Sum(x => x.Amount);           

                await _novaHealthDbContext.SaveChangesAsync(cancellationToken);

                bookOrder = order;
            }
            else
            {
                decimal totalAmount = request.Products.Sum(p => p.Amount);

                bookOrder = new BookOrder
                {
                    Guid = Guid.NewGuid(),
                    UserId = request.UserId,
                    Amount = totalAmount,
                    PaymentStatus = PaymentStatusType.Completed,
                    CreatedDate = DateTime.Now,
                    SessionId = sessionId,
                    IsActive = true,
                    IsDeleted = false
                };


                foreach (var productDto in request.Products)
                {
                    var productOrder = new ProductOrder
                    {
                        ProductId = productDto.ProductId,
                        Quantity = productDto.Quantity,
                        Amount = productDto.Amount,
                        BookOrder = bookOrder
                    };
                    bookOrder.ProductOrders.Add(productOrder);
                }

                await _novaHealthDbContext.BookOrders.AddAsync(bookOrder, cancellationToken);
            }
        }

        await _novaHealthDbContext.SaveChangesAsync(cancellationToken);

        var notification = new Notification
        {
            NotificationType = NotificationType.Order,
            Title = "New Order Placed",
            Message = $"patient #{request.UserId} placed a new order (Order ID: {bookOrder.Id})",
            CreatedBy = request.UserId,
            CreatedDate = DateTime.UtcNow,
            IsActive = true
        };

        await _novaHealthDbContext.Notifications.AddAsync(notification, cancellationToken);
        await _novaHealthDbContext.SaveChangesAsync(cancellationToken);

        var adminAndDoctorUserIds = await _novaHealthDbContext.Users
                                   .Where(u => u.UserRoles.Any(r => r.Role.RoleType == RoleType.Admin || r.Role.RoleType == RoleType.Doctor))
                                   .Select(u => u.Id)
                                   .Distinct()
                                   .ToListAsync(cancellationToken);

        foreach (var user in adminAndDoctorUserIds)
        {
            var userNotificationReference = new UserNotificationReference
            {
                UserId = user,
                NotificationId = notification.Id,
                NotificationTypeId = bookOrder.Id,
                CreatedDate = DateTime.UtcNow,
                IsActive = true,
                IsRead = false,
                IsDeleted = false
            };
            await _novaHealthDbContext.UserNotificationReferences.AddAsync(userNotificationReference, cancellationToken);
        }

        foreach (var userId in adminAndDoctorUserIds)
        {
            var connectionIds = _userConnectionManager.GetUserConnections(userId.ToString());

            foreach (var connectionId in connectionIds)
            {
                await _hubContext.Clients.Client(connectionId).SendAsync("ReceiveNotification", new
                {
                    Title = notification.Title,
                    Message = notification.Message,
                    Type = notification.NotificationType.ToString(),
                    CreatedDate = bookOrder.CreatedDate
                }, cancellationToken);
            }
        }


        var ipAddress = _httpContextAccessor.HttpContext?.Connection?.RemoteIpAddress?.ToString();

        if (_httpContextAccessor.HttpContext.Request.Headers.ContainsKey("X-Forwarded-For"))
        {
            ipAddress = _httpContextAccessor.HttpContext.Request.Headers["X-Forwarded-For"].FirstOrDefault();
        }
        await _timelineService.LogTimelineEventAsync(
                         request.UserId,
                        TimelineEventType.Order,
                          "Order Placed",
                         $"Order placed {bookOrder.Id}",
                       //$" {request.ProductId}, quantity {request.Quantity}, amount {request.Amount}",
                       new { ipAddress = ipAddress, orderId = bookOrder.Id }
        );


        return bookOrder.Id;
    }
}
