﻿using MediatR;
using Microsoft.EntityFrameworkCore;
using NovaHealth.Application.Common.Interfaces;

namespace NovaHealth.Application.Products.Command.DeleteProduct;

public class DeleteProductRequest : IRequest<bool>
{
    public long Id { get; set; }
}

public class DeleteProductRequestHandler : IRequestHandler<DeleteProductRequest, bool>
{
    private readonly INovaHealthDbContext _novaHealthDbContext;

    public DeleteProductRequestHandler(INovaHealthDbContext novaHealthDbContext)
    {
        _novaHealthDbContext = novaHealthDbContext;
    }

    public async Task<bool> Handle(DeleteProductRequest request, CancellationToken cancellationToken)
    {
        var product = await _novaHealthDbContext.Products
                     .FirstOrDefaultAsync(x => x.Id == request.Id && !x.IsDeleted, cancellationToken);

        if (product == null)
        {
            throw new NotImplementedException($"Cannot find product with id :{request.Id}");
        }

        product.IsDeleted = true;

        await _novaHealthDbContext.SaveChangesAsync(cancellationToken);

        return true;
    }
}