﻿using MediatR;
using Microsoft.EntityFrameworkCore;
using NovaHealth.Application.Common.Interfaces;

namespace NovaHealth.Application.Products.Command.DeleteProductIngredients;

public class DeleteProductIngredientRequest : IRequest<bool>
{
    public long Id { get; set; }
}

public class DeleteProductIngredientRequestHandler : IRequestHandler<DeleteProductIngredientRequest, bool>
{
    private readonly INovaHealthDbContext _novaHealthDbContext;

    public DeleteProductIngredientRequestHandler(INovaHealthDbContext novaHealthDbContext)
    {
        _novaHealthDbContext = novaHealthDbContext;
    }

    public async Task<bool> Handle(DeleteProductIngredientRequest request, CancellationToken cancellationToken)
    {
        var productIngredient = await _novaHealthDbContext.ProductIngredients
                              .FirstOrDefaultAsync(x => x.Id == request.Id && !x.IsDeleted, cancellationToken);

        if (productIngredient == null)
        {
            throw new NotImplementedException($"Cannot find product ingredient with id :{request.Id}");
        }

        productIngredient.IsDeleted = true;

        await _novaHealthDbContext.SaveChangesAsync(cancellationToken);

        return true;
    }
}