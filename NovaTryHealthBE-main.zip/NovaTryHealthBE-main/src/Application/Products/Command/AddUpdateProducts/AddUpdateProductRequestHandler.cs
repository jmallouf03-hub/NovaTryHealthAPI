﻿using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using NovaHealth.Application.Common.FileStorage;
using NovaHealth.Application.Common.Interfaces;
using NovaHealth.Application.Products.AddUpdateProducts;
using NovaHealth.Domain.Entities;

namespace NovaHealth.Application.Products.Command.AddUpdateProducts;

public class AddUpdateProductRequestHandler : IRequestHandler<AddUpdateProductRequest, AddUpdateProductResponse>
{
    private readonly INovaHealthDbContext _novaHealthDbContext;
    private readonly Func<FileStorageOption?, IFileStorageService> _fileStorageFunc;
    private readonly AppSettings _appSettings;

    public AddUpdateProductRequestHandler(
        Func<FileStorageOption?, IFileStorageService> fileStorageFunc,
        INovaHealthDbContext novaHealthDbContext,
        IOptions<AppSettings> appSettings)
    {
        _novaHealthDbContext = novaHealthDbContext;
        _fileStorageFunc = fileStorageFunc;
        _appSettings = appSettings.Value;
    }
    public async Task<AddUpdateProductResponse> Handle(AddUpdateProductRequest request, CancellationToken cancellationToken)
    {

        var fileStorageService = _fileStorageFunc(_appSettings.DefaultFileStorage);

        var product = await _novaHealthDbContext.Products
            .Include(p => p.Variants)
            .Include(p => p.Ingredients)
            .FirstOrDefaultAsync(x => x.Id == request.Id && !x.IsDeleted, cancellationToken);

        if (product == null)
        {
            product = new Product
            {
                DrugName = request.DrugName ?? string.Empty,
                BrandName = request.BrandName,
                ShortName = request.ShortName,
                LabelerName = request.LabelerName,
                GenericName = request.GenericName,
                DosageForm = request.DosageForm,
                ConsultOnlyPrice = request.ConsultOnlyPrice,
                ProductType = request.ProductType,
                IsActive = true,
                IsDeleted = false,
                CreatedDate = DateTime.UtcNow
            };

            await _novaHealthDbContext.Products.AddAsync(product, cancellationToken);
            await _novaHealthDbContext.SaveChangesAsync(cancellationToken);
        }
        else
        {
            product.DrugName = request.DrugName;
            product.BrandName = request.BrandName;
            product.ShortName = request.ShortName;
            product.LabelerName = request.LabelerName;
            product.GenericName = request.GenericName;
            product.DosageForm = request.DosageForm;
            product.ConsultOnlyPrice = request.ConsultOnlyPrice;
            product.CreatedDate = DateTime.UtcNow;
            product.ProductType = request.ProductType;
            product.IsActive = true;
            product.IsDeleted = false;

        }

        // ✅ Handle Variants
        foreach (var variantRequest in request.Variants)
        {
            var existingVariant = product.Variants.FirstOrDefault(v => v.Id == variantRequest.Id);

            if (existingVariant != null)
            {
                existingVariant.Name = variantRequest.Name;
                existingVariant.Price = variantRequest.Price;
                existingVariant.ComparePrice = variantRequest.ComparePrice;
                existingVariant.Quantity = variantRequest.Quantity;
                existingVariant.QuantityUnit = variantRequest.QuantityUnit;
                existingVariant.Refills = variantRequest.Refills;
                existingVariant.Dose = variantRequest.Dose;
                existingVariant.Dosage = variantRequest.Dosage;
                existingVariant.Strength = variantRequest.Strength;
                existingVariant.Packing = variantRequest.Packing;
                existingVariant.Form = variantRequest.Form;
                existingVariant.VideoUrl = variantRequest.VideoUrl;
                existingVariant.IsActive = true;
                existingVariant.CreatedDate = DateTime.UtcNow;
                existingVariant.Upc = variantRequest.Upc;

                if (variantRequest.RegularImageUrlFileName != null)
                {
                    var upload = await fileStorageService.UploadAsync(new FileUploadRequest
                    {
                        File = variantRequest.RegularImageUrlFileName,
                        FileTypeOption = FileTypeOption.ProfilePicture
                    }, cancellationToken);

                    existingVariant.RegularImageUrlFileName = upload.OriginalName;
                    existingVariant.RegularImageUrlFilePath = upload.SavedTo;
                }

                if (variantRequest.TransparentImageUrlFileName != null)
                {
                    var upload = await fileStorageService.UploadAsync(new FileUploadRequest
                    {
                        File = variantRequest.TransparentImageUrlFileName,
                        FileTypeOption = FileTypeOption.ProfilePicture
                    }, cancellationToken);

                    existingVariant.TransparentImageUrlFileName = upload.OriginalName;
                    existingVariant.TransparentImageUrlFilePath = upload.SavedTo;
                }
            }
            else
            {
                var newVariant = new ProductVariant
                {
                    ProductId = product.Id,
                    Name = variantRequest.Name,
                    Price = variantRequest.Price,
                    ComparePrice = variantRequest.ComparePrice,
                    Quantity = variantRequest.Quantity,
                    QuantityUnit = variantRequest.QuantityUnit,
                    Refills = variantRequest.Refills,
                    Dose = variantRequest.Dose,
                    Dosage = variantRequest.Dosage,
                    Strength = variantRequest.Strength,
                    Packing = variantRequest.Packing,
                    Form = variantRequest.Form,
                    VideoUrl = variantRequest.VideoUrl,
                    Upc = variantRequest.Upc,
                    IsActive = true,
                    IsDeleted = false,
                    CreatedDate = DateTime.UtcNow
                };

                if (variantRequest.RegularImageUrlFileName != null)
                {
                    var upload = await fileStorageService.UploadAsync(new FileUploadRequest
                    {
                        File = variantRequest.RegularImageUrlFileName,
                        FileTypeOption = FileTypeOption.ProfilePicture
                    }, cancellationToken);

                    newVariant.RegularImageUrlFileName = upload.OriginalName;
                    newVariant.RegularImageUrlFilePath = upload.SavedTo;
                }

                if (variantRequest.TransparentImageUrlFileName != null)
                {
                    var upload = await fileStorageService.UploadAsync(new FileUploadRequest
                    {
                        File = variantRequest.TransparentImageUrlFileName,
                        FileTypeOption = FileTypeOption.ProfilePicture
                    }, cancellationToken);

                    newVariant.TransparentImageUrlFileName = upload.OriginalName;
                    newVariant.TransparentImageUrlFilePath = upload.SavedTo;
                }

                await _novaHealthDbContext.ProductVariants.AddAsync(newVariant, cancellationToken);
                await _novaHealthDbContext.SaveChangesAsync(cancellationToken);

            }
        }

        //  ✅ Handle Ingredients
        foreach (var ingredientRequest in request.Ingredients)
        {
            var existingIngredient = product.Ingredients.FirstOrDefault(i => i.Id == ingredientRequest.Id);

            if (existingIngredient != null)
            {
                existingIngredient.Name = ingredientRequest.Name;
                existingIngredient.Strength = ingredientRequest.Strength;
                existingIngredient.IsActive = true;
                existingIngredient.CreatedDate = DateTime.UtcNow;
            }
            else
            {
                var newIngredient = new ProductIngredient
                {
                    ProductId = product.Id,
                    Name = ingredientRequest.Name,
                    Strength = ingredientRequest.Strength,
                    IsActive = true,
                    IsDeleted = false,
                    CreatedDate = DateTime.UtcNow
                };

                await _novaHealthDbContext.ProductIngredients.AddAsync(newIngredient, cancellationToken);
                await _novaHealthDbContext.SaveChangesAsync(cancellationToken);

            }
        }

        await _novaHealthDbContext.SaveChangesAsync(cancellationToken);

        return new AddUpdateProductResponse
        {
            ProductId = product.Id,
        };

    }
}