﻿namespace NovaHealth.Application.Products.Command.AddUpdateProducts;

public class AddUpdateProductResponse
{
    public long ProductId { get; set; }
}
