﻿using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using NovaHealth.Application.Products.Command.AddUpdateProducts;

namespace NovaHealth.Application.Products.AddUpdateProducts;

public class AddUpdateProductRequest : IRequest<AddUpdateProductResponse>
{
    public long? Id { get; set; }
    public string DrugName { get; set; } = null!;
    public string? BrandName { get; set; }
    public string ShortName { get; set; } = null!;
    public string? LabelerName { get; set; }
    public string GenericName { get; set; } = null!;
    public string? DosageForm { get; set; }
    public decimal? ConsultOnlyPrice { get; set; }

    public ProductTypeOption ProductType { get; set; }

    // ✅ Variants for product pricing, packaging, images, etc.
    [FromForm]
    public List<ProductVariantDto>? Variants { get; set; } = new();

    // ✅ Ingredients list
    [FromForm]

    public List<ProductIngredientDto>? Ingredients { get; set; } = new();
}

public class ProductIngredientDto
{
    public long? Id { get; set; }
    public string? Name { get; set; }
    public string? Strength { get; set; }
}

// ✅ Renamed "Ingredients" -> "ProductVariantDto"
public class ProductVariantDto
{
    public long? Id { get; set; }
    public string Name { get; set; } = null!;
    public decimal Price { get; set; }

    public string? Upc { get; set; }
    public decimal ComparePrice { get; set; }
    public int Quantity { get; set; }
    public string QuantityUnit { get; set; } = null!;
    public int? Refills { get; set; }
    public string? Dose { get; set; }
    public string? Dosage { get; set; }
    public string? Strength { get; set; }
    public string? Packing { get; set; }
    public string? Form { get; set; }
    [FromForm]
    public IFormFile? RegularImageUrlFileName { get; set; }
    [FromForm]
    public IFormFile? TransparentImageUrlFileName { get; set; }

    public string? VideoUrl { get; set; }
}