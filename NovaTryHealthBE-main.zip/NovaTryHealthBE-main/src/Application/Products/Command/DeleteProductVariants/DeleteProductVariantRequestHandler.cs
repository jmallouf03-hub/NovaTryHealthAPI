﻿using MediatR;
using Microsoft.EntityFrameworkCore;
using NovaHealth.Application.Common.Interfaces;

namespace NovaHealth.Application.Products.Command.DeleteProductVariants;

public class DeleteProductVariantRequest : IRequest<bool>
{
    public long Id { get; set; }
}

public class DeleteProductVariantRequestHandler : IRequestHandler<DeleteProductVariantRequest, bool>
{
    private readonly INovaHealthDbContext _novaHealthDbContext;

    public DeleteProductVariantRequestHandler(INovaHealthDbContext novaHealthDbContext)
    {
        _novaHealthDbContext = novaHealthDbContext;
    }

    public async Task<bool> Handle(DeleteProductVariantRequest request, CancellationToken cancellationToken)
    {
        var productVariant = await _novaHealthDbContext.ProductVariants
            .FirstOrDefaultAsync(x => x.Id == request.Id && !x.IsDeleted, cancellationToken);

        if (productVariant == null)
        {
            throw new NotImplementedException($"Cannot find product variant with id :{request.Id}");
        }

        productVariant.IsDeleted = true;

        await _novaHealthDbContext.SaveChangesAsync(cancellationToken);

        return true;
    }
}