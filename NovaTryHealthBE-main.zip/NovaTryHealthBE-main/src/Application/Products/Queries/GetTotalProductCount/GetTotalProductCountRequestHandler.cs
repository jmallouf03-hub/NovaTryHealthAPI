﻿using MediatR;
using Microsoft.EntityFrameworkCore;
using NovaHealth.Application.Common.Interfaces;

namespace NovaHealth.Application.Products.Queries.GetTotalProductCount;
public class GetTotalProductCountRequest : IRequest<GetTotalProductCountResponse> { }

public class GetTotalProductCountRequestHandler : IRequestHandler<GetTotalProductCountRequest, GetTotalProductCountResponse>
{
    private readonly INovaHealthDbContext _novaHealthDbContext;

    public GetTotalProductCountRequestHandler(INovaHealthDbContext novaHealthDbContext)
    {
        _novaHealthDbContext = novaHealthDbContext;

    }
    public async Task<GetTotalProductCountResponse> Handle(GetTotalProductCountRequest request, CancellationToken cancellationToken)
    {

        var totalCount = await _novaHealthDbContext.Products
                       .Where(x => !x.IsDeleted)
                        .CountAsync(cancellationToken);

        var totalActive = await _novaHealthDbContext.Products
                        .Where(x => x.IsActive && !x.IsDeleted)
                        .CountAsync(cancellationToken);

        var totalInactive = await _novaHealthDbContext.Products
                             .Where(x => !x.IsActive && !x.IsDeleted)
                             .CountAsync(cancellationToken);

        return new GetTotalProductCountResponse
        {
            TotalProductCount = totalCount,
            TotalActiveProdcut = totalActive,
            TotalInActiveProdcut = totalInactive
        };
    }
}
