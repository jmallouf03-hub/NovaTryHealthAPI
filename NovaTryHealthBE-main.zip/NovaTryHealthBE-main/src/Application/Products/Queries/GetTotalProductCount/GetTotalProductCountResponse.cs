﻿namespace NovaHealth.Application.Products.Queries.GetTotalProductCount;

public class GetTotalProductCountResponse
{
    public int TotalProductCount { get; set; } 

    public int TotalActiveProdcut { get; set; }

    public int TotalInActiveProdcut { get; set; }
}
