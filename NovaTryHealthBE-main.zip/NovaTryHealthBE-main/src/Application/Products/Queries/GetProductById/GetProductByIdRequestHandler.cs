﻿using MediatR;
using Microsoft.EntityFrameworkCore;
using NovaHealth.Application.Common.Exceptions;
using NovaHealth.Application.Common.Interfaces;
using System.Text.Json.Serialization;

namespace NovaHealth.Application.Products.Queries.GetProductById;

public record GetProductByIdRequest : IRequest<GetProductByIdsResponse>
{
    [JsonIgnore] public long ProductId { get; set; }
}

public class GetProductByIdsRequestHandler : IRequestHandler<GetProductByIdRequest, GetProductByIdsResponse>
{
    private readonly INovaHealthDbContext _novaHealthDbContext;

    public GetProductByIdsRequestHandler(INovaHealthDbContext novaHealthDbContext)
    {
        _novaHealthDbContext = novaHealthDbContext;
    }

    public async Task<GetProductByIdsResponse> Handle(GetProductByIdRequest request, CancellationToken cancellationToken)
    {
        var product = await _novaHealthDbContext.Products
                    .Where(p => p.Id == request.ProductId && !p.IsDeleted)
            .Select(p => new GetProductByIdsResponse
            {
                Id = p.Id,
                DrugName = p.DrugName,
                BrandName = p.BrandName,
                ShortName = p.ShortName,
                LabelerName = p.LabelerName,
                GenericName = p.GenericName,
                DosageForm = p.DosageForm,
                ConsultOnlyPrice = p.ConsultOnlyPrice,
                ProductType = p.ProductType,
                VariantCount = p.Variants.Count(v => !v.IsDeleted),
                IngredientCount = p.Ingredients.Count(i => !i.IsDeleted),
                Variants = p.Variants
                        .Where(v => !v.IsDeleted)
                        .Select(v => new ProductVariantDto
                        {
                            Id = v.Id,
                            Name = v.Name,
                            Price = v.Price,
                            ComparePrice = v.ComparePrice,
                            Quantity = v.Quantity,
                            QuantityUnit = v.QuantityUnit,
                            Refills = v.Refills,
                            Dose = v.Dose,
                            Dosage = v.Dosage,
                            Strength = v.Strength,
                            Packing = v.Packing,
                            Form = v.Form,
                            RegularImageUrlFileName = v.RegularImageUrlFileName,
                            TransparentImageUrlFileName = v.TransparentImageUrlFileName,
                            RegularImageUrlFilePath = v.RegularImageUrlFilePath,
                            TransparentImageUrlFilePath = v.TransparentImageUrlFilePath,
                            VideoUrl = v.VideoUrl,
                            Upc = v.Upc
                        }).ToList(),

                Ingredients = p.Ingredients
                            .Where(i => !i.IsDeleted)
                            .Select(i => new ProductIngredientDto
                            {
                                Id = i.Id,
                                Name = i.Name,
                                Strength = i.Strength
                            }).ToList()

            }).FirstOrDefaultAsync(cancellationToken);

        if (product == null)
            throw new NotFoundException($"Product with Id {request.ProductId} not found.");

        return product;
    }
}
