﻿using AutoMapper;
using AutoMapper.QueryableExtensions;
using MediatR;
using NovaHealth.Application.Common.Interfaces;
using NovaHealth.Application.Common.Mappings;
using NovaHealth.Application.Common.Models;
using System.Linq.Dynamic.Core;

namespace NovaHealth.Application.Products.Queries.GetProductList;

public class GetProductListRequest : PaginationFilter, IRequest<PaginationResponse<GetProductListResponse>> { }

public class GetProductListRequestHandler : IRequestHandler<GetProductListRequest, PaginationResponse<GetProductListResponse>>
{
    private readonly INovaHealthDbContext _novaHealthDbContext;
    private readonly IMapper _mapper;

    public GetProductListRequestHandler(INovaHealthDbContext novaHealthDbContext, IMapper mapper)
    {
        _novaHealthDbContext = novaHealthDbContext;
        _mapper = mapper;
    }

    public async Task<PaginationResponse<GetProductListResponse>> Handle(GetProductListRequest request, CancellationToken cancellationToken)
    {

        var productQuery = _novaHealthDbContext.Products
                            .Where(x => !x.IsDeleted)
                            .Select(x => new GetProductListResponse
                            {
                                ProductId = x.Id,
                                DrugName = x.DrugName,
                                BrandName = x.BrandName,
                                ShortName = x.ShortName,
                                LabelerName = x.LabelerName,
                                GenericName = x.GenericName,
                                IsActive = x.IsActive,
                                CreatedDate = x.CreatedDate,
                                ProductType = x.ProductType.ToString(),
                                DosageForm = x.DosageForm,
                            });

        if (!string.IsNullOrEmpty(request.Filter))
        {
            productQuery = productQuery.Where(request.Filter);
        }
        if (!string.IsNullOrEmpty(request.OrderBy))
        {
            productQuery = productQuery.OrderBy(request.OrderBy);
        }
        else
        {
            productQuery = productQuery.OrderByDescending(x => x.ProductId);
        }
        return await productQuery.ProjectTo<GetProductListResponse>(_mapper.ConfigurationProvider)
                    .PaginatedListAsync(request.PageNumber, request.PageSize);
    }
}