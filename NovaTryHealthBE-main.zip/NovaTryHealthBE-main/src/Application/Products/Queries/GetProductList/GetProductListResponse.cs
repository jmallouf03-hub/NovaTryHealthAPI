﻿using AutoMapper;

namespace NovaHealth.Application.Products.Queries.GetProductList;

public class GetProductListResponse
{
    public long? ProductId { get; set; }
    public string? DrugName { get; set; }
    public string? BrandName { get; set; }
    public string? ShortName { get; set; }
    public string? LabelerName { get; set; }
    public string? GenericName { get; set; }
    public string? ProductType { get; set; }
    public string? DosageForm { get; set; }
    public DateTime CreatedDate { get; set; }
    public bool IsActive { get; set; }

    public class Mapping : Profile
    {
        public Mapping()
        {
            CreateMap<GetProductListResponse, GetProductListResponse>();
        }
    }
}
