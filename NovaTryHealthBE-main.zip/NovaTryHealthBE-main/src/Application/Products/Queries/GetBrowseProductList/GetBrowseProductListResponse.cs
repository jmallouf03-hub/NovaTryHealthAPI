﻿using AutoMapper;

namespace NovaHealth.Application.Products.Queries.GetBrowseProductList;
public class GetBrowseProductListResponse
{
    public long? ProductId { get; set; }
    public string? DrugName { get; set; }
    //public string? BrandName { get; set; }
    //public string? ShortName { get; set; }
    //public string? LabelerName { get; set; }
    public decimal? ConsultOnlyPrice { get; set; }
    //public string? GenericName { get; set; }
    //public ProductTypeOption? ProductType { get; set; }
    //public string? DosageForm { get; set; }
    //public DateTime CreatedDate { get; set; }
    //public bool IsActive { get; set; }
    public long? IngredienId { get; set; }
    public string? IngredienName { get; set; }
    public string? IngredienStrength { get; set; }
    public long? VariantId { get; set; }
    public string? VariantName { get; set; }
    public decimal TotalPrice { get; set; }
    public decimal TotalComparePrice { get; set; }
    public int TotalVariant { get; set; }
    public string? RegularImageUrlFileName { get; set; }
    public string? RegularImageUrlFilePath { get; set; }

    public string? TransparentImageUrlFileName { get; set; }
    public string? TransparentImageUrlFilePath { get; set; }





    public class Mapping : Profile
    {
        public Mapping()
        {
            CreateMap<GetBrowseProductListResponse, GetBrowseProductListResponse>();
        }
    }
}