﻿using AutoMapper;
using AutoMapper.QueryableExtensions;
using MediatR;
using NovaHealth.Application.Common.Interfaces;
using NovaHealth.Application.Common.Mappings;
using NovaHealth.Application.Common.Models;
using System.Linq.Dynamic.Core;

namespace NovaHealth.Application.Products.Queries.GetBrowseProductList;


public class GetBrowseProductListRequest : PaginationFilter, IRequest<PaginationResponse<GetBrowseProductListResponse>> { }

public class GetBrowseProductListRequestHandler : IRequestHandler<GetBrowseProductListRequest, PaginationResponse<GetBrowseProductListResponse>>
{
    private readonly INovaHealthDbContext _novaHealthDbContext;
    private readonly IMapper _mapper;

    public GetBrowseProductListRequestHandler(INovaHealthDbContext novaHealthDbContext, IMapper mapper)
    {
        _novaHealthDbContext = novaHealthDbContext;
        _mapper = mapper;
    }
    public async Task<PaginationResponse<GetBrowseProductListResponse>> Handle(GetBrowseProductListRequest request, CancellationToken cancellationToken)
    {
        var productQuery = _novaHealthDbContext.Products
                          .Where(x => !x.IsDeleted)
             .Select(x => new GetBrowseProductListResponse
             {
                 ProductId = x.Id,
                 DrugName = x.DrugName,
                 ConsultOnlyPrice = x.ConsultOnlyPrice,
                 TotalPrice = x.Variants.Sum(v => v.Price),
                 TotalComparePrice = x.Variants.Sum(v => v.ComparePrice),
                 TotalVariant = x.Variants.Count(),

                 VariantId = x.Variants.Select(v => v.Id).FirstOrDefault(),
                 VariantName = x.Variants.Select(v => v.Name).FirstOrDefault(),
                 RegularImageUrlFileName = x.Variants.Select(v => v.RegularImageUrlFileName).FirstOrDefault(),
                 RegularImageUrlFilePath = x.Variants.Select(v => v.RegularImageUrlFilePath).FirstOrDefault(),
                 TransparentImageUrlFileName = x.Variants.Select(v => v.TransparentImageUrlFileName).FirstOrDefault(),
                 TransparentImageUrlFilePath = x.Variants.Select(v => v.TransparentImageUrlFilePath).FirstOrDefault(),
                 IngredienId = x.Ingredients.Select(i => i.Id).FirstOrDefault(),
                 IngredienName = x.Ingredients.Select(i => i.Name).FirstOrDefault(),
                 IngredienStrength = x.Ingredients.Select(i => i.Strength).FirstOrDefault(),
             });

        if (!string.IsNullOrEmpty(request.Filter))
        {
            productQuery = productQuery.Where(request.Filter);
        }
        if (!string.IsNullOrEmpty(request.OrderBy))
        {
            productQuery = productQuery.OrderBy(request.OrderBy);
        }
        else
        {
            productQuery = productQuery.OrderByDescending(x => x.ProductId);
        }
        return await productQuery.ProjectTo<GetBrowseProductListResponse>(_mapper.ConfigurationProvider)
                    .PaginatedListAsync(request.PageNumber, request.PageSize);
    }
}