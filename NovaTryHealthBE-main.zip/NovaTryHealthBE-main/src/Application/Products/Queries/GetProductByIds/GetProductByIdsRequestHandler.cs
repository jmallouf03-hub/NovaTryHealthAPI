﻿using MediatR;
using Microsoft.EntityFrameworkCore;
using NovaHealth.Application.Common.Exceptions;
using NovaHealth.Application.Common.Interfaces;

namespace NovaHealth.Application.Products.Queries.GetProductByIds;

public record GetProductByIdsRequest : IRequest<List<GetProductsByIdsResponse>>
{
    public List<long> ProductIds { get; set; } = new List<long>();
}

public class GetProductByIdsRequestHandler : IRequestHandler<GetProductByIdsRequest, List<GetProductsByIdsResponse>>
{
    private readonly INovaHealthDbContext _novaHealthDbContext;

    public GetProductByIdsRequestHandler(INovaHealthDbContext novaHealthDbContext)
    {
        _novaHealthDbContext = novaHealthDbContext;
    }

    public async Task<List<GetProductsByIdsResponse>> Handle(GetProductByIdsRequest request, CancellationToken cancellationToken)
    {
        if (request.ProductIds == null || !request.ProductIds.Any())
            throw new ArgumentException("ProductIds list cannot be empty.");

        var products = await _novaHealthDbContext.Products
            .Where(p => request.ProductIds.Contains(p.Id) && !p.IsDeleted)
            .Select(p => new GetProductsByIdsResponse
            {
                Id = p.Id,
                DrugName = p.DrugName,
                BrandName = p.BrandName,
                ShortName = p.ShortName,
                LabelerName = p.LabelerName,
                GenericName = p.GenericName,
                DosageForm = p.DosageForm,
                ConsultOnlyPrice = p.ConsultOnlyPrice,
                ProductType = p.ProductType,
                Variants = p.Variants
                    .Where(v => !v.IsDeleted)
                    .Select(v => new ProductVariantDto
                    {
                        Id = v.Id,
                        Name = v.Name,
                        Price = v.Price,
                        ComparePrice = v.ComparePrice,
                        Quantity = v.Quantity,
                        QuantityUnit = v.QuantityUnit,
                        Refills = v.Refills,
                        Dose = v.Dose,
                        Dosage = v.Dosage,
                        Strength = v.Strength,
                        Packing = v.Packing,
                        Form = v.Form,
                        RegularImageUrlFileName = v.RegularImageUrlFileName,
                        TransparentImageUrlFileName = v.TransparentImageUrlFileName,
                        RegularImageUrlFilePath = v.RegularImageUrlFilePath,
                        TransparentImageUrlFilePath = v.TransparentImageUrlFilePath,
                        VideoUrl = v.VideoUrl,
                        Upc = v.Upc
                    }).ToList(),

                Ingredients = p.Ingredients
                    .Where(i => !i.IsDeleted)
                    .Select(i => new ProductIngredientDto
                    {
                        Id = i.Id,
                        Name = i.Name,
                        Strength = i.Strength
                    }).ToList()

            }).ToListAsync(cancellationToken);

        if (products == null || !products.Any())
            throw new NotFoundException("No products found for provided IDs.");

        return products;
    }
}