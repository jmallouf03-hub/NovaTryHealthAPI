﻿
namespace NovaHealth.Application.UserTimeLineEvent.Command.AddUserTimelineEvent
{
    internal class AddTimelineEventRequestHandler
    {
    }
}
