﻿using System.ComponentModel.DataAnnotations;

namespace NovaHealth.Application;

public class AppSettings : IValidatableObject
{
    public string NovaHealthUrl { get; set; } = null!;

    public string PaymentSuccessUrl { get; set; } = null!;

    public string PaymentCancelUrl { get; set; } = null!;

    public string PropertyManagementUrl { get; set; } = null!;

    public string DomainUrl { get; set; } = null!;

    public string StripeLogo { get; set; } = null!;

    public string ContentRootPath { get; set; } = null!;

    public string ThankYouUrl { get; set; } = null!;

    public string AppId { get; set; } = null!;

    public string AppCertificate { get; set; } = null!;

    public string VideoCallUrl { get; set; } = null!;

    public string Country { get; set; } = null!;

    public string Currency { get; set; } = null!;

    public string SupportEmail { get; set; } = null!;

    public string SupportPhone { get; set; } = null!;

    public string SupportUrl { get; set; } = null!;

    public string ShareDocumentURL { get; set; } = null!;

    public string Url { get; set; } = null!;

    public string Mcc { get; set; } = null!;

    public string CountryCode { get; set; } = null!;

    public string HereApiUrl { get; set; } = null!;

    public string HereApiKey { get; set; } = null!;

    public string OpenFdaApiUrl { get; set; } = null!;

    public string RxNormApiUrl { get; set; } = null!;

    public string GoogleClientId { get; set; } = null!;

    public string GoogleClientSecret { get; set; } = null!;

    public string RedirectUri { get; set; } = null!;

    public string AppointmentListURL { get; set; } = null!;

    public bool IsOtpBypassed { get; set; }

    public FileStorageOption DefaultFileStorage { get; set; } = FileStorageOption.Local;

    public VerifyExpirySettings VerifyExpirySettings { get; set; } = null!;

    public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
    {
        if (string.IsNullOrEmpty(PropertyManagementUrl))
        {
            yield return new ValidationResult("No StaffManagementUrl defined in AppSettings config", new[] { nameof(PropertyManagementUrl) });
        }
    }
}

public class VerifyExpirySettings
{
    public VerifyExpirySettingsData Email { get; set; } = null!;

    public VerifyExpirySettingsData Phone { get; set; } = null!;
}

public record VerifyExpirySettingsData
{
    public int ExpiryInSeconds { get; set; }

    public int CanSendInSeconds { get; set; }
}

public class StripeSettings
{
    public string PublishableKey { get; set; } = null!;

    public string SecretKey { get; set; } = null!;
}