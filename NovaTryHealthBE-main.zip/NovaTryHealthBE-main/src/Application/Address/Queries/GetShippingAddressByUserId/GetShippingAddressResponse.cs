﻿namespace NovaHealth.Application.Address.Queries.GetShippingAddressByUserId;

public class GetShippingAddressResponse
{
    public long UserId { get; set; }

    public string? Address1 { get; set; } 

    public string? Address2 { get; set; }

    public string? City { get; set; } 

    public int StateId { get; set; } 

    public string? ZipCode { get; set; } 
}
