﻿using MediatR;
using System.Text.Json.Serialization;
using NovaHealth.Application.Common.Interfaces;
using NovaHealth.Application.Common.Exceptions;
using Microsoft.EntityFrameworkCore;

namespace NovaHealth.Application.Address.Queries.GetShippingAddressByUserId;
public record GetShippingAddressRequest : IRequest<GetShippingAddressResponse>
{
    [JsonIgnore] public long UserId { get; set; }
}
public class GetShippingAddressByUserIdRequestHandler : IRequestHandler<GetShippingAddressRequest, GetShippingAddressResponse>
{
    private readonly INovaHealthDbContext _novaHealthDbContext;

    public GetShippingAddressByUserIdRequestHandler(INovaHealthDbContext novaHealthDbContext)
    {
        _novaHealthDbContext = novaHealthDbContext;
    }
    public async Task<GetShippingAddressResponse> Handle(GetShippingAddressRequest request, CancellationToken cancellationToken)
    {
        var shippingAddress = await _novaHealthDbContext.UserAddress
                            .Include(x => x.State)
                            .FirstOrDefaultAsync(x => x.UserId == request.UserId && !x.IsDeleted, cancellationToken);

        if (shippingAddress == null)
        {
            return new GetShippingAddressResponse();
        }


        return new GetShippingAddressResponse
        {
            UserId = shippingAddress.UserId,
            Address1 = shippingAddress.Address1,
            Address2 = shippingAddress.Address2,
            City = shippingAddress.City,
            StateId = shippingAddress.State.Id,
            ZipCode = shippingAddress.ZipCode,

        };
    }
}