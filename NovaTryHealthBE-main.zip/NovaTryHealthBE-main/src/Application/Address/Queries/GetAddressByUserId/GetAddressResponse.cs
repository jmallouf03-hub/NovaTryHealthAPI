﻿    namespace NovaHealth.Application.Address.Queries.GetAddressByUserId;
public class GetAddressResponse
{
    public long UserId { get; set; }

    public string? FirstName { get; set; }

    public string? LastName { get; set; } 

    public string? PhoneNumber { get; set; }

    public DateTime? DateOfBirth { get; set; }

    public string? Email { get; set; }
}
