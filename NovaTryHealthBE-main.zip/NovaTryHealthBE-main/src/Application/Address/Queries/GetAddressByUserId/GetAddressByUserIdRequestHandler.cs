﻿using MediatR;
using Microsoft.EntityFrameworkCore;
using NovaHealth.Application.Common.Exceptions;
using NovaHealth.Application.Common.Interfaces;
using Stripe;
using System.Text.Json.Serialization;

namespace NovaHealth.Application.Address.Queries.GetAddressByUserId;

public record GetAddressByUserIdRequest : IRequest<GetAddressResponse>
{
    [JsonIgnore] public long UserId { get; set; }
}
public class GetAddressByUserIdRequestHandler : IRequestHandler<GetAddressByUserIdRequest, GetAddressResponse>
{
    private readonly INovaHealthDbContext _novaHealthDbContext;

    public GetAddressByUserIdRequestHandler(INovaHealthDbContext novaHealthDbContext)
    {
        _novaHealthDbContext = novaHealthDbContext;
    }
    public async Task<GetAddressResponse> Handle(GetAddressByUserIdRequest request, CancellationToken cancellationToken)
    {

        var accountDetal = await _novaHealthDbContext.Users
                          .FirstOrDefaultAsync(u => u.Id == request.UserId && !u.IsDeleted, cancellationToken);

        if (accountDetal == null)
        {
            return new GetAddressResponse();
        }

        return new GetAddressResponse
        {
            UserId = accountDetal.Id,
            FirstName = accountDetal.FirstName,
            LastName = accountDetal.LastName,
            Email = accountDetal.Email,
            PhoneNumber = accountDetal.PhoneNumber,
            DateOfBirth = accountDetal.DateOfBirth,
        };
    }
}