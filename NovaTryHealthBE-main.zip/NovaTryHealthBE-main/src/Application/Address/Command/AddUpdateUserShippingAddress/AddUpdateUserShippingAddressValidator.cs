﻿using FluentValidation;

namespace NovaHealth.Application.Address.Command.AddUpdateUserShippingAddress;
public class AddUpdateUserShippingAddressValidator : AbstractValidator<AddUpdateUserShippingAddressRequest>
{
    public AddUpdateUserShippingAddressValidator()
    {
        //RuleFor(x => x.Address1)
        //   .NotEmpty().WithMessage("Address1 is required.")
        //   .MaximumLength(200).WithMessage("Address1 cannot exceed 200 characters.");

        //RuleFor(x => x.Address2)
        //   .NotEmpty().WithMessage("Address2 is required.")
        //    .MaximumLength(200).WithMessage("Address2 cannot exceed 200 characters.");
        //.NotEqual(x => x.Address1).WithMessage("Address2 should not be the same as Address1.");

        RuleFor(x => x.City)
            .NotEmpty().WithMessage("City is required.")
            .MaximumLength(100).WithMessage("City cannot exceed 100 characters.");

        RuleFor(x => x.StateId)
                .GreaterThan(0).WithMessage("StateId must be greater than 0.");


        RuleFor(x => x.ZipCode)
          .NotEmpty().WithMessage("Zip Code is required.")
          .Matches(@"^\d{5}$").WithMessage("ZipCode Code must be exactly 5 digits.");
    }
}
