﻿using AutoMapper.Execution;
using MediatR;
using Microsoft.EntityFrameworkCore;
using NovaHealth.Application.Common.FileStorage;
using NovaHealth.Application.Common.Interfaces;
using NovaHealth.Domain.Entities;
namespace NovaHealth.Application.Address.Command.AddUpdateUserShippingAddress;
public class AddUpdateUserShippingAddressRequestHandler : IRequestHandler<AddUpdateUserShippingAddressRequest, bool>
{
    private readonly INovaHealthDbContext _novaHealthDbContext;

    public AddUpdateUserShippingAddressRequestHandler(INovaHealthDbContext novaHealthDbContext)
    {
        _novaHealthDbContext = novaHealthDbContext;
    }

    public async Task<bool> Handle(AddUpdateUserShippingAddressRequest request, CancellationToken cancellationToken)
    {
        var user = await _novaHealthDbContext.Users
                   .FirstOrDefaultAsync(x => x.Id == request.UserId && !x.IsDeleted, cancellationToken);

        if (user == null)
        {
            throw new Exception("User not found");
        }

        // Check if address already exists for this user
        var shippingAddress = await _novaHealthDbContext.UserAddress
            .FirstOrDefaultAsync(x => x.UserId == request.UserId && !x.IsDeleted, cancellationToken);

        if (shippingAddress != null)
        {
            // Update existing address
            shippingAddress.Address1 = request.Address1;
            shippingAddress.Address2 = request.Address2;
            shippingAddress.City = request.City;
            shippingAddress.StateId = request.StateId;
            shippingAddress.ZipCode = request.ZipCode;
            shippingAddress.IsActive = true;
        }
        else
        {
            // Insert new address
            var newShippingAddress = new UserAddress
            {
                UserId = request.UserId,
                Address1 = request.Address1,
                Address2 = request.Address2,
                City = request.City,
                StateId = request.StateId,
                ZipCode = request.ZipCode,
                IsActive = true,
                IsDeleted = false,
                CreatedDate = DateTime.UtcNow,
            };

            await _novaHealthDbContext.UserAddress.AddAsync(newShippingAddress, cancellationToken);
        }
        await _novaHealthDbContext.SaveChangesAsync(cancellationToken);
        return true;
    }
}

