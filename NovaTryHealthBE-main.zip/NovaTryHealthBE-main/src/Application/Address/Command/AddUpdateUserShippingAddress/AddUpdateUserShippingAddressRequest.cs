﻿using MediatR;

namespace NovaHealth.Application.Address.Command.AddUpdateUserShippingAddress;
public class AddUpdateUserShippingAddressRequest : IRequest<bool>
{
    public long UserId { get; set; }

    public string Address1 { get; set; } = null!;

    public string? Address2 { get; set; } 

    public string City { get; set; } = null!;

    public int StateId { get; set; }

    public string ZipCode { get; set; } = null!;
}
