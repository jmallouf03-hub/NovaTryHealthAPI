﻿using MediatR;

namespace NovaHealth.Application.Address.Command.AddUpdateUserAddress;

public class AddUpdateUserAddressRequest : IRequest<bool>
{
    public long UserId { get; set; }

    public string FirstName { get; set; } = null!;

    public string LastName { get; set; } = null!;

    public string? PhoneNumber { get; set; }

    public DateTime? DateOfBirth { get; set; }

    public string Email { get; set; } = null!;
}
