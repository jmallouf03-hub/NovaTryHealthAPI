﻿using MediatR;
using Microsoft.EntityFrameworkCore;
using NovaHealth.Application.Common.Interfaces;

namespace NovaHealth.Application.Address.Command.AddUpdateUserAddress;
public class AddUpdateUserAddressRequestHandler : IRequestHandler<AddUpdateUserAddressRequest, bool>
{
    private readonly INovaHealthDbContext _novaHealthDbContext;

    public AddUpdateUserAddressRequestHandler(INovaHealthDbContext novaHealthDbContext)
    {
        _novaHealthDbContext = novaHealthDbContext;
    }

    public async Task<bool> Handle(AddUpdateUserAddressRequest request, CancellationToken cancellationToken)
    {
        var user = await _novaHealthDbContext.Users
                   .FirstOrDefaultAsync(x => x.Id == request.UserId && x.IsActive && !x.IsDeleted, cancellationToken);

        if (user == null)
        {
            throw new Exception("User not found.");
        }   

        user.FirstName = request.FirstName;
        user.LastName = request.LastName;
        user.Email = request.Email;
        user.PhoneNumber = request.PhoneNumber;
        user.DateOfBirth = request.DateOfBirth;
        user.IsActive = true;

        await _novaHealthDbContext.SaveChangesAsync(cancellationToken);
        return true;
    }
}
