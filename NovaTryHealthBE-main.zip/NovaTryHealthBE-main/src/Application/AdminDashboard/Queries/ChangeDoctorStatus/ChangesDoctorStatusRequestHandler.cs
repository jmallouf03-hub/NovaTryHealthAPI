﻿using MediatR;
using Microsoft.EntityFrameworkCore;
using NovaHealth.Application.Common.Exceptions;
using NovaHealth.Application.Common.Interfaces;

namespace NovaHealth.Application.AdminDashboard.Queries.ChangeDoctorStatus;
public class ChangesDoctorStatusRequest : IRequest<bool>
{
    public long UserId { get; set; }

    public bool IsDisabledByAdmin { get; set; }
}
public class ChangesDoctorStatusRequestHandler : IRequestHandler<ChangesDoctorStatusRequest, bool>
{
    private readonly INovaHealthDbContext _novaHealthDbContext;

    public ChangesDoctorStatusRequestHandler(INovaHealthDbContext novaHealthDbContext)
    {
        _novaHealthDbContext = novaHealthDbContext;
    }

    public async Task<bool> Handle(ChangesDoctorStatusRequest request, CancellationToken cancellationToken)
    {
        var user = await _novaHealthDbContext.Users
                  .Include(u => u.UserRoles).ThenInclude(ur => ur.Role)
                  .FirstOrDefaultAsync(x => x.Id == request.UserId, cancellationToken);

        if (user == null)
             throw new NotFoundException($"Cannot find user with UserId: {request.UserId}");
         
        // Step 2: Only check for patient role if disabling
        //if (request.IsDisabledByAdmin)
        //{
        //    var isDoctor = user.UserRoles
        //        .Any(ur => ur.IsActive && !ur.IsDeleted && ur.Role.RoleType == RoleType.Doctor);

        //    if (!isDoctor)
        //        throw new InvalidOperationException("Only doctor accounts can be disabled by admin.");
        //}
        user.IsDisabledByAdmin = request.IsDisabledByAdmin;

        await _novaHealthDbContext.SaveChangesAsync(cancellationToken);

        return true;
    }
}