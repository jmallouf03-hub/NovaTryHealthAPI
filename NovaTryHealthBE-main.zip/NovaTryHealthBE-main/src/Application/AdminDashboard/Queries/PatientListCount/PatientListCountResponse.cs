﻿namespace NovaHealth.Application.AdminDashboard.Queries.PatientListCount;

public class PatientListCountResponse
{
    public int TotalPatients { get; set; }

    public int NewPatientsCurrentWeek { get; set; }

    public int NewPatientsLastWeek { get; set; }

    public WeeklyPatientStats? CurrentWeek { get; set; }

    public WeeklyPatientStats? LastWeek { get; set; }

}
public class WeeklyPatientStats
{
    public int Sunday { get; set; }

    public int Monday { get; set; }

    public int Tuesday { get; set; }

    public int Wednesday { get; set; }

    public int Thursday { get; set; }

    public int Friday { get; set; }

    public int Saturday { get; set; }
}
