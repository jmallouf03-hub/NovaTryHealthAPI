﻿using MediatR;
using Microsoft.EntityFrameworkCore;
using NovaHealth.Application.Common.Interfaces;

namespace NovaHealth.Application.AdminDashboard.Queries.PatientListCount;

public class PatientListCountRequest : IRequest<PatientListCountResponse> { }

public class PatientListCountRequestHandler : IRequestHandler<PatientListCountRequest, PatientListCountResponse>
{
    private readonly INovaHealthDbContext _context;

    public PatientListCountRequestHandler(INovaHealthDbContext context)
    {
        _context = context;
    }

    public async Task<PatientListCountResponse> Handle(PatientListCountRequest request, CancellationToken cancellationToken)
    {
        var today = DateTime.UtcNow.Date;

        var startOfCurrentWeek = today.AddDays(-(int)today.DayOfWeek);
        var endOfCurrentWeek = startOfCurrentWeek.AddDays(7);

        var startOfLastWeek = startOfCurrentWeek.AddDays(-7);
        var endOfLastWeek = startOfCurrentWeek;

        // Total patients count
        var totalPatients = await _context.Users
            .Where(u => !u.IsDeleted && u.IsActive && u.UserRoles.Any(ur => ur.Role.RoleType == RoleType.Patient))
            .CountAsync(cancellationToken);

        // Helper to get count of patients grouped by day for a date range
        async Task<WeeklyPatientStats> GetWeeklyStats(DateTime startDate, DateTime endDate)
        {
            var patients = await _context.Users
                .Where(u => !u.IsDeleted && u.IsActive && u.UserRoles.Any(ur => ur.Role.RoleType == RoleType.Patient)
                            && u.CreatedDate >= startDate && u.CreatedDate < endDate)
                .Select(u => u.CreatedDate.Date)
                .ToListAsync(cancellationToken);

            var stats = new WeeklyPatientStats();

            foreach (var date in patients)
            {
                switch (date.DayOfWeek)
                {
                    case DayOfWeek.Sunday: stats.Sunday++; break;
                    case DayOfWeek.Monday: stats.Monday++; break;
                    case DayOfWeek.Tuesday: stats.Tuesday++; break;
                    case DayOfWeek.Wednesday: stats.Wednesday++; break;
                    case DayOfWeek.Thursday: stats.Thursday++; break;
                    case DayOfWeek.Friday: stats.Friday++; break;
                    case DayOfWeek.Saturday: stats.Saturday++; break;
                }
            }

            return stats;
        }

        var currentWeekStats = await GetWeeklyStats(startOfCurrentWeek, endOfCurrentWeek);
        var lastWeekStats = await GetWeeklyStats(startOfLastWeek, endOfLastWeek);

        int totalCurrentWeekPatients = currentWeekStats.Sunday + currentWeekStats.Monday + currentWeekStats.Tuesday +
                               currentWeekStats.Wednesday + currentWeekStats.Thursday + currentWeekStats.Friday +
                               currentWeekStats.Saturday;

        int totalLastWeekPatients = lastWeekStats.Sunday + lastWeekStats.Monday + lastWeekStats.Tuesday +
                                    lastWeekStats.Wednesday + lastWeekStats.Thursday + lastWeekStats.Friday +
                                    lastWeekStats.Saturday;

        return new PatientListCountResponse
        {
            TotalPatients = totalPatients,
            CurrentWeek = currentWeekStats,
            LastWeek = lastWeekStats,
            NewPatientsCurrentWeek = totalCurrentWeekPatients,
            NewPatientsLastWeek = totalLastWeekPatients
        };
    }
}
