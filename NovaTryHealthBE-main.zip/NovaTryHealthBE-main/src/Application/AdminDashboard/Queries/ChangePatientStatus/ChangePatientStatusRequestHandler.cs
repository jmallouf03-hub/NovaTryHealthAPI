﻿using MediatR;
using Microsoft.EntityFrameworkCore;
using NovaHealth.Application.Common.Exceptions;
using NovaHealth.Application.Common.Interfaces;

namespace NovaHealth.Application.Admin.Command.ChangePatientStatus;

public class ChangePatientStatusRequest : IRequest<bool>
{
    public long UserId { get; set; }
    public bool IsDisabledByAdmin { get; set; }
}

public class ChangePatientStatusRequestHandler : IRequestHandler<ChangePatientStatusRequest, bool>
{
    private readonly INovaHealthDbContext _novaHealthDbContext;

    public ChangePatientStatusRequestHandler(INovaHealthDbContext novaHealthDbContext)
    {
        _novaHealthDbContext = novaHealthDbContext;
    }

    public async Task<bool> Handle(ChangePatientStatusRequest request, CancellationToken cancellationToken)
    {
        // Step 1: Get the user
        var user = await _novaHealthDbContext.Users
                  .Include(u => u.UserRoles).ThenInclude(ur => ur.Role)
                  .FirstOrDefaultAsync(x => x.Id == request.UserId, cancellationToken);

        if (user == null)
            throw new NotFoundException($"Cannot find user with UserId: {request.UserId}");

        // Step 2: Only check for patient role if disabling
        //if (request.IsDisabledByAdmin)
        //{
        //    var isPatient = user.UserRoles
        //        .Any(ur => ur.IsActive && !ur.IsDeleted && ur.Role.RoleType == RoleType.Patient);

        //    if (!isPatient)
        //        throw new InvalidOperationException("Only patient accounts can be disabled by admin.");
        //}

        // Step 3: Set status and save
        user.IsDisabledByAdmin = request.IsDisabledByAdmin;

        await _novaHealthDbContext.SaveChangesAsync(cancellationToken);

        return true;
    }
}