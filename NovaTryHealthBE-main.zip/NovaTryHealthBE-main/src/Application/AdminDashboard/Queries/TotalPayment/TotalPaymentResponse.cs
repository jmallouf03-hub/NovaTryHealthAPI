﻿namespace NovaHealth.Application.AdminDashboard.Queries.TotalPayment;

public class TotalPaymentResponse
{
    public decimal Succeeded { get; set; }

    public decimal Uncaptured { get; set; }

    public decimal Refunded { get; set; }

    public decimal Failed { get; set; }
}