﻿using MediatR;
using Microsoft.EntityFrameworkCore;
using NovaHealth.Application.Common.Interfaces;

namespace NovaHealth.Application.AdminDashboard.Queries.TotalPayment;

public class TotalPaymentRequest : IRequest<TotalPaymentResponse> { }

public class TotalPaymentRequestHandler : IRequestHandler<TotalPaymentRequest, TotalPaymentResponse>
{

    private readonly INovaHealthDbContext _context;

    public TotalPaymentRequestHandler(INovaHealthDbContext context)
    {
        _context = context;
    }

    public async Task<TotalPaymentResponse> Handle(TotalPaymentRequest request, CancellationToken cancellationToken)
    {

        var succeeded = await _context.BookOrders
                         .Where(p => p.PaymentStatus == PaymentStatusType.Completed)
                         .SumAsync(p => (decimal?)p.Amount) ?? 0;

        var uncaptured = await _context.BookOrders
                        .Where(p => p.PaymentStatus == PaymentStatusType.Pending)
                        .SumAsync(p => (decimal?)p.Amount) ?? 0;

        var refunded = await _context.BookOrders
                    .Where(p => p.PaymentStatus == PaymentStatusType.Refunded)
                    .SumAsync(p => (decimal?)p.Amount) ?? 0;

        var failed = await _context.BookOrders
                    .Where(p => p.PaymentStatus == PaymentStatusType.Failed)
                    .SumAsync(p => (decimal?)p.Amount) ?? 0;


        return new TotalPaymentResponse
        {
            Succeeded = succeeded,
            Uncaptured = uncaptured,
            Refunded = refunded,
            Failed = failed
        };
    }
}