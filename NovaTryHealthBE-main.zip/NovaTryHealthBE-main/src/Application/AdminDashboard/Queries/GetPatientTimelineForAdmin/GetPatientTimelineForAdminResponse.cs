﻿using NovaHealth.Domain.Entities;
namespace NovaHealth.Application.AdminDashboard.Queries.GetPatientTimelineForAdmin;

public class GetPatientTimelineForAdminResponse
{
    public long UserId { get; set; }

    public string? EventType { get; set; }  // stored as string
    public string? Title { get; set; }
    public string? Description { get; set; }
    public DateTimeOffset EventDate { get; set; }
    public string? CreatedBy { get; set; }
    public string? Metadata { get; set; }   // JSON
    public long? BookOrderId { get; set; }

    public Guid GuidNumber { get; set; }
    public string? Guid { get; set; } 
}
