﻿using MediatR;
using Microsoft.EntityFrameworkCore;
using NovaHealth.Application.Common.Interfaces;

namespace NovaHealth.Application.AdminDashboard.Queries.GetPatientTimelineForAdmin;

public class GetPatientTimelineForAdminRequest : IRequest<List<GetPatientTimelineForAdminResponse>>
{
    public long UserId { get; set; }
}

public class GetPatientTimelineForAdminRequestHandler : IRequestHandler<GetPatientTimelineForAdminRequest, List<GetPatientTimelineForAdminResponse>>
{
    private readonly INovaHealthDbContext _novaHealthDbContext;

    public GetPatientTimelineForAdminRequestHandler(INovaHealthDbContext novaHealthDbContext)
    {
        _novaHealthDbContext = novaHealthDbContext;
    }
    public async Task<List<GetPatientTimelineForAdminResponse>> Handle(GetPatientTimelineForAdminRequest request, CancellationToken cancellationToken)
    {

        var timeLine = await _novaHealthDbContext.TimelineEvents
                       .Where(o => o.UserId == request.UserId).OrderByDescending(o => o.EventDate)

                        .Select(o => new GetPatientTimelineForAdminResponse
                        {
                            UserId = o.UserId,
                            // User = o.User,
                            EventType = o.EventType,
                            Title = o.Title,
                            Description = o.Description,
                            EventDate = o.EventDate,
                            CreatedBy = o.CreatedBy,
                            Metadata = o.Metadata,
                            BookOrderId = o.EventType == TimelineEventType.Order.ToString()
                                        ? _novaHealthDbContext.BookOrders
                                        .Where(b => b.UserId == o.UserId).OrderByDescending(b => b.CreatedDate)
                                        // latest order first
                                        .Select(b => (long?)b.Id)
                                        .FirstOrDefault() ?? 0 : 0,


                            GuidNumber = o.EventType == TimelineEventType.Order.ToString() ? _novaHealthDbContext.BookOrders
                                        .Where(b => b.UserId == o.UserId).OrderByDescending(b => b.CreatedDate)
                                        .Select(b => b.Guid).FirstOrDefault() : Guid.Empty,


                            // Short GUID (last 6 characters)
                            Guid = o.EventType == TimelineEventType.Order.ToString()
                                    ? _novaHealthDbContext.BookOrders.Where(b => b.UserId == o.UserId)
                                        .OrderByDescending(b => b.CreatedDate)
                                        .Select(b => b.Guid.ToString("N").Substring(26, 6))
                                        .FirstOrDefault() : null

                        }).ToListAsync(cancellationToken);

        return timeLine;
    }
}