﻿using AutoMapper;

namespace NovaHealth.Application.AdminDashboard.Queries.GetMessageListByRoleType;

public class GetMessageListByRoleTypeRespose
{

    public long ReceiverId { get; set; }

    public long SenderId { get; set; }

    //public long PatientId { get; set; }

    //public long ProviderId { get; set; }
    public string? MessageContent { get; set; }

    public string? SenderName { get; set; }

    public int UnreadMessageCount { get; set; }

    public long UserId { get; set; }

    public DateTime CreatedDate { get; set; }

    public long SuperParentMessageId { get; set; }
    public string? DoctorName { get; set; }
    public string? PatientName { get; set; }

    public string? SenderProfilePictureName { get; set; }

    public string? SenderProfilePicturePath { get; set; }
    public string? PatienProfilePictureName { get; set; }

    public string? PatienProfilePicturePath { get; set; }
    public class Mapping : Profile
    {
        public Mapping()
        {
            CreateMap<GetMessageListByRoleTypeRespose, GetMessageListByRoleTypeRespose>();
        }
    }
}
