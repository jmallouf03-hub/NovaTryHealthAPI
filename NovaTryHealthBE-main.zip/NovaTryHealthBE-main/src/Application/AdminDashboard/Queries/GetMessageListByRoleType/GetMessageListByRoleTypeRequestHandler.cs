﻿using MediatR;
using NovaHealth.Application.Common.Interfaces;
using NovaHealth.Application.Common.Models;
using Microsoft.EntityFrameworkCore;
using System.Linq.Dynamic.Core;
using System.Text.Json.Serialization;
using NovaHealth.Application.Common.Mappings;

namespace NovaHealth.Application.AdminDashboard.Queries.GetMessageListByRoleType;

public class GetMessageListByRoleTypeRequest : PaginationFilter, IRequest<PaginationResponse<GetMessageListByRoleTypeRespose>>
{
    [JsonIgnore] public RoleType Type { get; set; }
}

public class GetMessageListByRoleTypeRequestHandler : IRequestHandler<GetMessageListByRoleTypeRequest, PaginationResponse<GetMessageListByRoleTypeRespose>>
{
    private readonly INovaHealthDbContext _novaHealthDbContext;

    public GetMessageListByRoleTypeRequestHandler(INovaHealthDbContext novaHealthDbContext)
    {
        _novaHealthDbContext = novaHealthDbContext;
    }

    public async Task<PaginationResponse<GetMessageListByRoleTypeRespose>> Handle(GetMessageListByRoleTypeRequest request, CancellationToken cancellationToken)
    {
        // Get all doctor & patient user IDs in a single DB call
        var userRoles = await _novaHealthDbContext.UserRoles
                        .Select(ur => new { ur.UserId, ur.Role.RoleType })
                        .ToListAsync(cancellationToken);

        var doctorIds = userRoles
                        .Where(x => x.RoleType == RoleType.Doctor)
                        .Select(x => x.UserId)
                        .ToList();

        var patientIds = userRoles
                        .Where(x => x.RoleType == RoleType.Patient)
                        .Select(x => x.UserId)
                        .ToList();

        var currentUserIds = request.Type == RoleType.Doctor ? doctorIds : patientIds;

        var recipientMessagesQuery = from recipient in _novaHealthDbContext.MessageRecipients
                                     join message in _novaHealthDbContext.Messages on recipient.MessageId equals message.Id
                                     join sender in _novaHealthDbContext.MessageSenders on message.Id equals sender.MessageId
                                     join senderUser in _novaHealthDbContext.Users on sender.SenderId equals senderUser.Id
                                     join receiverUser in _novaHealthDbContext.Users on recipient.ReceiverId equals receiverUser.Id

                                     where currentUserIds.Contains(senderUser.Id) || currentUserIds.Contains(receiverUser.Id)

                                     group new
                                     {
                                         message,
                                         recipient,
                                         sender,
                                         senderUser,
                                         receiverUser
                                     }
                                     by recipient.SuperParentMessageId into grouped

                                     select new GetMessageListByRoleTypeRespose
                                     {
                                         MessageContent = grouped
                                             .OrderByDescending(g => g.message.Id)
                                             .Select(g => g.message.MessageContent)
                                             .FirstOrDefault(),

                                         CreatedDate = grouped
                                             .OrderByDescending(g => g.message.CreatedDate)
                                             .Select(g => g.message.CreatedDate)
                                             .FirstOrDefault(),

                                         SuperParentMessageId = grouped.Key,

                                         //SenderName = grouped
                                         //       .OrderByDescending(g => g.message.CreatedDate)
                                         //       .Select(g => $"{g.senderUser.FirstName} {g.senderUser.LastName}".Trim())
                                         //       .FirstOrDefault(),


                                         SenderName = grouped
                                                        .OrderByDescending(g => g.message.CreatedDate)
                                                        .Select(g => request.Type == RoleType.Doctor
                                                            ? (doctorIds.Contains(g.senderUser.Id)
                                                                ? $"{g.senderUser.FirstName} {g.senderUser.LastName}".Trim()
                                                                : $"{g.receiverUser.FirstName} {g.receiverUser.LastName}".Trim())
                                                            : (patientIds.Contains(g.senderUser.Id)
                                                                ? $"{g.senderUser.FirstName} {g.senderUser.LastName}".Trim()
                                                                : $"{g.receiverUser.FirstName} {g.receiverUser.LastName}".Trim())
                                                        )
                                                        .FirstOrDefault(),

                                         ReceiverId = grouped
                                             .OrderByDescending(g => g.message.CreatedDate)
                                             .Select(g => g.recipient.ReceiverId)
                                             .FirstOrDefault(),

                                         SenderId = grouped
                                             .OrderByDescending(g => g.message.CreatedDate)
                                             .Select(g => g.sender.SenderId)
                                             .FirstOrDefault(),

                                         UserId = grouped
                                             .OrderByDescending(g => g.message.CreatedDate)
                                             .Select(g => g.sender.SenderId)
                                             .FirstOrDefault(),

                                         UnreadMessageCount = grouped.Count(m => !m.recipient.IsRead && currentUserIds.Contains(m.recipient.ReceiverId) && m.recipient.ReceiverId != m.sender.SenderId),

                                         DoctorName = grouped
                                            .Where(g => doctorIds.Contains(g.senderUser.Id) || doctorIds.Contains(g.receiverUser.Id))
                                            .Select(g => doctorIds.Contains(g.senderUser.Id)
                                                ? $"{g.senderUser.FirstName} {g.senderUser.LastName}".Trim()
                                                : $"{g.receiverUser.FirstName} {g.receiverUser.LastName}".Trim())
                                            .FirstOrDefault(),

                                         //SenderProfilePictureName = grouped
                                         //   .Where(g => doctorIds.Contains(g.senderUser.Id) || doctorIds.Contains(g.receiverUser.Id))
                                         //   .Select(g => doctorIds.Contains(g.senderUser.Id)
                                         //       ? g.senderUser.ProfilePictureName
                                         //       : g.receiverUser.ProfilePictureName)
                                         //   .FirstOrDefault(),

                                         //SenderProfilePicturePath = grouped
                                         //       .Where(g => doctorIds.Contains(g.senderUser.Id) || doctorIds.Contains(g.receiverUser.Id))
                                         //       .Select(g => doctorIds.Contains(g.senderUser.Id)
                                         //           ? g.senderUser.ProfilePicturePath
                                         //           : g.receiverUser.ProfilePicturePath)
                                         //       .FirstOrDefault(),
                                         PatientName = grouped
                                                        .Where(g => patientIds.Contains(g.senderUser.Id) || patientIds.Contains(g.receiverUser.Id))
                                                        .Select(g => patientIds.Contains(g.senderUser.Id)
                                                            ? $"{g.senderUser.FirstName} {g.senderUser.LastName}".Trim()
                                                            : $"{g.receiverUser.FirstName} {g.receiverUser.LastName}".Trim())
                                                        .FirstOrDefault(),



                                         SenderProfilePictureName = grouped
                                                            .OrderByDescending(g => g.message.CreatedDate)
                                                            .Select(g => request.Type == RoleType.Doctor
                                                                ? (doctorIds.Contains(g.senderUser.Id)
                                                                    ? g.senderUser.ProfilePictureName
                                                                    : g.receiverUser.ProfilePictureName)
                                                                : (patientIds.Contains(g.senderUser.Id)
                                                                    ? g.senderUser.ProfilePictureName
                                                                    : g.receiverUser.ProfilePictureName)
                                                            )
                                                            .FirstOrDefault(),

                                         SenderProfilePicturePath = grouped
                                                        .OrderByDescending(g => g.message.CreatedDate)
                                                        .Select(g => request.Type == RoleType.Doctor
                                                            ? (doctorIds.Contains(g.senderUser.Id)
                                                                ? g.senderUser.ProfilePicturePath
                                                                : g.receiverUser.ProfilePicturePath)
                                                            : (patientIds.Contains(g.senderUser.Id)
                                                                ? g.senderUser.ProfilePicturePath
                                                                : g.receiverUser.ProfilePicturePath)
                                                        )
                                                        .FirstOrDefault(),
                                     };

        // Apply dynamic filtering
        if (!string.IsNullOrEmpty(request.Filter))
        {
            recipientMessagesQuery = recipientMessagesQuery.Where(request.Filter);
        }

        // Apply sorting
        if (!string.IsNullOrEmpty(request.OrderBy))
        {
            recipientMessagesQuery = recipientMessagesQuery.OrderBy(request.OrderBy);
        }
        else
        {
            recipientMessagesQuery = recipientMessagesQuery.OrderByDescending(x => x.CreatedDate);
        }

        // Paginated result
        return await recipientMessagesQuery.PaginatedListAsync(request.PageNumber, request.PageSize);
    }
}