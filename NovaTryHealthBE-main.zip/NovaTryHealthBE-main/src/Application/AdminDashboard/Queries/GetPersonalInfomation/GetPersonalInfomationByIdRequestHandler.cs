﻿using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NovaHealth.Application.AdminDashboard.Queries.GetPersonalInfomation;
public class GetPersonalInfomationByIdRequest
{
    public long Id { get; set; }
}
public class GetPersonalInfomationByIdRequestHandler 
{

}
