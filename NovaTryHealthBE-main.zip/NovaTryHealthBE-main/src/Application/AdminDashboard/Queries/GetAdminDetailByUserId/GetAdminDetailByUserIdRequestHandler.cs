﻿using MediatR;
using Microsoft.EntityFrameworkCore;
using NovaHealth.Application.Common.Exceptions;
using NovaHealth.Application.Common.Interfaces;
using System.Text.Json.Serialization;

namespace NovaHealth.Application.AdminDashboard.Queries.GetAdminDetailByUserId;
public record GetAdminDetailByUserIdRequest : IRequest<GetAdminDetailByUserIdResponse>
{
    // [JsonIgnore] public long UserId { get; set; }
}

public class GetAdminDetailByUserIdRequestHandler : IRequestHandler<GetAdminDetailByUserIdRequest, GetAdminDetailByUserIdResponse>
{
    private readonly INovaHealthDbContext _novaHealthDbContext;

    public GetAdminDetailByUserIdRequestHandler(INovaHealthDbContext novaHealthDbContext)
    {
        _novaHealthDbContext = novaHealthDbContext;
    }

    public async Task<GetAdminDetailByUserIdResponse> Handle(GetAdminDetailByUserIdRequest request, CancellationToken cancellationToken)
    {

        var adminProfile = await _novaHealthDbContext.Users
                          .Include(u => u.UserRoles).ThenInclude(ur => ur.Role)
                         .Where(u => u.IsActive && u.UserRoles.Any(ur => ur.Role.RoleType == RoleType.Admin))
                         .FirstOrDefaultAsync(cancellationToken);

        if (adminProfile == null)
        {
            throw new NotFoundException("No active admin profile found.");
        }
        var response = new GetAdminDetailByUserIdResponse
        {
            Id = adminProfile.Id,
            FullName = adminProfile.FirstName + " " + adminProfile.LastName,
            Email = adminProfile.Email,
            PhoneNumber = adminProfile.PhoneNumber,
            ProfilePictureName = adminProfile.ProfilePictureName,
            ProfilePicturePath = adminProfile.ProfilePicturePath,


            SuperParentMessageId = (
                            from recipient in _novaHealthDbContext.MessageRecipients
                            join message in _novaHealthDbContext.Messages on recipient.MessageId equals message.Id
                            join sender in _novaHealthDbContext.MessageSenders on message.Id equals sender.MessageId
                            where (sender.SenderId == adminProfile.Id || recipient.ReceiverId == adminProfile.Id) && message.SupportMessage == true
                            orderby message.CreatedDate descending
                            select recipient.SuperParentMessageId
                        ).FirstOrDefault(),

        };
        return response;
    }
}
