﻿namespace NovaHealth.Application.AdminDashboard.Queries.GetAdminDetailByUserId;
public class GetAdminDetailByUserIdResponse
{

    public long Id { get; set; }
    public string? FullName { get; set; } 

    public string? PhoneNumber { get; set; }

    public string? Email { get; set; } 

    public string? ProfilePictureName { get; set; }

    public string? ProfilePicturePath { get; set; }

    public long SuperParentMessageId { get; set; }
}
