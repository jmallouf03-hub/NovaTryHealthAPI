﻿namespace NovaHealth.Application.AdminDashboard.Queries.GetSupportMessageByAdminId;

public class GetSupportMessageByAdminIdResponse
{

    public DateOnly Date { get; set; }

    public List<MessageLists>? MessageList { get; set; }
}
public record MessageLists
{
    public string? MessageContent { get; set; }

    public long MessageId { get; set; }

    public long CreatedBy { get; set; }

    public long? ParentMessageId { get; set; }

    public long SuperParentMessageId { get; set; }

    public List<long> ReceiverIds { get; set; } = new();

    public long SenderId { get; set; }

    public int? UnreadMessageCount { get; set; }
    public string? SenderName { get; set; }

    public DateTime CreatedDate { get; set; }

    public string? FileName { get; set; }

    public string? FilePath { get; set; }


    public string? SenderProfilePictureName { get; set; }

    public string? SenderProfilePicturePath { get; set; }

    public string? RecieverName { get; set; }

    public string? RoleType { get; set; }
    public string? DoctorName { get; set; }
    public string? PatientName { get; set; }
    public bool SupportMessage { get; set; }

}
