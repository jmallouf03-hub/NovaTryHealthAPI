﻿using AutoMapper;
using MediatR;
using Microsoft.EntityFrameworkCore;
using NovaHealth.Application.Common.Interfaces;
using System.Text.Json.Serialization;

namespace NovaHealth.Application.AdminDashboard.Queries.GetSupportMessageByAdminId;



public class GetSupportMessageByAdminIdRequest : IRequest<GetSupportMessageByAdminIdResponse>
{
    [JsonIgnore] public long UserId { get; set; }
}

public class GetSupportMessageByAdminIdRequestHandler : IRequestHandler<GetSupportMessageByAdminIdRequest, GetSupportMessageByAdminIdResponse>
{
    private readonly INovaHealthDbContext _novaHealthDbContext;
    private readonly IMapper _mapper;

    public GetSupportMessageByAdminIdRequestHandler(INovaHealthDbContext novaHealthDbContext, IMapper mapper)
    {
        _novaHealthDbContext = novaHealthDbContext;
        _mapper = mapper;
    }
    public async Task<GetSupportMessageByAdminIdResponse> Handle(GetSupportMessageByAdminIdRequest request, CancellationToken cancellationToken)
    {
        var userRoles = await _novaHealthDbContext.UserRoles
                    .Select(ur => new { ur.UserId, ur.Role.RoleType })
                    .ToListAsync(cancellationToken);

        var doctorIds = userRoles.Where(x => x.RoleType == RoleType.Doctor).Select(x => x.UserId).ToList();
        var patientIds = userRoles.Where(x => x.RoleType == RoleType.Patient).Select(x => x.UserId).ToList();


        var recipientMessagesQuery = from recipient in _novaHealthDbContext.MessageRecipients
                                     join message in _novaHealthDbContext.Messages
                                         on recipient.MessageId equals message.Id
                                     join sender in _novaHealthDbContext.MessageSenders
                                         on message.Id equals sender.MessageId
                                     join senderUser in _novaHealthDbContext.Users
                                         on sender.SenderId equals senderUser.Id
                                     join receiverUser in _novaHealthDbContext.Users
                                         on recipient.ReceiverId equals receiverUser.Id

                                     join senderUserRole in _novaHealthDbContext.UserRoles
                                        on senderUser.Id equals senderUserRole.UserId
                                     join senderRole in _novaHealthDbContext.Roles
                                         on senderUserRole.RoleId equals senderRole.Id

                                     where message.SupportMessage == true

                                     group new
                                     {
                                         message,
                                         recipient,
                                         senderUser,
                                         receiverUser,
                                         sender,
                                         senderRole,
                                     }
                                     by recipient.SuperParentMessageId into grouped
                                     select new MessageLists
                                     {
                                         ReceiverIds = grouped
                                            .Select(g => g.recipient.ReceiverId)
                                            .Distinct()
                                            .ToList(),


                                         SenderId = grouped.OrderByDescending(g => g.message.CreatedDate)
                                                      .Select(g => g.sender.SenderId)
                                                      .FirstOrDefault(),
                                         MessageId = grouped.OrderByDescending(g => g.message.CreatedDate)
                                                               .Select(g => g.message.Id)
                                                               .FirstOrDefault(),


                                         MessageContent = grouped.OrderByDescending(g => g.message.Id).Select(g => g.message.MessageContent).FirstOrDefault(),

                                         SenderName = grouped.OrderByDescending(g => g.message.CreatedDate).Select(g =>
                                                   request.UserId == g.sender.SenderId
                                                       ? g.receiverUser.FirstName + " " + g.receiverUser.LastName
                                                       : g.senderUser.FirstName + " " + g.senderUser.LastName
                                            ).FirstOrDefault(),


                                         SenderProfilePictureName = grouped.OrderByDescending(g => g.message.CreatedDate)
                                                .Select(g => g.senderUser.ProfilePictureName)
                                                .FirstOrDefault(),

                                         SenderProfilePicturePath = grouped.OrderByDescending(g => g.message.CreatedDate)
                                                .Select(g => g.senderUser.ProfilePicturePath)
                                                .FirstOrDefault(),



                                         CreatedDate = grouped.OrderByDescending(g => g.message.CreatedDate).Select(g => g.message.CreatedDate).FirstOrDefault(),
                                         SuperParentMessageId = grouped.Key,
                                         UnreadMessageCount = grouped.Count(m => !m.recipient.IsRead && m.recipient.ReceiverId == request.UserId && m.recipient.ReceiverId != m.sender.SenderId),


                                         DoctorName = grouped.Select(g =>
                                                        doctorIds.Contains(g.senderUser.Id)
                                                            ? g.senderUser.FirstName + " " + g.senderUser.LastName
                                                            : doctorIds.Contains(g.receiverUser.Id)
                                                                ? g.receiverUser.FirstName + " " + g.receiverUser.LastName
                                                                : ""
                                                         ).FirstOrDefault(),

                                         PatientName = grouped.Select(g =>
                                             patientIds.Contains(g.senderUser.Id)
                                                 ? g.senderUser.FirstName + " " + g.senderUser.LastName
                                                 : patientIds.Contains(g.receiverUser.Id)
                                                     ? g.receiverUser.FirstName + " " + g.receiverUser.LastName
                                                     : ""
                                             ).FirstOrDefault(),
                                         CreatedBy = grouped.OrderByDescending(g => g.message.CreatedDate)
                                                   .Select(g => g.message.CreatedBy)
                                                   .FirstOrDefault(),

                                         RoleType = grouped
                                                        .OrderByDescending(g => g.message.CreatedDate)
                                                        .Select(g => g.senderRole.RoleType.ToString())
                                                        .FirstOrDefault(),
                                         FileName = grouped.OrderByDescending(g => g.message.CreatedDate)
                                       .Select(g => g.message.FileName)
                                       .FirstOrDefault(),

                                         FilePath = grouped.OrderByDescending(g => g.message.CreatedDate)
                                                       .Select(g => g.message.FilePath)
                                                       .FirstOrDefault(),
                                         SupportMessage = grouped.OrderByDescending(m => m.message.CreatedDate)
                                                      .Select(m => m.message.SupportMessage)
                                                      .FirstOrDefault()
                                     };



        var messageList = await recipientMessagesQuery
                        .OrderByDescending(m => m.CreatedDate)
                        .ToListAsync(cancellationToken);


        TimeZoneInfo sourceZone = TimeZoneInfo.FindSystemTimeZoneById("UTC");

        // Destination: Local system timezone
        TimeZoneInfo localZone = TimeZoneInfo.Local;

        foreach (var message in messageList)
        {
            if (message.CreatedDate != null)
            {
                // Convert
                message.CreatedDate = TimeZoneInfo.ConvertTime(message.CreatedDate, sourceZone, localZone);
            }
        }

        return new GetSupportMessageByAdminIdResponse
        {
            Date = DateOnly.FromDateTime(DateTime.Now),
            MessageList = messageList
        };
    }
}
