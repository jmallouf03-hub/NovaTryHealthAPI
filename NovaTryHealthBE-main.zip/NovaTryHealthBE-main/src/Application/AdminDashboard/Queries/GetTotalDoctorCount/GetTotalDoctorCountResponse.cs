﻿namespace NovaHealth.Application.AdminDashboard.Queries.GetTotalDoctorCount;

public class GetTotalDoctorCountResponse
{
    public int TotalDoctorCount { get; set; }

    public int TotalActiveDoctorCount { get; set; }

    public int TotalIsDisabledByAdmin { get; set; }
}
