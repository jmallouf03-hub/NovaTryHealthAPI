﻿using MediatR;
using Microsoft.EntityFrameworkCore;
using NovaHealth.Application.Common.Interfaces;


namespace NovaHealth.Application.AdminDashboard.Queries.GetTotalDoctorCount;

public class GetTotalDoctorCountRequest : IRequest<GetTotalDoctorCountResponse> { }

public class GetTotalDoctorCountRequestHandler : IRequestHandler<GetTotalDoctorCountRequest, GetTotalDoctorCountResponse>
{
    private readonly INovaHealthDbContext _novaHealthDbContext;

    public GetTotalDoctorCountRequestHandler(INovaHealthDbContext novaHealthDbContext)
    {
        _novaHealthDbContext = novaHealthDbContext;

    }
    public async Task<GetTotalDoctorCountResponse> Handle(GetTotalDoctorCountRequest request, CancellationToken cancellationToken)
    {

        // All doctors, regardless of active status
        var totalDoctorCount = await _novaHealthDbContext.Users
            .Where(user => !user.IsDeleted && user.IsActive)
            .Where(user => user.UserRoles.Any(ur =>
                !ur.IsDeleted &&
                ur.Role.RoleType == RoleType.Doctor))
            .CountAsync(cancellationToken);

        // Only active doctors
        var totalActiveDoctorCount = await _novaHealthDbContext.Users
            .Where(user => !user.IsDeleted && user.IsActive && user.IsDisabledByAdmin)
            .Where(user => user.UserRoles.Any(ur =>
                !ur.IsDeleted && ur.IsActive &&
                ur.Role.RoleType == RoleType.Doctor))
            .CountAsync(cancellationToken);


        var totalDisableDoctorCount = await _novaHealthDbContext.Users
           .Where(user => !user.IsDeleted && !user.IsDisabledByAdmin)
           .Where(user => user.UserRoles.Any(ur =>
               !ur.IsDeleted && ur.IsActive &&
               ur.Role.RoleType == RoleType.Doctor))
           .CountAsync(cancellationToken);

        return new GetTotalDoctorCountResponse
        {   
            TotalDoctorCount = totalDoctorCount,
            TotalActiveDoctorCount = totalActiveDoctorCount,
            TotalIsDisabledByAdmin = totalDisableDoctorCount,
        };
    }
}

