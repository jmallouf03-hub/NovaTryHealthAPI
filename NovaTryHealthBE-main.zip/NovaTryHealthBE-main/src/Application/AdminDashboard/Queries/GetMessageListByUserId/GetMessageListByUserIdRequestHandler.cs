﻿using MediatR;
using Microsoft.EntityFrameworkCore;
using NovaHealth.Application.Common.Interfaces;
using System.Text.Json.Serialization;

namespace NovaHealth.Application.AdminDashboard.Queries.GetMessageListByUserId;

public record GetMessageListByUserIdRequest : IRequest<List<GetMessageListByUserIdResponse>>
{
    [JsonIgnore]
    public long SuperParentMessageId { get; set; }

    [JsonIgnore]
    public long UserId { get; set; }
}

public class GetMessageListByUserIdRequestHandler : IRequestHandler<GetMessageListByUserIdRequest, List<GetMessageListByUserIdResponse>>
{
    private readonly INovaHealthDbContext _novaHealthDbContext;

    public GetMessageListByUserIdRequestHandler(INovaHealthDbContext novaHealthDbContext)
    {
        _novaHealthDbContext = novaHealthDbContext;
    }

    public async Task<List<GetMessageListByUserIdResponse>> Handle(GetMessageListByUserIdRequest request, CancellationToken cancellationToken)
    {
        var superParentId = request.SuperParentMessageId;
        var userId = request.UserId;

        // ✅ Query all messages where user is sender or receiver in that thread
        var messageQuery = await (
            from message in _novaHealthDbContext.Messages
            join sender in _novaHealthDbContext.MessageSenders
                on message.Id equals sender.MessageId
            join recipient in _novaHealthDbContext.MessageRecipients
                on message.Id equals recipient.MessageId
            join senderUser in _novaHealthDbContext.Users
                on sender.SenderId equals senderUser.Id
            join receiverUser in _novaHealthDbContext.Users
           on recipient.ReceiverId equals receiverUser.Id

            join senderUserRole in _novaHealthDbContext.UserRoles
                on senderUser.Id equals senderUserRole.UserId
            join senderRole in _novaHealthDbContext.Roles
                on senderUserRole.RoleId equals senderRole.Id

            join receiverUserRole in _novaHealthDbContext.UserRoles
                on receiverUser.Id equals receiverUserRole.UserId
            join receiverRole in _novaHealthDbContext.Roles
                on receiverUserRole.RoleId equals receiverRole.Id


            where sender.SuperParentMessageId == superParentId
                && !message.IsDeleted
                && !sender.IsDeleted
                && !recipient.IsDeleted
                && (sender.SenderId == userId || recipient.ReceiverId == userId)

            select new
            {
                MessageId = message.Id,
                message.MessageContent,
                message.CreatedBy,
                message.CreatedDate,
                ParentMessageId = recipient.ParentMessageId,
                SuperParentMessageId = recipient.SuperParentMessageId,
                ReceiverId = recipient.ReceiverId,
                SenderId = sender.SenderId,
                SenderType = senderRole.RoleType.ToString(),
                ReceiverType = receiverRole.RoleType.ToString(),
                SenderName = senderUser.FirstName + " " + senderUser.LastName,
                message.FileName,
                message.FilePath,
                SenderProfilePictureName = senderUser.ProfilePictureName,
                SenderProfilePicturePath = senderUser.ProfilePicturePath,
                RecieverName = receiverUser.FirstName + " " + receiverUser.LastName,
                SupportMessage = message.SupportMessage,

            }
        ).ToListAsync(cancellationToken);

        if (!messageQuery.Any())
        {
            return new List<GetMessageListByUserIdResponse>();
        }

        // ✅ Group receiver IDs per message
        var groupedMessages = messageQuery
            .GroupBy(m => m.MessageId)
            .Select(g => new MessageLists
            {
                MessageId = g.Key,
                MessageContent = g.First().MessageContent,
                CreatedBy = g.First().CreatedBy,
                CreatedDate = g.First().CreatedDate,
                ParentMessageId = g.First().ParentMessageId,
                SuperParentMessageId = g.First().SuperParentMessageId,
                SenderId = g.First().SenderId,
                SenderName = g.First().SenderName,
                FileName = g.First().FileName,
                FilePath = g.First().FilePath,
                SenderType = g.First().SenderType,
                SupportMessage = g.First().SupportMessage,
                ReceiverIds = g.Select(x => x.ReceiverId).Distinct().ToList(),
                SenderProfilePictureName = g.First().SenderProfilePictureName,
                SenderProfilePicturePath = g.First().SenderProfilePicturePath,
                MessageDirection = $"{g.First().SenderType} To {g.First().ReceiverType}"
            })
            .ToList();


        TimeZoneInfo sourceZone = TimeZoneInfo.FindSystemTimeZoneById("UTC");

        // Destination: Local system timezone
        TimeZoneInfo localZone = TimeZoneInfo.Local;

        foreach (var message in groupedMessages)
        {
            if (message.CreatedDate != null)
            {
                // Convert
                message.CreatedDate = TimeZoneInfo.ConvertTime(message.CreatedDate, sourceZone, localZone);
            }
        }


        // ✅ Group messages by date
        return groupedMessages
            .GroupBy(m => m.CreatedDate.Date)
            .OrderBy(g => g.Key)
            .Select(g => new GetMessageListByUserIdResponse
            {
                Date = DateOnly.FromDateTime(g.Key),
                MessageList = g.ToList()
            })
            .ToList();
    }
}