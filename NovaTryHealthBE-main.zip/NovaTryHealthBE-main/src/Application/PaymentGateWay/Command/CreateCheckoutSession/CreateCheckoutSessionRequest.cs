﻿using MediatR;
using Microsoft.EntityFrameworkCore.Storage.ValueConversion;

namespace NovaHealth.Application.PaymentGateway.Commands.CreateCheckoutSession;

public record CreateCheckoutSessionRequest : IRequest<CreateCheckoutSessionResponse>
{
    public long UserId { get; set; }
    public string ProductId { get; set; } = null!;
    public decimal Amount { get; set; }
    public int Quantity { get; set; }
}