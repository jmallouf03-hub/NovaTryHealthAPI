﻿namespace NovaHealth.Application.PaymentGateway.Commands.CreateCheckoutSession;

public record CreateCheckoutSessionResponse
{
    public string Url { get; set; } = null!;
}
