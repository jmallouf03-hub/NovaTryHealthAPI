﻿//using MediatR;
//using Microsoft.Extensions.Options;
//using NovaHealth.Application;
//using Stripe.Checkout;

//namespace NovaHealth.Application.PaymentGateway.Commands.CreateCheckoutSession;

//public class CreateCheckoutSessionRequestHandler : IRequestHandler<CreateCheckoutSessionRequest, CreateCheckoutSessionResponse>
//{
//    private readonly AppSettings _appSettings;

//    public CreateCheckoutSessionRequestHandler(IOptions<AppSettings> appSettings)
//    {
//        _appSettings = appSettings.Value;
//    }

//    public async Task<CreateCheckoutSessionResponse> Handle(CreateCheckoutSessionRequest request, CancellationToken cancellationToken)
//    {
//        var domainUrl = $"{_appSettings.DomainUrl}";

//        var options = new SessionCreateOptions
//        {
//            SuccessUrl = $"{_appSettings.NovaHealthUrl}" + $"{_appSettings.PaymentSuccessUrl}",
//            CancelUrl = domainUrl + $"{_appSettings.PaymentCancelUrl}",
//            PaymentMethodTypes = new List<string> { "card" },
//            Mode = "payment",
//            LineItems = new List<SessionLineItemOptions>(),
//            Metadata = new Dictionary<string, string>()
//        };

//        var sessionListItem = new SessionLineItemOptions
//        {
//            PriceData = new SessionLineItemPriceDataOptions
//            {
//                Currency = "cad",
//                ProductData = new SessionLineItemPriceDataProductDataOptions
//                {
//                    Name = request.ProductId.ToString(),
//                },
//                UnitAmount = (long)(request.Amount * 100),
//            },
//            Quantity = 1,
//        };

//        options.LineItems.Add(sessionListItem);
//        options.Metadata.Add("UserId", request.UserId.ToString());
//        options.Metadata.Add("ProductId", request.ProductId.ToString());
//        //options.Metadata.Add("StudentSubscriptionId", request.StudentSubscriptionId?.ToString());

//        options.Metadata.Add("Amount", request.Amount.ToString());

//        var service = new SessionService();
//        var session = await service.CreateAsync(options);

//        return new CreateCheckoutSessionResponse
//        {
//            Url = session.Url,
//        };
//    }
//}

using MediatR;
using Microsoft.Extensions.Options;
using NovaHealth.Application;
using NovaHealth.Application.PaymentGateway.Commands.CreateCheckoutSession;
using Stripe;

namespace NovaHealth.Application.PaymentGateway.Commands.DirectPayment;

public class DirectPaymentRequestHandler : IRequestHandler<CreateCheckoutSessionRequest, CreateCheckoutSessionResponse>
{
    private readonly AppSettings _appSettings;

    public DirectPaymentRequestHandler(IOptions<AppSettings> appSettings)
    {
        _appSettings = appSettings.Value;
        // StripeConfiguration.ApiKey = _appSettin;
    }

    public async Task<CreateCheckoutSessionResponse> Handle(CreateCheckoutSessionRequest request, CancellationToken cancellationToken)
    {
        var options = new PaymentIntentCreateOptions
        {
            Amount = (long)(request.Amount * 100), // Amount in cents
            Currency = "cad",
            PaymentMethodTypes = new List<string> { "card" },
            Metadata = new Dictionary<string, string>
            {
                { "UserId", request.UserId.ToString() },
                { "ProductId", request.ProductId.ToString() },
                { "Amount", request.Amount.ToString() }
            }
        };

        var service = new PaymentIntentService();
        var paymentIntent = await service.CreateAsync(options);

        return new CreateCheckoutSessionResponse
        {
            Url = paymentIntent.ClientSecret
        };
    }
}
