﻿using AutoMapper;

namespace NovaHealth.Application.States.Queries.GetStateList;

public class GetStateListResponse
{
    public long Id { get; set; }

    public string Name { get; set; } = null!;

    private class Mapping : Profile
    {
        public Mapping()
        {
            CreateMap<GetStateListResponse, GetStateListResponse>();
        }
    }
}
