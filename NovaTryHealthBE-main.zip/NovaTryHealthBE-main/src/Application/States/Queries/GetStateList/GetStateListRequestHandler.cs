﻿using AutoMapper;
using AutoMapper.QueryableExtensions;
using MediatR;
using NovaHealth.Application.Common.Interfaces;
using NovaHealth.Application.Common.Mappings;
using NovaHealth.Application.Common.Models;
using System.Linq.Dynamic.Core;


namespace NovaHealth.Application.States.Queries.GetStateList;
public class GetStateListRequest : PaginationFilter, IRequest<PaginationResponse<GetStateListResponse>> { }

public class GetStateListRequestHandler : IRequestHandler<GetStateListRequest, PaginationResponse<GetStateListResponse>>
{
    private readonly INovaHealthDbContext _novaHealthDbContext;

    private readonly IMapper _mapper;

    public GetStateListRequestHandler(INovaHealthDbContext healthCareDBContext, IMapper mapper)
    {
        _novaHealthDbContext = healthCareDBContext;
        _mapper = mapper;

    }
    public async Task<PaginationResponse<GetStateListResponse>> Handle(GetStateListRequest request, CancellationToken cancellationToken)
    {
        var statesQuery = _novaHealthDbContext.States
                          .Select(x => new GetStateListResponse
                          {
                              Id = x.Id,
                              Name = x.StateName,
                          });

        if (!string.IsNullOrEmpty(request.Filter))
        {
            statesQuery = statesQuery.Where(request.Filter);
        }

        if (!string.IsNullOrEmpty(request.OrderBy))
        {
            statesQuery = statesQuery.OrderBy(request.OrderBy);
        }
        else
        {
            statesQuery = statesQuery.OrderBy(x => x.Name);
        }

        return await statesQuery.ProjectTo<GetStateListResponse>(_mapper.ConfigurationProvider)
           .PaginatedListAsync(request.PageNumber, request.PageSize);
    }
}
