﻿
namespace NovaHealth.Domain.Entities;

public class ProductIngredient : BaseAuditableEntity
{
    public string? Name { get; set; }

    public string? Strength { get; set; }

    public long ProductId { get; set; }

    public Product Product { get; set; } = null!;

    public bool IsActive { get; set; } = true;

    public bool IsDeleted { get; set; } = false;
}
