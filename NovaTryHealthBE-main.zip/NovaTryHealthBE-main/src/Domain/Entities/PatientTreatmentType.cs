﻿namespace NovaHealth.Domain.Entities;

public class PatientTreatmentType : BaseEntity
{
    public string TreatmentType { get; set; } = null!;
}
