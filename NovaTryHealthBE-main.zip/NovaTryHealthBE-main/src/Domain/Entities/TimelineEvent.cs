﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NovaHealth.Domain.Entities
{
    public class TimelineEvent : BaseEntity
    {
        public long UserId { get; set; }

        public User User { get; set; } = null!;
        public string? EventType { get; set; }  // stored as string
        public string ? Title { get; set; }
        public string ? Description { get; set; }
        public DateTimeOffset EventDate { get; set; }
        public string ? CreatedBy { get; set; }
        public string? Metadata { get; set; }   // JSON
    }
}
    