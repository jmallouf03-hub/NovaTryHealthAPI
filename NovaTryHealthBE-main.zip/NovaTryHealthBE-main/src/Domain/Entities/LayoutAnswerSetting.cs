﻿
namespace NovaHealth.Domain.Entities;

public class LayoutAnswerSetting : BaseAuditableEntity
{
    public long LayoutId { get; set; }
    public virtual QuestionnaireGlobalLayout Layout { get; set; } = null!;
   // public int? QuestionId { get; set; }
    public string? AnswerBackgroundColor { get; set; }
    public string? AnswerTextColor { get; set; }
    public string? AnswerHighlightColor { get; set; }
    public string? AnswerOutlineColor { get; set; }
}
