﻿namespace NovaHealth.Domain.Entities;
public class Notification : BaseAuditableEntity
{
    public NotificationType NotificationType { get; set; }

    public string? Title { get; set; }

    public string? Message { get; set; }

    public long? CreatedBy { get; set; }

    public virtual ICollection<UserNotificationReference> References { get; set; } = new List<UserNotificationReference>();
}