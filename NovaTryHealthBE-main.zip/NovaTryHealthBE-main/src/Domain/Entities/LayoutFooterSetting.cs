﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NovaHealth.Domain.Entities;

public class LayoutFooterSetting : BaseAuditableEntity
{
    public long  LayoutId { get; set; } 
    public virtual QuestionnaireGlobalLayout Layout { get; set; } = null!;
    public bool ShowFooter { get; set; } = false;
    public string? PrimaryTextColor { get; set; }
    public string? SecondaryTextColor { get; set; }
    public string? DividerColor { get; set; }
    public string? BackgroundColor { get; set; }
    public string? FooterLogo { get; set; }
    public string? CompanyName { get; set; }
    public string? PhoneNumber { get; set; }
    public string? EmailAddress { get; set; }
    public string? HelpCenterURL { get; set; }
    public string? CopyrightText { get; set; }

    public bool ShowFooterSocialIcons { get; set; } =false;
    public string? FacebookURL { get; set; }
    public string? InstagramURL { get; set; }
    public string? TwitterURL { get; set; }
    public string? LinkedInURL { get; set; }
 
}
