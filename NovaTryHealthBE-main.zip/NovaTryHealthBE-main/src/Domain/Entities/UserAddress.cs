﻿namespace NovaHealth.Domain.Entities;

public class UserAddress : BaseAuditableEntity
{
    public long UserId { get; set; }

    public virtual User User { get; set; } = null!;

    public string Address1 { get; set; } = null!;

    public string? Address2 { get; set; } 

    public string City { get; set; } = null!;

    public int StateId { get; set; }

    public virtual State State { get; set; } = null!;

    public string ZipCode { get; set; } = null!;

}
