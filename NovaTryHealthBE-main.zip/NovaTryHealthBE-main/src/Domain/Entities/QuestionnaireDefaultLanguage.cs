﻿

namespace NovaHealth.Domain.Entities;

public class QuestionnaireDefaultLanguage: BaseEntity
{
    public string DefaultLanguage { get; set; } = null!;
}
