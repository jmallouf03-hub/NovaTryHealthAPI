﻿namespace NovaHealth.Domain.Entities;

public class UserRole : BaseEntity
{
    public long RoleId { get; set; }

    public virtual Role Role { get; set; } = null!;  

    public long UserId { get; set; }

    public virtual User User { get; set; } = null!;  

    public bool IsActive { get; set; }

    public bool IsDeleted { get; set; }
}
