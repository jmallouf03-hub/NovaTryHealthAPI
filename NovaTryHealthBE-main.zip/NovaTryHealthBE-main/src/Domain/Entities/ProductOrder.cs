﻿namespace NovaHealth.Domain.Entities;

public class ProductOrder : BaseEntity
{
    public long BookOrderId { get; set; }
    public virtual BookOrder BookOrder { get; set; } = null!;

    public virtual Product Product { get; set; } = null!;

    public long ProductId { get; set; }

    public int Quantity { get; set; }

    public decimal Amount { get; set; }

}
