﻿

namespace NovaHealth.Domain.Entities;

public class WebDomain : BaseAuditableEntity
{
    public string? Name { get; set; } 
    public string? Description { get; set; }
    public string Url { get; set; } = null!;

}
