﻿namespace NovaHealth.Domain.Entities;

public class User : BaseAuditableEntity
{
    public string FirstName { get; set; } = null!;

    public string? MiddleName { get; set; }

    public string? LastName { get; set; } 

    public string? PhoneNumber { get; set; }

    public DateTime? DateOfBirth { get; set; }

    public string? Password { get; set; }

    public GenderTypeOption Gender { get; set; } = GenderTypeOption.NotSpecified;

    public string Email { get; set; } = null!;

    public bool IsEmailVerified {  get; set; }

    public bool IsDisabledByAdmin { get; set; }

    public string? ProfilePictureName { get; set; }

    public string? ProfilePicturePath { get; set; }
    public virtual ICollection<UserAddress> UserAddresses { get; set; } = new List<UserAddress>();

    public virtual ICollection<UserRole> UserRoles { get; set; } = new List<UserRole>();

    public virtual ICollection<DoctorCategory> DoctorCategories { get; set; } = new List<DoctorCategory>();
}