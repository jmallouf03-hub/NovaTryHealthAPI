﻿namespace NovaHealth.Domain.Entities;
public class State 
{
    public int Id { get; set; }
    public string StateName { get; set; } = null!;
}
