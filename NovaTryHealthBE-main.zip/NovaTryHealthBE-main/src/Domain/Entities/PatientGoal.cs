﻿namespace NovaHealth.Domain.Entities;

public class PatientGoal : BaseAuditableEntity
{
    public string Goal = null!;

    public long UserId { get; set; }

    public User User { get; set; } = null!;

    public long PatientTreatmentTypeId { get; set; }

    public PatientTreatmentType PatientTreatmentType { get; set; } = null!;

    public long PatientMetricId { get; set; }

    public PatientMetric PatientMetric { get; set; } = null!;

    public string TargetValuelBsForWeight { get; set; } = null!;

   // public decimal TargetValuelBsForWeight { get; set; }
    public DateOnly StartDate { get; set; }

    public DateOnly EndDate { get; set; }


}
