﻿namespace NovaHealth.Domain.Entities;

public class QuestionProduct : BaseEntity
{
    public long?  QuestionId { get; set; } = null;

    public virtual Question Question { get; set; } = null!;

    public long? ProductId { get; set; } = null;

    public virtual Product Product { get; set; } = null!;

}
