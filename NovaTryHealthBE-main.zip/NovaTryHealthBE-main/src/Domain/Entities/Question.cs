﻿namespace NovaHealth.Domain.Entities;

public class Question :BaseAuditableEntity
{
    public long QuestionnaireId { get; set; }
    public virtual Questionnaire Questionnaire { get; set; } = null!;
    public string? Name { get; set; } 
    public string? Title { get; set; } 
    public long QuestionTypeId { get; set; }
    public long? NextQuestionId { get; set; } = null;
    public int? QuestionNumber { get; set; } = null;
    public QuestionType? QuestionType { get; set; }  
    public long? QuestionSpecialVisitId { get; set; }
    public virtual QuestionSpecialVisit? QuestionSpecialVisit { get; set; }

    public virtual ICollection<QuestionProduct> QuestionProducts { get; set; } = new List<QuestionProduct>();

    public virtual ICollection<AnswerOption>? Answers { get; set; } = new List<AnswerOption>();
}
