﻿namespace NovaHealth.Domain.Entities;
public class LayoutTitleSetting : BaseEntity<long>
{

    public long LayoutId { get; set; }
    public virtual QuestionnaireGlobalLayout Layout { get; set; } = null!;
    public string? PreHeader { get; set; }
    public bool ShowPreHeader { get; set; } = false;
    public string? PreHeaderColor { get; set; }

    public string? MainHeader { get; set; }
    public string? ShowMainHeader { get; set; }
    public string? MainHeaderColor { get; set; }

    public string? SubHeader { get; set; }
    public bool ShowSubHeader { get; set; }
    public string? SubHeaderColor { get; set; }

    public string? Banner { get; set; }
    public bool ShowBanner { get; set; }
    public string? BannerTextColor { get; set; }

    public string? BannerBGColor { get; set; }

    public bool ShowBannerIcon { get; set; }
    public string? BannerIconColor { get; set; }


}