﻿namespace NovaHealth.Domain.Entities;

public class LoginLog : BaseEntity
{
    public long UserId { get; set; }

    public User User { get; set; } = null!;

    public string? Platform { get; set; }

    public string? Browser { get; set; }

    public string? Version { get; set; }

    public string? MobileDeviceType { get; set; }

    public string? RequestFrom { get; set; }

    public string? IpAddress { get; set; }

    public string? UserAgent { get; set; }

    public DateTimeOffset CreatedDate { get; set; }
}