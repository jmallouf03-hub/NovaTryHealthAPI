﻿namespace NovaHealth.Domain.Entities;

public class PatientMetric : BaseEntity
{
    public string MetricName { get; set; } = null!;
}
