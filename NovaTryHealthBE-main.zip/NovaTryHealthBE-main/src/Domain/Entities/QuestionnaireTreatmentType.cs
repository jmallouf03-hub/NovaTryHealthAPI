﻿namespace NovaHealth.Domain.Entities;

public class QuestionnaireTreatmentType : BaseEntity
{
    public string TreatmentType { get; set; } = null!;
}
