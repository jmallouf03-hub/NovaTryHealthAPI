﻿namespace NovaHealth.Domain.Entities;
public class Message : BaseAuditableEntity
{
    public string? MessageContent { get; set; }

    public long CreatedBy { get; set; }

    public string? FileName { get; set; }

    public string? FilePath { get; set; }

    public bool SupportMessage { get; set; }

    //public DateTime ExpiresAt { get; set; } = DateTime.UtcNow.AddHours(24);

    public ICollection<MessageSender> MessageSenders { get; set; } = new List<MessageSender>();

    public ICollection<MessageRecipient> MessageRecipients { get; set; } = new List<MessageRecipient>();
}
