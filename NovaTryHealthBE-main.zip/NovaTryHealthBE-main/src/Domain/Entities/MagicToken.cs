﻿

namespace NovaHealth.Domain.Entities;

public class MagicToken : BaseAuditableEntity
{
    public long UserId { get; set; }         
    public User User { get; set; } = null!; 
    public string Email { get; set; } = null!;
    public Guid Token { get; set; } = Guid.NewGuid();
    public DateTimeOffset Expiry { get; set; } = DateTime.UtcNow.AddMinutes(15);
    public bool IsUsed { get; set; } = false;
   
}
