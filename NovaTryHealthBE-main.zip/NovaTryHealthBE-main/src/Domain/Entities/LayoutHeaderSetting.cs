﻿
namespace NovaHealth.Domain.Entities;

public class LayoutHeaderSetting : BaseAuditableEntity
{
    public long LayoutId { get; set; }
    public virtual QuestionnaireGlobalLayout Layout { get; set; } = null!;
    public string? NavbarLeftRadius { get; set; }
    public string? HeaderBackgroundColor { get; set; }
    public string? HeaderLogo { get; set; }
    public string? CustomProgressBarSegments { get; set; } 
 
    public bool BackButtonGlobal { get; set; } = false;   

    public bool BackButtonOnlyCurrent { get; set; } = false;
    public string? ProgressBarColor { get; set; }
    public string? ProgressBarBackgroundColor { get; set; }
    public string? BackButtonColor { get; set; }
    public string? HeaderTextColor { get; set; }

    public bool ShowHelpButton { get; set; } = false;
    public string? HelpButtonSupportHours { get; set; }
    public string? HelpButtonColor { get; set; }
    public string? HelpButtonTextColor { get; set; }
}