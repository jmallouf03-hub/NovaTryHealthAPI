﻿namespace NovaHealth.Domain.Entities;

public class QuestionnaireProduct : BaseAuditableEntity
{
    public long QuestionnaireId { get; set; }
    public virtual Questionnaire Questionnaire { get; set; } = null!;

    public long ProductId { get; set; }
    public virtual Product Product { get; set; } = null!;
}
