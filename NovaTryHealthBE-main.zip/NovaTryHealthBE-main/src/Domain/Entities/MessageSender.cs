﻿    namespace NovaHealth.Domain.Entities;

    public class MessageSender : BaseAuditableEntity
    {
        public long SenderId { get; set; }

        public User Sender { get; set; } = null!;

        public long MessageId { get; set; }

        public Message Message { get; set; } = null!;

        public long? ParentMessageId { get; set; }

        public long SuperParentMessageId { get; set; }
}