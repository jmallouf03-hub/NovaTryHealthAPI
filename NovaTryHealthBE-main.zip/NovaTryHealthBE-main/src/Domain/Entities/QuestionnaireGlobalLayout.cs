﻿namespace NovaHealth.Domain.Entities;

public class QuestionnaireGlobalLayout : BaseEntity
{
    public string GlobalLayout { get; set; } = null!;
}
