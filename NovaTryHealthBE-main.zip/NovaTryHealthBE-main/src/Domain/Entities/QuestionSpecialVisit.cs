﻿namespace NovaHealth.Domain.Entities;

public class QuestionSpecialVisit : BaseEntity
{
    public string SpecialVisitName { get; set; } = null!;
   
}
