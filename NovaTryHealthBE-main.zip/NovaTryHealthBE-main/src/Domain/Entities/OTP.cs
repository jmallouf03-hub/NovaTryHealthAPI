﻿namespace NovaHealth.Domain.Entities;

public class OTP : BaseAuditableEntity
{
    public long UserId { get; set; }

    public User User { get; set; } = null!;

    public string OtpCode { get; set; } = null!;

    public DateTime ExpiryDate { get; set; }
}
