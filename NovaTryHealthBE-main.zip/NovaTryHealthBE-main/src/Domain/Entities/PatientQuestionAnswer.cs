﻿using System;
namespace NovaHealth.Domain.Entities;

public class PatientQuestionAnswer  :  BaseEntity
{
    
    public long? PatientId { get; set; } 
    public virtual User? Patient { get; set; } = null;
    public string? SessionId { get; set; } 
    public long QuestionId { get; set; } 
    public virtual Question Question { get; set; } = null!;
    public string? FileUrl { get; set; } 
    public string? AnswerText { get; set; }
    public DateTime CreatedDate { get; set; }

    public bool IsDeleted { get; set; }
    public ICollection<PatientAnswer> PatientAnswers { get; set; } = new List<PatientAnswer>();


}
