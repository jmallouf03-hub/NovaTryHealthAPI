﻿namespace NovaHealth.Domain.Entities;

public class Role : BaseAuditableEntity
{
    public string Name { get; set; } = null!;

    public RoleType RoleType { get; set; }

    public string? Description { get; set; }

    public virtual ICollection<UserRole> UserRoles { get; set; } = new List<UserRole>();

}
