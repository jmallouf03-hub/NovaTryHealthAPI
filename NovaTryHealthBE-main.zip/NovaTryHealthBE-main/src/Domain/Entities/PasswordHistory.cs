﻿namespace NovaHealth.Domain.Entities;

public class PasswordHistory : BaseAuditableEntity
{
    public long UserId { get; set; }

    public User User { get; set; } = null!; 

    public string HashedPassword { get; set; }  =null!;

    public DateTimeOffset LastPasswordCreatedDate { get; set; } 
}
