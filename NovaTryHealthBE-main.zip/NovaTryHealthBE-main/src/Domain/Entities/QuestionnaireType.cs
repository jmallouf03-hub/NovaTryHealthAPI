﻿namespace NovaHealth.Domain.Entities;

public class QuestionnaireType : BaseEntity
{
    public string Type { get; set; } = null!;
}
