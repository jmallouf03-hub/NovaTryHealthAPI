﻿namespace NovaHealth.Domain.Entities;

public class AnswerOption : BaseAuditableEntity
{
  
    public string? Text { get; set; } 
    public int Priority { get; set; }

    public long? NextQuestionId { get; set; } 

    public virtual Question? Question { get; set; } 

    public string? Flag { get; set; } 

    public long? ProductId { get; set; } 

    public virtual Product? Product { get; set; } 
}
