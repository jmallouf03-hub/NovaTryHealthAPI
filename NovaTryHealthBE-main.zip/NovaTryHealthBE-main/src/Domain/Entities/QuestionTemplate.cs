﻿namespace NovaHealth.Domain.Entities;

public class QuestionTemplate : BaseEntity
{
    public string TemplateName { get; set; } = null!;
}
