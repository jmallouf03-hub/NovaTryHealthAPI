﻿
namespace NovaHealth.Domain.Entities;

public class Questionnaire : BaseAuditableEntity
{
    public string Title { get; set; } = null!;
    public string Slug { get; set; } = null!;
    public bool IsPublished { get; set; }
    public string? Status { get; set; }
    public bool Mode { get; set; }    // e.g., Live, Test

    public bool BelugaEnabledRX { get; set; }

    //  public bool EnableTranslation { get; set; }
    public long QuestionnaireTreatmentTypeId { get; set; }

    public QuestionnaireTreatmentType QuestionnaireTreatmentType { get; set; } = null!;

    public long WebDomainId { get; set; }

    public virtual WebDomain WebDomain { get; set; } = null!;

    public long QuestionnaireTypeId { get; set; }

    public virtual QuestionnaireType QuestionnaireType { get; set; } = null!;
    //  public long QuestionnaireDefaultLanguageId { get; set; }

    //   public virtual QuestionnaireDefaultLanguage QuestionnaireDefaultLanguage { get; set; } = null!;
    public long QuestionnaireGlobalLayoutId { get; set; }

    public QuestionnaireGlobalLayout QuestionnaireGlobalLayout { get; set; } = null!;
    public virtual ICollection<Question> Questions { get; set; } = new List<Question>();
    public virtual ICollection<QuestionnaireProduct> QuestionnaireProducts { get; set; } = new List<QuestionnaireProduct>();
}
