﻿namespace NovaHealth.Domain.Entities;

public  class GlobalLayoutSetting : BaseEntity
{
    public long LayoutId { get; set; }
    public virtual QuestionnaireGlobalLayout Layout { get; set; } = null!;

    public string? RoundedBoarderRaduis {  get; set; }

    public string? NavigationButtonWidth { get; set; }

    public long? QuestionTemplateId { get; set; } = null;
    public virtual QuestionTemplate? QuestionTemplate { get; set; }


}
