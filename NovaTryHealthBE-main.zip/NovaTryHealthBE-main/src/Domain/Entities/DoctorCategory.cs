﻿namespace NovaHealth.Domain.Entities;

public class DoctorCategory : BaseEntity
{
    public long UserId { get; set; }
    public virtual User User { get; set; } = null!;

    public long CategoryId { get; set; }
    public virtual Category Category { get; set; } = null!;
}
