﻿namespace NovaHealth.Domain.Entities;
public class MessageRecipient : BaseAuditableEntity
{
    public long ReceiverId { get; set; }

    public User Receiver { get; set; } = null!;

    public long MessageId { get; set; }

    public Message Message { get; set; } = null!;

    public long? ParentMessageId { get; set; }

    public long SuperParentMessageId { get; set; }
    public bool IsRead { get; set; } = false;
}
