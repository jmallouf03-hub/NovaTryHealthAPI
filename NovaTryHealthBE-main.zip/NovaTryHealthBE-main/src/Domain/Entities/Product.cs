﻿namespace NovaHealth.Domain.Entities;

public class Product : BaseAuditableEntity
{
    public string DrugName { get; set; } = null!;
    public string? BrandName { get; set; } 
    public string ShortName { get; set; } = null!;
    public string? LabelerName { get; set; } 
    public string GenericName { get; set; } = null!;
    public string? DosageForm { get; set; } 
    public decimal? ConsultOnlyPrice { get; set; }

    public ProductTypeOption ProductType { get; set;}

    public long? CategoryId { get; set; }
    public virtual Category? Category { get; set; } 

    public virtual ICollection<ProductIngredient> Ingredients { get; set; } = new List<ProductIngredient>();
    public virtual ICollection<ProductVariant> Variants { get; set; } = new List<ProductVariant>();
}
