﻿namespace NovaHealth.Domain.Entities;

public class BookOrder : BaseAuditableEntity
{
    public Guid Guid { get; set; } = Guid.NewGuid();
    public long UserId { get; set; }
    public virtual User User { get; set; } = null!;
    public decimal Amount { get; set; }
    public PaymentStatusType PaymentStatus { get; set; } = PaymentStatusType.Pending;
    public DateTime? UpdatedDate { get; set; } = null;

    public string? SessionId { get; set; }

    public virtual ICollection<ProductOrder> ProductOrders { get; set; } = new List<ProductOrder>();

}
