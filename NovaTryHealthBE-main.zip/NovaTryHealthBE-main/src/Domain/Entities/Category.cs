﻿namespace NovaHealth.Domain.Entities;

public class Category : BaseEntity
{
    public string Name { get; set; } = null!;

    public virtual ICollection<DoctorCategory> DoctorCategories { get; set; } = new List<DoctorCategory>();

}