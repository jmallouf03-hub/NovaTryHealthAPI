﻿namespace NovaHealth.Domain.Entities;

public class QuestionType : BaseEntity
{
    public string Type { get; set; } = null!;
  
}
