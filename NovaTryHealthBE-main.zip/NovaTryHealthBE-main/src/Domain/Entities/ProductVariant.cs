﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NovaHealth.Domain.Entities;

public class ProductVariant : BaseAuditableEntity
{
    public string Name { get; set; } = null!;

    public decimal Price { get; set; } 
    public decimal ComparePrice { get; set; } 

    public string? Upc { get; set; }
   
    public int Quantity { get; set; }
    public string QuantityUnit { get; set; } = null!;
    public int? Refills { get; set; }
    public string? Dose { get; set; } 
    public string? Dosage { get; set; } 
    public string? Strength { get; set; } 

    // Packing & Form
    public string? Packing { get; set; }
    public string? Form { get; set; }

    // Media
    public string? RegularImageUrlFileName { get; set; }
    public string? RegularImageUrlFilePath { get; set; }

    public string? TransparentImageUrlFileName { get; set; }
    public string? TransparentImageUrlFilePath { get; set; }

    public string? VideoUrl { get; set; }

    // Foreign key to Product
    public long ProductId { get; set; }
    public Product Product { get; set; } = null!;
}
