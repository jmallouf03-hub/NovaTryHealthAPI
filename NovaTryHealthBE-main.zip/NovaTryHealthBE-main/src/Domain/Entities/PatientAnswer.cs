﻿
namespace NovaHealth.Domain.Entities;

public class PatientAnswer : BaseEntity
{
    public long AnswerOptionId { get; set; }
    public virtual AnswerOption AnswerOption { get; set; } = null!;
    public long PatientQuesionAnswerId { get; set; }
    public virtual PatientQuestionAnswer PatientQuesionAnswer { get; set; } = null!;
    public bool IsDeleted { get; set; }
    public DateTime CreatedDate { get; set; }
}
 