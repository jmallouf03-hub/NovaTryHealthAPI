﻿namespace NovaHealth.Domain.Entities;

public class UserNotificationReference : BaseAuditableEntity
{
    public long UserId { get; set; }

    public long NotificationId { get; set; }

    public virtual Notification Notification { get; set; } = null!;

    public long NotificationTypeId { get; set; }

    public virtual User User { get; set; } = null!;

    public bool IsRead { get; set; } = false;
}

