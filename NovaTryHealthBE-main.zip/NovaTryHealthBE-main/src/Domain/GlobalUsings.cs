﻿global using NovaHealth.Domain.Common;
global using NovaHealth.Shared.Extensions;
global using NovaHealth.Shared.Enums;
global using NovaHealth.Shared.Helpers;