﻿using MediatR;

namespace NovaHealth.Domain.Common;

public abstract class BaseEvent : INotification
{
}