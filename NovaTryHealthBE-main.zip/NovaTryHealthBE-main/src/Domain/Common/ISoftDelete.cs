namespace NovaHealth.Domain.Common;

public interface ISoftDelete
{
    long? DeletedBy { get; set; }

    DateTime? DeletedDate { get; set; }
}