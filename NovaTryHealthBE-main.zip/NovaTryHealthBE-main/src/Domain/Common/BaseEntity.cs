﻿namespace NovaHealth.Domain.Common;

public abstract class BaseEntity : BaseEntity<long>
{
}