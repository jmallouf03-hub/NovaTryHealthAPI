﻿namespace NovaHealth.Domain.Common;

public interface IAuditableEntity
{
    public DateTime CreatedDate { get; set; }

    public bool IsDeleted { get; set; }

    public bool IsActive { get; set; }
}