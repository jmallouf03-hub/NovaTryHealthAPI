﻿namespace NovaHealth.Domain.Common;

public abstract class BaseAuditableEntity : BaseAuditableEntity<long>
{
}