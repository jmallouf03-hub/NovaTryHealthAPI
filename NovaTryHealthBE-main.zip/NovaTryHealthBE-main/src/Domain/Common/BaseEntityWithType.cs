﻿using System.ComponentModel.DataAnnotations.Schema;

namespace NovaHealth.Domain.Common;

public abstract class BaseEntity<T> : IEntity<T>
{
    private readonly List<BaseEvent> _domainEvents = new();
    public T Id { get; set; } = default(T)!;

    [NotMapped] public IReadOnlyCollection<BaseEvent> DomainEvents => _domainEvents.AsReadOnly();

    public void AddDomainEvent(BaseEvent domainEvent)
    {
        _domainEvents.Add(domainEvent);
    }

    public void RemoveDomainEvent(BaseEvent domainEvent)
    {
        _domainEvents.Remove(domainEvent);
    }

    public void ClearDomainEvents()
    {
        _domainEvents.Clear();
    }
}